#!/usr/bin/env python3
"""Local source-only NetHack 5 Tutorial overlay. No GitHub, AI, servers or online calls.

Usage: python tools/apply_to_upstream.py /path/to/NetHack-Android-source

Start from a CLEAN JodiJodington NetHack 5 Android checkout/extraction.
This patches the local copy; keep an untouched copy for rollback.
"""
from pathlib import Path
import shutil
import os
import sys
import xml.etree.ElementTree as ET

NAMESPACE = "http://schemas.android.com/apk/res/android"
PACKAGE = "com.tbd.nethack5.guide"
ACTIVITY = "com.tbd.NetHack5.tutorial.TutorialActivity"


def overlay(upstream):
    upstream = Path(upstream).resolve()
    project = Path(__file__).resolve().parents[1]
    app = upstream / "sys/android/app"
    manifest_path = app / "AndroidManifest.xml"
    gradle_path = app / "build.gradle"
    if not manifest_path.is_file() or not gradle_path.is_file():
        raise RuntimeError("Expected sys/android/app/{AndroidManifest.xml,build.gradle} in upstream root")

    ET.register_namespace("android", NAMESPACE)
    document = ET.parse(manifest_path)
    app_elem = document.getroot().find("application")
    if app_elem is None:
        raise RuntimeError("Application element missing")
    found = False
    for activity in app_elem.findall("activity"):
        name = activity.attrib.get(f"{{{NAMESPACE}}}name", "")
        if name in ("com.tbd.forkfront.ForkFront", ACTIVITY, "com.tbd.NetHack5.ai.GuideActivity"):
            activity.set(f"{{{NAMESPACE}}}name", ACTIVITY)
            found = True
    if not found:
        raise RuntimeError("Expected ForkFront launcher activity not found")
    app_elem.set(f"{{{NAMESPACE}}}label", "NetHack 5 Tutorial")
    document.write(manifest_path, encoding="utf-8", xml_declaration=True)

    gradle = gradle_path.read_text(encoding="utf-8")
    if "java.srcDirs(['src'])" not in gradle:
        pattern = "manifest.srcFile('AndroidManifest.xml')"
        if pattern not in gradle: raise RuntimeError("Unknown Gradle sourceSets layout")
        gradle = gradle.replace(pattern, "java.srcDirs(['src'])\n      " + pattern, 1)
    if 'applicationId = "'+PACKAGE+'"' not in gradle:
        pattern = "defaultConfig {"
        if pattern not in gradle: raise RuntimeError("Unknown Gradle defaultConfig layout")
        gradle = gradle.replace(pattern, pattern+'\n    applicationId = "'+PACKAGE+'"', 1)
    if "minSdkVersion = 7" in gradle:
        gradle = gradle.replace("minSdkVersion = 7", "minSdkVersion = 23", 1)
    if "versionCode = 5000" in gradle:
        gradle = gradle.replace("versionCode = 5000", "versionCode = 50033", 1)
    elif "versionCode = 5002" in gradle:
        gradle = gradle.replace("versionCode = 5002", "versionCode = 50033", 1)
    elif "versionCode = 50033" not in gradle:
        raise RuntimeError("Unexpected versionCode — avoid accidental downgrade")
    if "versionName = '5.0.0'" in gradle:
        gradle = gradle.replace("versionName = '5.0.0'", "versionName = '5.0.0-tutorial-floor4'", 1)
    # Signed test builds must keep one stable identity across CI runners.
    # This public project-specific TEST key is stored under signing/ in the repo;
    # do not treat it as a private production release identity.
    key=os.environ.get("NETHACK_STABLE_KEYSTORE","")
    if key:
        if not Path(key).is_file(): raise RuntimeError("Configured stable signing keystore not found")
        signing="""
  signingConfigs {
    tutorialStable {
      storeFile = file(System.getenv('NETHACK_STABLE_KEYSTORE'))
      storeType = 'pkcs12'
      storePassword = System.getenv('NETHACK_STABLE_PASSWORD')
      keyAlias = 'nethack-tutorial'
      keyPassword = System.getenv('NETHACK_STABLE_PASSWORD')
    }
  }
  buildTypes {
    debug {
      signingConfig = signingConfigs.tutorialStable
    }
  }
"""
        if "signingConfigs {" in gradle: raise RuntimeError("Unexpected preexisting Android signing config")
        gradle=gradle.replace("android {", "android {"+signing, 1)
    gradle_path.write_text(gradle, encoding="utf-8")

    for source in (project / "app/src/main/java").rglob("*.java"):
        relative = source.relative_to(project / "app/src/main/java")
        dest = app / "src" / relative
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
    for source in (project / "app/src/main/res").rglob("*.xml"):
        dest = app / "res" / source.relative_to(project / "app/src/main/res")
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, dest)
    # Feed the tame-monster flag through to the local, read-only Android tutor.
    # The native port previously stripped MG_PET when the highlight option
    # was off, losing knowledge that the engine actually displayed as a pet.
    native = upstream / 'sys/android/winandroid.c'
    content = native.read_text()
    marker = '    if(!iflags.hilite_pet)\n        special &= ~MG_PET;'
    if marker not in content:
        raise RuntimeError('winandroid.c pet flag stripping changed; review before building')
    native.write_text(content.replace(marker,
       '    /* Tutorial mode needs the rendered MG_PET marker even if optional highlighting is off. */', 1))
    print("Local tutorial source installed.")
    print("No GitHub, ChatGPT or API integration added.")
    print("Application ID:", PACKAGE)
    print("WARNING: a normal update still requires matching APK signing certificates.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: python3 tools/apply_to_upstream.py /path/to/NetHack-Android-source")
    overlay(sys.argv[1])
