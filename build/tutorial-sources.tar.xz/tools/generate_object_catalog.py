#!/usr/bin/env python3
"""Generate read-only set of object tile indices from NetHack's actual tilemap utility.

Only object-category information is exposed. The mapping deliberately never
reveals item identities, which can be randomized at the start of a game.
"""
import re
import sys
from pathlib import Path

def generate(upstream):
    upstream=Path(upstream)
    matches=list(upstream.rglob('tilemappings.lst'))
    if not matches: raise RuntimeError('Native tilemap listing not found; refusing to guess object tile identities')
    raw=matches[0].read_text(errors='replace')
    bounds={k:int(v) for k,v in re.findall(r'^([A-Z_]+)\s*=\s*(\d+)\s*$',raw,re.M)}
    first=bounds.get('GLYPH_OBJ_OFF'); end=bounds.get('GLYPH_CMAP_OFF')
    if first is None or end is None or not 0<first<end: raise RuntimeError('Object glyph bounds invalid')
    mapped=[]
    for glyph,tile in re.findall(r'^glyph\[\s*(\d+)\]\s+\[\s*(-?\d+)\]',raw,re.M):
        glyph,tile=int(glyph),int(tile)
        if first<=glyph<end and tile>=0: mapped.append(tile)
    if len(mapped)<100 or not 0<min(mapped)<max(mapped)<20000:
        raise RuntimeError('Unexpected object visual tile range')
    # Only public object class/tile existence, NOT actual randomized identity.
    vals=sorted(set(mapped))
    body='''package com.tbd.NetHack5.tutorial;
/** Generated from this build's native NetHack tilemappings.lst.
 * An object is never identified by its randomized appearance. */
final class ObjectCatalog {
    private ObjectCatalog() {}
    private static final int[] TILES = {%s};
    static boolean isGroundObjectTile(int tile) {
        return java.util.Arrays.binarySearch(TILES,tile)>=0;
    }
}
''' % ','.join(map(str,vals))
    dest=upstream/'sys/android/app/src/com/tbd/NetHack5/tutorial/ObjectCatalog.java'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(body)
    print('Object tile catalog generated:',len(vals),'tiles;', 'range',min(vals),max(vals))

if __name__=='__main__':
    if len(sys.argv)!=2: raise SystemExit('Usage: generate_object_catalog.py upstream')
    generate(sys.argv[1])
