#!/usr/bin/env python3
"""Generate a read-only monster tile index from the *same* NetHack 5 build.

The Android port passes glyphinfo->gm.tileidx, NOT the raw NetHack glyph.
NetHack 5's win/share/tilemap.c orders male/female monster tiles by pm.h
index and reserves two tile numbers for each omitted conditional monster.
Do not silently guess a species if this metadata cannot be built.
"""
from pathlib import Path
import re
import sys


def generate(upstream):
    upstream = Path(upstream)
    pm = upstream / 'include' / 'pm.h'
    tilemap = upstream / 'win' / 'share' / 'tilemap.c'
    if not pm.exists() or not tilemap.exists():
        raise RuntimeError('NetHack pm.h or tilemap.c missing; refuse guessed monster mappings')
    pms = re.findall(r'^\s*#define\s+PM_([A-Z0-9_]+)\s+(\d+)\b', pm.read_text(), re.M)
    if not pms:
        # Some NetHack distributions use an enum instead of defines.
        raise RuntimeError('Unsupported generated pm.h format: review monster index generator')
    ids = {name:int(index) for name,index in pms}
    ordered = sorted(ids.items(), key=lambda kv:kv[1])
    assert all(n == i for i,(_,n) in enumerate(ordered)), 'Non-sequential monster ids'
    conditional_text = tilemap.read_text()
    # Same optional reservations as tilemap.c. The pinned build does not
    # compile CHARON or MAIL_STRUCTURES, so these entries are reserved.
    reservations = {}
    for predecessor in re.findall(r'\{\s*MON_GLYPH\s*,\s*PM_([A-Z0-9_]+)\s*,',conditional_text):
        if predecessor not in ids:
            raise RuntimeError('Unknown conditional monster predecessor: '+predecessor)
        reservations[ids[predecessor]] = reservations.get(ids[predecessor],0)+1
    entries = []
    tile_no = 0
    for ident,n in ordered:
        title=ident.lower().replace('_',' ')
        for sex in ('male','female'):
            entries.append((tile_no,title));tile_no+=1
        tile_no+=2*reservations.get(n,0)
    # Important: this mapping is only for live monster tiles; do not decode
    # corpses, objects, statues or effects by reusing this array.
    table = ',\n        '.join('"'+v[1].replace('\\','\\\\').replace('"','\\"')+'"' for v in entries)
    # Sparse holes represented as null in exact tile-id array.
    dense=['null']*tile_no
    for tile,name in entries:
        dense[tile]='"'+name.replace('\\','\\\\').replace('"','\\"')+'"'
    body='''package com.tbd.NetHack5.tutorial;
/** Generated from pinned NetHack 5 include/pm.h and win/share/tilemap.c.
 * This maps visual *monster tiles* to species, without accessing hidden monsters.
 * Other tile types and out-of-range ids deliberately return null. */
public final class MonsterCatalog {
    private MonsterCatalog() {}
    private static final String[] NAMES = {\n        %s\n    };
    public static String fromTile(int tile) {
        if (tile < 0 || tile >= NAMES.length) return null;
        return NAMES[tile];
    }
    public static int knownTiles() { return NAMES.length; }
}
''' % ',\n        '.join(dense)
    dest=upstream/'sys/android/app/src/com/tbd/NetHack5/tutorial/MonsterCatalog.java'
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(body)
    fox=[k for k,v in entries if v=='fox']
    kitten=[k for k,v in entries if v=='kitten']
    assert len(fox)==2 and len(kitten)==2 and fox[0]<kitten[0]
    print('Monster catalog: %d species, %d visual tiles, fox=%s kitten=%s' % (len(ordered),tile_no,fox,kitten))

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: generator.py upstream')
    generate(sys.argv[1])
