#!/usr/bin/env python3
"""Read authoritative NetHack 5.0 include/objects.h; generate offline weapon stats.

Only record compile-time literal values for standard weapons; skip unknown
macros, values, or deferred/#if 0 blocks. No runtime network access.
"""
import json, re, sys
from pathlib import Path


def weapon_rows(data):
    # Strip block/line comments, honor #if 0 explicitly to avoid deferred items.
    data = re.sub(r'/\*.*?\*/', ' ', data, flags=re.S)
    data = re.sub(r'//[^\n]*', '', data)
    keep=[]; disabled=[]
    for line in data.splitlines():
        directive=re.match(r'\s*#\s*(if|ifdef|ifndef|endif|else|elif)\b\s*(.*)', line)
        if directive:
            cmd,arg=directive.groups()
            if cmd in ('if','ifdef','ifndef'):
                disabled.append((cmd == 'if' and re.match(r'0(?:\s|$)',arg) is not None) or (disabled[-1] if disabled else False))
            elif cmd == 'endif' and disabled:disabled.pop()
            elif cmd == 'else' and disabled: # keep ambiguous branches unless within a disabled outer block
                outer=disabled[-2] if len(disabled)>1 else False
                disabled[-1]=outer or not disabled[-1]
            continue
        if not any(disabled):keep.append(line)
    data='\n'.join(keep)
    for m in re.finditer(r'(?m)^\s*(WEAPON|PROJECTILE|BOW)\s*\(', data):
        kind=m.group(1); level=1;end=m.end(); quoted=False;escape=False
        while end<len(data) and level:
            ch=data[end]
            if quoted:
                if escape:escape=False
                elif ch=='\\':escape=True
                elif ch=='"':quoted=False
            else:
                if ch=='"':quoted=True
                elif ch=='(':level+=1
                elif ch==')':level-=1
            end+=1
        if level:continue
        inner=data[m.end():end-1]
        args=[];cur='';depth=0;quote=False;esc=False
        for ch in inner:
            if quote:
                cur+=ch
                if esc:esc=False
                elif ch=='\\':esc=True
                elif ch=='"':quote=False
            elif ch=='"':quote=True;cur+=ch
            elif ch=='(':depth+=1;cur+=ch
            elif ch==')':depth-=1;cur+=ch
            elif ch==',' and depth==0:args.append(cur.strip());cur=''
            else:cur+=ch
        args.append(cur.strip())
        if not args[0].startswith('"'):continue
        name=args[0].strip('"')
        try:
            if kind=='PROJECTILE' and len(args)==13:
                _,_,_,freq,wt,cost,sdam,ldam,hit,metal,skill,_,_=args
                launcher=True
            elif kind=='WEAPON' and len(args)==16:
                _,_,_,_,_,freq,wt,cost,sdam,ldam,hit,_,skill,metal,_,_=args
                launcher=False
            elif kind=='BOW' and len(args)==11:
                _,_,_,freq,wt,cost,hit,metal,skill,_,_=args
                sdam=ldam='2';launcher=False
            else:continue
            if not all(re.fullmatch(r'-?\d+',v) for v in (wt,cost,sdam,ldam,hit)):
                continue
        except ValueError:continue
        def skillname(x):
            x=x.lstrip('-');return x[2:].replace('_',' ').lower().title() if x.startswith('P_') else '—'
        wield=skillname(skill)
        if kind=='PROJECTILE':
            if 'BOW' in skill and 'CROSSBOW' not in skill:combo='Bow (elven bow is a natural pairing for elven arrows)' if name=='elven arrow' else 'Bow'
            elif 'CROSSBOW' in skill:combo='Crossbow'
            else:combo='Appropriate launcher'
        elif kind=='BOW':combo='Matching arrows' if name!='sling' else 'Sling bullets, stones and gems'
        else:combo='None required'
        yield dict(name=name,kind=kind,small='1d'+sdam,large='1d'+ldam,
                   hit=('+' if int(hit)>=0 else '')+hit,weight=wt,price=cost,
                   material=metal.replace('_',' ').lower(),skill=wield,combo=combo)


def generate(upstream):
    upstream=Path(upstream)
    src=upstream/'include/objects.h'
    if not src.exists():raise SystemExit('Missing exact pinned NetHack 5 object definitions')
    rows=list(weapon_rows(src.read_text()))
    names={x['name']:x for x in rows}
    if len(names)<40 or 'elven arrow' not in names or names['elven arrow']['small']!='1d7' or names['elven arrow']['large']!='1d6':
        raise SystemExit('Weapon macro parsing inconsistent with NetHack 5; refusing unverified data')
    dest=upstream/'sys/android/app/src/com/tbd/NetHack5/tutorial/WeaponStats.java'
    dest.parent.mkdir(parents=True,exist_ok=True)
    lines=['package com.tbd.NetHack5.tutorial;',
           '/** Base stats generated from the exact NetHack 5 include/objects.h. */',
           'final class WeaponStats {',
           '  static final class Info {',
           '    final String name,kind,small,large,hit,weight,price,material,skill,combo;',
           '    Info(String a,String b,String c,String d,String e,String f,String g,String h,String i,String j) {',
           '      name=a;kind=b;small=c;large=d;hit=e;weight=f;price=g;material=h;skill=i;combo=j;',
           '    }',
           '    String[][] rows() { return new String[][] {',
           '      {"Damage · small",small}, {"Damage · large",large}, {"To-hit",hit},',
           '      {"Weight",weight}, {"Base price",price+" zm"},',
           '      {"Material",material}, {"Skill",skill}, {"Pairs with",combo}',
           '    }; }',
           '  }',
           '  private static final java.util.Map<String,Info> ALL = new java.util.HashMap<>();',
           '  static {']
    for row in rows:
        items=[row[x] for x in ('name','kind','small','large','hit','weight','price','material','skill','combo')]
        lines.append('    add('+','.join(json.dumps(v,ensure_ascii=True) for v in items)+');')
    lines.extend(['  }',
        '  private static void add(String name,String kind,String small,String large,String hit,String weight,String price,String material,String skill,String combo) {',
        '    ALL.put(name,new Info(name,kind,small,large,hit,weight,price,material,skill,combo));',
        '  }',
        '  static Info find(String observed) {',
        '    if(observed==null)return null;',
        '    String k=observed.trim().toLowerCase(java.util.Locale.ROOT);',
        '    Info exact=ALL.get(k);if(exact!=null)return exact;',
        '    if(k.endsWith("s") && !k.endsWith("ss"))return ALL.get(k.substring(0,k.length()-1));',
        '    return null;',
        '  }',
        '  static int count() {return ALL.size();}',
        '}'])
    dest.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('Generated',len(names),'verified NetHack 5 weapon entries:',dest)
    return names

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python3 generate_weapon_stats.py upstream')
    generate(sys.argv[1])
