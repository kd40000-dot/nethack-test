import tempfile
from pathlib import Path
from generate_object_catalog import generate
with tempfile.TemporaryDirectory() as d:
    root=Path(d); (root/'util').mkdir();
    (root/'util/tilemappings.lst').write_text('GLYPH_OBJ_OFF = 10\nGLYPH_CMAP_OFF = 210\n'+'\n'.join(f'glyph[{x:04d}] [{x+1000:04d}] item' for x in range(220)))
    generate(root)
    p=root/'sys/android/app/src/com/tbd/NetHack5/tutorial/ObjectCatalog.java'
    assert '1010,1011' in p.read_text()
    assert '1220' not in p.read_text()
print('Object mapping test passed')
