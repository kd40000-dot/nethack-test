from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/tbd/NetHack5/tutorial'
ui=(src/'TutorialOverlay.java').read_text()
state=(src/'StateProbe.java').read_text()
engine=(src/'TutorialEngine.java').read_text()

def test_only_cardinal_known_doors():
    assert "if(c=='+' && Math.abs(dx)+Math.abs(dy)==1)" in state
    assert 's.adjacentDoors.add(new TutorialEngine.Door(dx,dy))' in state
    assert 'Math.abs(dx)+Math.abs(dy)!=1' in engine

def test_atomic_sequenced_door_action_and_multiple_choice():
    assert 'view.adjacentDoors.size()==1' in ui
    assert 'showDoorDirections(command,view.adjacentDoors)' in ui
    assert 'awaitDoorDirection(game,key,token,0,priorDirectionMessage)' in ui
    assert 'game.expectsDirection() && game.isDPadVisible()' in ui
    assert 'newMapPrompt' in ui
    assert 'probe.visibleDirectionPrompt()' in ui
    assert 'game.sendDirKeyCmd(target)' in ui
    assert 'boolean confirmed=false' in ui
    assert 'if(!confirmed || fresh.inputPromptActive)' in ui
    assert 'cmd.equals("o")' not in ui or 'cmd.equals("M-u")' in ui

def test_runtime_hardening_and_modal_lifecycle():
    assert 'private void safeRefresh()' in ui
    assert 'catch(RuntimeException failure)' in ui
    assert 'Log.e("NetHackTutorial"' in ui
    assert 'activity.isFinishing() || activity.isDestroyed()' in ui
    assert 'handler.postDelayed(this::safeRefresh' in ui
    assert 'handler.postDelayed(this::refresh' not in ui

def test_real_icons_and_usable_actions():
    assert 'setCompoundDrawablesRelative' in ui
    assert 'Drawable image=activity.getDrawable(icon)' in ui
    for category in ('NEARBY DOORS','AT YOUR FEET','YOUR AVAILABLE ITEMS','BAG & EXPLORATION','DISPLAY & ACCESSIBILITY','MORE NETHACK COMMANDS'):
        assert category in ui
    for command in ('"e"','"q"','"r"','"w"','"W"','"P"','"R"','"z"','"M-l"'):
        assert command in ui
    assert 'if(s.inventoryKnown)' in ui

def test_unverified_inventory_never_enables_item_commands():
    assert 'if(!s.inventoryKnown) return false' in ui
    assert 'if(matches && !text.contains("being worn")' in ui

def test_no_untrusted_code_or_network_dependency():
    for path in src.glob('*.java'):
        code=path.read_text()
        assert 'api.openai.com' not in code
        assert 'Runtime.getRuntime().exec' not in code

def test_command_center_rechecks_live_capability_after_modal():
    assert 'private boolean commandStillRelevant(String command)' in ui
    assert 'if(!commandStillRelevant(cmd))' in ui
    assert 'if(commandStillRelevant(cmd))dispatch(cmd)' in ui
    assert 'case ",":return s.itemHere' in ui
    assert 'case "o": case "M-u": return !s.adjacentDoors.isEmpty()' in ui
    assert 'pendingDoorToken++' in ui


def test_both_native_getdir_modes():
    assert 'String visibleDirectionPrompt()' in state
    assert 'normalized.contains("what direction")' in state
    assert 'boolean directionPad' in ui
    assert 'boolean newMapPrompt' in ui
    assert 'if(directionPad || newMapPrompt)' in ui
    assert '!visible.equals(previousPrompt)' in ui
