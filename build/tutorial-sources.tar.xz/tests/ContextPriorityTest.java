package com.tbd.NetHack5.tutorial;

public class ContextPriorityTest {
    private static int assertions=0;
    private static void yes(boolean condition,String label) {
        if(!condition)throw new AssertionError(label);
        assertions++;
    }
    private static boolean command(TutorialEngine.Advice advice,String name) {
        for(TutorialEngine.Choice c:advice.choices)if(name.equals(c.command))return true;
        return false;
    }
    private static TutorialEngine.State withKitten(){
        TutorialEngine.State s=new TutorialEngine.State();s.gameReady=true;s.hp=16;s.maxHp=16;
        s.nearbyMonsters.add(new TutorialEngine.Monster("kitten",true,1,0));
        s.monsterAdjacent=true;
        return s;
    }
    public static void main(String[] args){
        TutorialEngine.State state=withKitten();
        yes(TutorialEngine.assess(state).title.contains("pet kitten"),"introduce new pet only when nothing more relevant exists");
        state.groundItems.add(new TutorialEngine.GroundItem("tool",-1,0));
        state.visibleStairs.add(new TutorialEngine.Stair(3,2,true));
        TutorialEngine.Advice advice=TutorialEngine.assess(state);
        yes(advice.title.equals("A tool to the west"),"SCREENSHOT: tool beats adjacent tame kitten");
        yes(command(advice,"MOVE:-1:0"),"SCREENSHOT: one-step tool approach offered");
        yes(!advice.title.contains("kitten"),"SCREENSHOT: kitten must not hide useful discovery");
        state.groundItems.clear();
        yes(TutorialEngine.assess(state).title.toLowerCase().contains("staircase down"),"mapped stairs beat repeated kitten tip");
        state.visibleStairs.clear();
        state.acknowledgedPets.add("kitten");
        yes(TutorialEngine.assess(state).title.equals("Explore carefully"),"after reading pet help, stop repeat focus");
        state.groundItems.add(new TutorialEngine.GroundItem("tool",0,0,"leash","leash"));
        state.itemHere=true;
        yes(TutorialEngine.assess(state).title.equals("Leash at your feet"),"observed floor name beats kitten");
        yes(command(TutorialEngine.assess(state),","),"only underfoot can pick up");
        state.itemHere=false;state.groundItems.clear();
        state.stairsDownHere=true;
        yes(command(TutorialEngine.assess(state),">"),"standing on stairs offers descend");
        state.stairsDownHere=false;
        state.groundItems.add(new TutorialEngine.GroundItem("scroll",0,0));
        state.itemHere=true;
        yes(TutorialEngine.assess(state).title.toLowerCase().contains("scroll"),"scroll at feet beats kitten");
        state.groundItems.clear();state.itemHere=false;
        state.nearbyMonsters.add(new TutorialEngine.Monster("kobold",false,-1,1));
        yes(TutorialEngine.assess(state).title.toLowerCase().contains("kobold"),"creatures requiring caution outrank distractions");
        state.hp=2;
        yes(TutorialEngine.assess(state).title.toLowerCase().contains("danger"),"low hp outranks even creatures");
        TutorialEngine.Stair diagonal=new TutorialEngine.Stair(3,2,true);
        yes(diagonal.direction().equals("south-east"),"stair direction");
        yes(diagonal.distance()==3,"stair tile distance is Chebyshev, not fake travel time");
        System.out.println("PASS: "+assertions+" context-priority assertions");
    }
}
