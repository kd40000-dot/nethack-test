import com.tbd.NetHack5.tutorial.WikiLibrary;
public class WikiLibraryTest {
  static void yes(boolean b,String what){if(!b) throw new AssertionError(what);}
  public static void main(String[] args) {
    yes(WikiLibrary.count()>=25,"expected useful offline reference depth");
    yes(WikiLibrary.forInventoryItem("a pink potion").id.equals("potion"),"unknown color must remain unknown");
    yes(WikiLibrary.forInventoryItem("an uncursed wand of opening").id.equals("wand-opening"),"known wand should resolve");
    yes(WikiLibrary.forInventoryItem("a tin opener").id.equals("tinopener"),"item combinations should resolve");
    yes(WikiLibrary.forInventoryItem("a scroll labeled YUM YUM").id.equals("scroll"),"randomized scroll labels should not identify");
    yes(WikiLibrary.forMessage("This door is locked").id.equals("door"),"message routing for doors");
    yes(WikiLibrary.forMessage("The fox bites!").id.equals("fox"),"fox encounter help is specific");
    yes(WikiLibrary.monsterTopic("kitten",true).equals("kitten"),"kitten help is species-specific");
    System.out.println("PASS: 8 offline wiki routing assertions; "+WikiLibrary.count()+" reference cards");
  }
}
