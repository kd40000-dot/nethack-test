from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PROBE=(ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/StateProbe.java').read_text()
OVERLAY=(ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()
ENGINE=(ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialEngine.java').read_text()

def test_never_resurrect_floor_from_old_message():
    assert 's.itemHere=s.itemHere||message.contains("you see here")' not in PROBE
    assert 's.floorPickupUnverified' in PROBE
    assert 'floorGuard.blocks(player.x,player.y)' in PROBE
    assert 'confirmedFloorItem=null;' in PROBE

def test_immediate_suppression_precedes_pickup_command():
    assert 'if(command.equals(",")) {' in OVERLAY
    assert OVERLAY.index('probe.pickupRequested()') < OVERLAY.index('if(command.startsWith("MOVE:"))')
    assert 'handler.post(this::safeRefresh)' in OVERLAY

def test_pile_recheck_without_asserting_item_exists():
    assert 'if(s.floorPickupUnverified)' in ENGINE
    assert 'Check if anything remains here' in ENGINE
    assert '"inventory",false' in ENGINE

def test_turn_change_invalidate_stale_name():
    assert 'if(observedTurn>=0 && currentTurn!=observedTurn)' in PROBE
    assert PROBE.index('if(observedTurn>=0 && currentTurn!=observedTurn)') < PROBE.index('s.recentMessage=latestMessage()')
