package com.tbd.NetHack5.tutorial;

public class GroundMessageTest {
    static void assertThat(boolean yes, String label){if(!yes)throw new AssertionError(label);}
    public static void main(String[] args) {
        GroundMessage.Seen x=GroundMessage.parse("You see here a lichen corpse.");
        assertThat(x!=null && x.name.equals("lichen corpse") && x.category.equals("corpse") && x.topic.equals("lichen-corpse"),"Recognize lichen corpse exactly");
        x=GroundMessage.parse("You see here 5 gold pieces.");
        assertThat(x!=null && x.category.equals("gold") && x.name.equals("5 gold pieces"),"Recognize displayed amount of gold");
        x=GroundMessage.parse("You see here a scroll labeled DAIYEN FOOELS.");
        assertThat(x!=null && x.category.equals("scroll") && x.name.equals("scroll labeled DAIYEN FOOELS") && x.topic.equals("scroll"),"Preserve scroll label but not reveal hidden effect");
        assertThat(GroundMessage.parse("You hit the lichen!")==null,"Unrelated combat message isn't floor item");
        assertThat(GroundMessage.parse("You see here something.")==null,"Don't claim a specific unknown item");
        assertThat(GroundMessage.invalidates("You pick up a lichen corpse."),"Picking up invalidates old floor evidence");
        assertThat(GroundMessage.invalidates("You finish eating the lichen corpse."),"Eating invalidates floor evidence");
        assertThat(!GroundMessage.invalidates("You hit the kobold!"),"Combat alone doesn't erase underfoot report");
        assertThat(WikiLibrary.forInventoryItem("a lichen corpse").id.equals("lichen-corpse"),"Inventory wiki uses exact species");
        assertThat(WikiLibrary.forMessage("You see here a lichen corpse.").id.equals("lichen-corpse"),"Context wiki uses exact species");
        TutorialEngine.State state=new TutorialEngine.State(); state.gameReady=true;state.itemHere=true;
        state.groundItems.add(new TutorialEngine.GroundItem("corpse",0,0,"lichen corpse","lichen-corpse"));
        TutorialEngine.Advice advice=TutorialEngine.assess(state);
        assertThat(advice.title.contains("Lichen corpse"),"Main panel names lichen corpse");
        assertThat(advice.wikiTopic.equals("lichen-corpse"),"Main panel chooses lichen-specific wiki");
        boolean ate=false;
        for(TutorialEngine.Choice c:advice.choices)if(c.command.equals("e"))ate=true;
        assertThat(ate,"Context offers lichen eating command");
        System.out.println("PASS: 12 exact-floor-object and wiki contextual tests");
    }
}
