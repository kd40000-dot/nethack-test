from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATE = (ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/StateProbe.java').read_text()
UI = (ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()


def test_prompt_requires_attached_visible_native_ui():
    assert 'view.getParent()!=null && view.isShown()' in STATE
    assert 's.inputPromptActive=activeNativePrompt(state);' in STATE
    assert 'hasVisiblePopup(get(state,"mQuestion"))' in STATE
    assert 'hasVisiblePopup(get(state,"mGetLine"))' in STATE
    assert 'hasVisiblePopup(window)' in STATE
    assert 'Boolean.TRUE.equals(get(wnd,"mIsVisible"))) s.inputPromptActive=true' not in STATE


def test_no_position_marker_or_overlay():
    assert 'PlayerLocatorView' not in UI
    assert 'playerLocator' not in UI
    assert 'canvas.drawText("YOU"' not in UI
    assert 'frame.addView(playerLocator' not in UI


def test_native_refresh_patched_after_ring_state_change():
    source=(ROOT/'tools/apply_to_upstream.py').read_text()
    assert 'src/do_wear.c' in source
    assert 'Ring_off_or_gone(obj, FALSE)' in source
    assert 'docrt();' in source
    assert 'ring_anchor' in source and 'code.count(ring_anchor) != 1' in source
    assert 'fake marker' in source
