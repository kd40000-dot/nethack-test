from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATE = (ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/StateProbe.java').read_text()
UI = (ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()


def test_prompt_requires_attached_visible_native_ui():
    assert 'view.getParent()!=null && view.isShown()' in STATE
    assert 's.inputPromptActive=activeNativePrompt(state);' in STATE
    assert 'hasVisiblePopup(get(state,"mQuestion"))' in STATE
    assert 'hasVisiblePopup(get(state,"mGetLine"))' in STATE
    assert 'hasVisiblePopup(window)' in STATE
    assert 'Boolean.TRUE.equals(get(wnd,"mIsVisible"))) s.inputPromptActive=true' not in STATE


def test_player_location_visible_when_native_glyph_absent():
    assert 'private static final class PlayerLocatorView extends View' in UI
    assert 'new PlayerLocatorView(activity,probe)' in UI
    assert 'frame.addView(playerLocator,new FrameLayout.LayoutParams(-1,-1));' in UI
    assert 'if(playerLocator!=null)playerLocator.invalidate();' in UI
    assert 'Point player=(Point)StateProbe.get(map,"mPlayerPos")' in UI
    assert 'mViewOffset' in UI
    assert 'getScaledTileWidth' in UI and 'getScaledTileHeight' in UI
    assert 'canvas.drawText("YOU",cx,baseline,ink)' in UI
    assert 'setClickable(false)' in UI
