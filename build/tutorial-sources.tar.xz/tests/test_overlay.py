import pathlib, tempfile, subprocess, xml.etree.ElementTree as ET
ROOT = pathlib.Path(__file__).resolve().parents[1]

def test_clean_overlay():
    with tempfile.TemporaryDirectory() as work:
        upstream=pathlib.Path(work)
        app=upstream/'sys/android/app';app.mkdir(parents=True)
        (app/'AndroidManifest.xml').write_text('''<manifest xmlns:android="http://schemas.android.com/apk/res/android"><application><activity android:name="com.tbd.forkfront.ForkFront"/></application></manifest>''')
        (app/'build.gradle').write_text("android { defaultConfig { minSdkVersion = 7\nversionName = '5.0.0'\nversionCode = 5000 } sourceSets { main { manifest.srcFile('AndroidManifest.xml') } } }")
        (upstream/'sys/android/winandroid.c').write_text('    if(!iflags.hilite_pet)\n        special &= ~MG_PET;\n')
        subprocess.run(['python3',str(ROOT/'tools/apply_to_upstream.py'),str(upstream)],check=True,capture_output=True)
        root=ET.parse(app/'AndroidManifest.xml').getroot()
        assert 'tutorial.TutorialActivity' in str(root.find('application').find('activity').attrib)
        assert (app/'src/com/tbd/NetHack5/tutorial/TutorialOverlay.java').exists()
        assert (app/'res/layout/menu_item.xml').exists()
        gradle=(app/'build.gradle').read_text()
        assert 'versionCode = 50037' in gradle
        assert 'com.tbd.nethack5.guide' in gradle
        assert 'special &= ~MG_PET' not in (upstream/'sys/android/winandroid.c').read_text()
