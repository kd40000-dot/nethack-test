import com.tbd.NetHack5.tutorial.TutorialEngine;
import java.util.Arrays;

public class TutorialEngineTest {
  static void yes(boolean ok, String test) { if (!ok) throw new AssertionError(test); }
  static boolean has(TutorialEngine.Advice a, String command) {
    for (TutorialEngine.Choice c : a.choices) if (c.command.equals(command)) return true;
    return false;
  }
  public static void main(String[] args) {
    TutorialEngine.State s=new TutorialEngine.State(); s.gameReady=true;
    s.doorAdjacent=true; s.recentMessage="This door is locked.";
    yes(!has(TutorialEngine.assess(s),"a"),"Key action must be hidden without inventory evidence");
    s.inventoryKnown=true;s.knownInventory=Arrays.asList("a - a skeleton key", "b - a +0 dagger");
    yes(has(TutorialEngine.assess(s),"a"),"Key action should appear for confirmed skeleton key");
    s.knownInventory=Arrays.asList("a - a +0 dagger");
    yes(!has(TutorialEngine.assess(s),"a"),"Do not offer key when only dagger carried");
    s.doorAdjacent=false;s.recentMessage="";s.conditions="Hungry";
    yes(!has(TutorialEngine.assess(s),"e"),"No eat button until safe food verified");
    s.knownInventory=Arrays.asList("an uncursed food ration");
    yes(has(TutorialEngine.assess(s),"e"),"Offer eat when verified safe ration");
    s.conditions="";s.hp=2;s.maxHp=20;
    yes(!has(TutorialEngine.assess(s),"."),"No risky wait at critical HP");
    s.hp=20;s.inputPromptActive=true;
    yes(TutorialEngine.assess(s).choices.size()==1,"Only cancel during input prompt");
    s.inputPromptActive=false;s.monsterAdjacent=true;
    yes(!has(TutorialEngine.assess(s),"^d"),"No kick during nearby monster");
    s.monsterAdjacent=true;
    s.nearbyMonsters.add(new TutorialEngine.Monster("fox",false,1,0));
    yes(TutorialEngine.assess(s).title.toLowerCase().contains("fox"),"Visible monster tiles name fox specifically");
    s.nearbyMonsters.clear();
    s.nearbyMonsters.add(new TutorialEngine.Monster("kitten",true,0,1));
    yes(TutorialEngine.assess(s).title.toLowerCase().contains("pet kitten"),"Confirmed kitten is a pet, not generic creature");
    s.nearbyMonsters.add(new TutorialEngine.Monster("fox",false,1,0));
    yes(TutorialEngine.assess(s).title.toLowerCase().contains("fox"),"Nearby threat takes priority over tame kitten");
    System.out.println("PASS: 10 conservative context/eligibility assertions");
  }
}
