from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
J=BASE/'app/src/main/java/com/tbd/NetHack5/tutorial'

def test_native_staircase_observation_and_stale_pet_ack():
    src=(J/'StateProbe.java').read_text()
    assert "symbol=='>' || symbol=='<'" in src
    assert 's.visibleStairs.sort' in src
    assert 'pet_explained_' in src
    assert 's.acknowledgedPets.add(monster.species)' in src

def test_overlay_keeps_secondary_landmarks_and_pet_help():
    src=(J/'TutorialOverlay.java').read_text()
    assert 'MAPPED STAIRCASES' in src
    assert 'stairHints.removeAllViews()' in src
    assert 'Companion: ' in src
    assert 'probe.markPetExplained(card.id)' in src
    assert 'for(TutorialEngine.Stair stair:s.visibleStairs)' in src

def test_engine_priority_and_pets_not_interchangeable_with_enemies():
    src=(J/'TutorialEngine.java').read_text()
    assert 'if (nonPetNearby)' in src
    assert 'if (s.itemHere || !s.groundItems.isEmpty())' in src
    assert 'if (!s.visibleStairs.isEmpty()' in src
    assert src.index('if (s.itemHere || !s.groundItems.isEmpty())') < src.index('if (!s.visibleStairs.isEmpty()') < src.index('for(Monster pet:s.nearbyMonsters)')
