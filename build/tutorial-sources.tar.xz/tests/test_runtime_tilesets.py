"""Prevent recurrence of resource names resolving to the original package."""
from pathlib import Path
R = Path(__file__).resolve().parents[1]

def test_package_namespace_matches_application_id():
    script=(R/'tools/apply_to_upstream.py').read_text()
    assert 'PACKAGE = "com.tbd.nethack5.guide"' in script
    assert 'res/values/config.xml' in script
    assert 'config.write_text(config_text.replace(original, replacement)' in script
    assert 'Resources.getIdentifier' in script

def test_picker_checks_both_sheet_and_overlay_before_saving():
    src=(R/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()
    assert 'getIdentifier(value,"drawable",activity.getPackageName())' in src
    assert 'getIdentifier("overlays","drawable",activity.getPackageName())' in src
    assert 'if(sheet==0 || marks==0)' in src
    assert src.index('if(sheet==0 || marks==0)') < src.index('boolean saved=prefs.edit().putString("tileset",value)')

def test_all_built_in_values_preserved():
    src=(R/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()
    assert 'R.array.tileNames' in src and 'R.array.tileValues' in src
    assert 'state.preferencesUpdated()' in src
