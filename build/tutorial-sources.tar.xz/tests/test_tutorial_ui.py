from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
JAVA=ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial'
RES=ROOT/'app/src/main/res/layout'

def test_live_preview_hierarchy():
    code=(JAVA/'TutorialOverlay.java').read_text()
    for phrase in ['TUTORIAL MODE  ·  OFFLINE', 'Novice Adventurer', 'DEPTH', "WHAT'S HAPPENING",
                   'Actions', 'explainCurrent()', 'showInventory()', 'addChoiceRow', 'moreOptions']:
        assert phrase in code,phrase
    assert 'NetHack' in code
    assert 'scenarios' not in code.lower()

def test_wiki_help_inventory_and_menu_ids():
    item=ET.parse(RES/'menu_item.xml').getroot()
    text=item.findall('.//*[@{http://schemas.android.com/apk/res/android}id]')
    ids=[v.attrib['{http://schemas.android.com/apk/res/android}id'] for v in text]
    for label in ['item_acc','item_tile','item_text','item_sub','item_count','item_check','tutorial_item_help']:
        assert '@+id/'+label in ids
    for name in ['dialog_menu1.xml','dialog_menu3.xml']:
        root=ET.parse(RES/name).getroot()
        assert any(v.attrib.get('{http://schemas.android.com/apk/res/android}id')=='@+id/menu_list' for v in root.iter())

def test_no_chatgpt_github_api_calls():
    for file in JAVA.glob('*.java'):
        source=file.read_text()
        assert 'api.openai.com' not in source
        assert 'chatgpt.com' not in source
        assert 'api.github.com' not in source

def test_refresh_clears_stale_inventory():
    p=(JAVA/'StateProbe.java').read_text()
    assert 'currentTurn!=observedTurn' in p
    assert 'invalidateBag()' in p
    ui=(JAVA/'TutorialOverlay.java').read_text()
    assert 'this option is no longer available' in ui

def test_native_commands_suppressed_before_draw():
    ui=(JAVA/'TutorialOverlay.java').read_text()
    assert 'addOnPreDrawListener' in ui
    assert 'child.setAlpha(0f)' in ui
    assert 'lp.width=0;lp.height=0' in ui
    for command in ['20s', 'KEYBOARD', 'Extended commands (#)', 'Show inventory (i)']:
        assert command in ui

def test_monster_species_read_from_tile_data_and_pet_flag():
    state=(JAVA/'StateProbe.java').read_text()
    assert 'MonsterCatalog.fromTile(visualTile)' in state
    assert '(effects & 0x10)' in state
    assert 'new TutorialEngine.Monster(species,pet' in state

def test_monster_catalog_generator_orders_real_tile_ids():
    import tempfile, subprocess
    with tempfile.TemporaryDirectory() as directory:
        root=Path(directory)
        (root/'include').mkdir()
        (root/'win/share').mkdir(parents=True)
        order=['GIANT_ANT','FOX','KITTEN']+['TEST_MONSTER_'+str(i) for i in range(150)]
        (root/'include/monsters.h').write_text('#ifdef MONS_ENUM\n'+',\n'.join('PM_'+x for x in order)+'\n#endif\n')
        (root/'win/share/tilemap.c').write_text('{ MON_GLYPH, PM_FOX, "unused" },')
        subprocess.run(['python3',str(ROOT/'tools/generate_monster_catalog.py'),str(root)],check=True,capture_output=True)
        result=(root/'sys/android/app/src/com/tbd/NetHack5/tutorial/MonsterCatalog.java').read_text()
        assert '"fox"' in result and '"kitten"' in result


def test_floor_objects_are_not_filtered_out_as_non_letters():
    src=(JAVA/'StateProbe.java').read_text()
    assert 'visibleObjectClass(c,visualTile)' in src
    assert "case '$': return \"gold\";".replace('\\"','\"') in src
    assert "case '?': return \"scroll\";".replace('\\"','\"') in src
    assert 'ObjectCatalog.isGroundObjectTile' in src
    assert src.index('String groundKind=visibleObjectClass') < src.index("if(c=='+')s.doorAdjacent")
    ui=(JAVA/'TutorialOverlay.java').read_text()
    assert 'VISIBLE FLOOR OBJECTS' in ui
    assert 'MOVE:' in ui

def test_ground_item_informational_help():
    engine=(JAVA/'TutorialEngine.java').read_text()
    assert 'Pick up what' in engine
    assert 'Move toward' in engine
    assert 'A scroll' not in engine or 'item.category' in engine
    library=(JAVA/'WikiLibrary.java').read_text()
    assert 'Gold pieces on the dungeon floor' in library
    assert 'Unidentified scroll' in library


def test_all_named_ground_objects_resolve_through_library():
    ui=(JAVA/'TutorialOverlay.java').read_text()
    assert 'WikiLibrary.forObservedItem(object.label(),object.category)' in ui
    assert 'card.sourceLabel' in ui
    resolver=(JAVA/'WikiLibrary.java').read_text()
    assert 'return c==null?CARDS.get("unknown")' not in resolver
    assert 'public static Card forObservedItem(String label,String visibleCategory)' in resolver
    assert 'sourceLabel' in resolver
