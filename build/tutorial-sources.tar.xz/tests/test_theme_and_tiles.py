from pathlib import Path
import xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1]
LAY=R/'app/src/main/res'

def test_styles_present():
    f=LAY/'values/tutorial_styles.xml'; root=ET.parse(f).getroot()
    names={s.attrib['name'] for s in root.findall('style')}
    assert {'TutorialTheme','NH_Dialog','ButtonText','DialogText','DialogTitle','ListText1','ListText2','InputText'}<=names
    for path in (LAY/'drawable/tutorial_dialog_panel.xml',LAY/'drawable/tutorial_button_bg.xml'):
        ET.parse(path)

def test_game_question_buttons_retain_native_listeners():
    a=(R/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()
    assert 'labelNativeChoices(map)' in a
    assert 'Yes (y)' in a and 'No (n)' in a and 'Cancel (q)' in a
    assert 'setOnClickListener' not in a[a.index('private void labelNativeChoices'):a.index('private void hideOldCommandPanel')]

def test_original_tileset_options_and_live_reload():
    a=(R/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()
    assert 'R.array.tileNames' in a and 'R.array.tileValues' in a
    assert 'putString("tileset",value)' in a
    assert 'putInt("tileW",width)' in a and 'putInt("tileH",height)' in a
    assert 'state.preferencesUpdated()' in a
    assert 'openOriginalSettings()' in a
    b=(R/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialActivity.java').read_text()
    assert 'startActivityForResult(new Intent(this, Settings.class), 42)' in b

def test_screens_theming_all_game_views():
    overlay=(R/'tools/apply_to_upstream.py').read_text()
    assert '"@style/TutorialTheme"' in overlay
    s=(LAY/'layout/dialog_menu3.xml').read_text()
    assert s.count('style="@style/ButtonText"')==3
