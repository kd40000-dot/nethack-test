package com.tbd.NetHack5.tutorial;

public final class FloorActionGuardTest {
    private static int checks;
    private static void check(boolean value,String description){checks++; if(!value)throw new AssertionError(description);}
    public static void main(String[]args){
        FloorActionGuard guard=new FloorActionGuard();
        check(!guard.blocks(12,5),"No suppression before pickup");
        guard.pickupRequested(12,5,"log:31:You see here a ruby potion.");
        check(guard.blocks(12,5),"Immediate optimistic suppression at old square");
        check(!guard.blocks(13,5),"Unrelated square not suppressed");
        check(!guard.acceptFreshReport(12,5,"log:31:You see here a ruby potion.",true),"Recycled old message cannot revive pickup");
        check(guard.blocks(12,5),"Old message does not clear guard");
        check(!guard.acceptFreshReport(12,5,"log:32:You pick up a ruby potion.",false),"Pickup result is not positive evidence of another floor item");
        check(guard.blocks(12,5),"After successful pickup floor stays suppressed");
        check(!guard.acceptFreshReport(12,5,"log:33:Nothing here to pick up.",false),"No item result does not reenable item");
        check(guard.blocks(12,5),"Empty-floor result does not resurrect tile");
        check(guard.acceptFreshReport(12,5,"log:34:You see here an emerald potion.",true),"New fresh sighting can confirm a remaining pile item");
        check(!guard.blocks(12,5),"New floor report makes another pickup available");
        guard.pickupRequested(12,5,"log:34:You see here an emerald potion.");
        check(guard.blocks(12,5),"Second pickup independently invalidates cache");
        guard.observePosition(12,5);
        check(guard.blocks(12,5),"Staying on tile does not clear guard");
        guard.observePosition(12,6);
        check(!guard.blocks(12,5),"Leaving tile allows new future observation");
        check(!guard.acceptFreshReport(12,5,"log:35:You see here a potion.",true),"No pending guard once moved");
        System.out.println("PASS: "+checks+" live-floor invalidation assertions");
    }
}
