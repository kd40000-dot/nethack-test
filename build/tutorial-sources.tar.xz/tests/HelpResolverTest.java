package com.tbd.NetHack5.tutorial;

public class HelpResolverTest {
    static int passed=0;
    static void yes(boolean condition,String description){if(!condition)throw new AssertionError(description);passed++;}
    static void named(String input,String category,String expectedTitle){
        WikiLibrary.Card c=WikiLibrary.forObservedItem(input,category);
        yes(c.title.toLowerCase().contains(expectedTitle), "Title wrong for "+input+": "+c.title);
        yes(!c.id.equals("unknown"),"Known item falsely unidentified: "+input);
        yes(!c.what.toLowerCase().contains("hasn't been identified"),"Magic-unknown explanation for: "+input);
        yes(c.wikiUrl.startsWith("https://"),"Credible reference missing for "+input);
    }
    public static void main(String[] args) {
        WikiLibrary.Card ammo=WikiLibrary.forObservedItem("7 elven arrows", "weapon");
        yes(ammo.title.equals("Elven arrows"),"Elven arrows retain the display name");
        yes(ammo.stats!=null && ammo.stats.length>=7,"Actual weapons have stats table");
        yes(ammo.what.contains("bow ammunition"),"Projectile description is item-specific");
        yes(ammo.interactions.contains("fire (f)"),"Strategy gives launcher controls");
        yes(!ammo.what.contains("explicitly") && !ammo.what.contains("tutorial"),"No implementation commentary in guide");
        yes(ammo.wikiUrl.endsWith("Elven_arrow"),"Verified per-item wiki page used");
        WikiLibrary.Card mystery=WikiLibrary.forInventoryItem("a scroll labeled YUM YUM");
        yes(mystery.stats==null && mystery.id.equals("scroll"),"Randomized scroll label never resolves");
        named("a leash", "tool", "leash");
        named("an uncursed leash", "tool", "leash");
        named("a blessed +1 leash", "tool", "leash");
        named("2 leashes", "tool", "leash");
        named("a magic whistle", "tool", "magic whistle");
        named("a towel", "tool", "towel");
        named("a saddle", "tool", "saddle");
        named("a magic marker", "tool", "magic marker");
        named("a skeleton key", "tool", "keys");
        named("a tin opener", "tool", "tin opener");
        named("a food ration", "food", "food ration");
        named("a kobold corpse", "corpse", "corpse");
        named("a scroll of identify", "scroll", "scroll of identify");
        named("a potion of object detection", "potion", "potion of object detection");
        named("a wand of teleportation", "wand", "wand of teleportation");
        named("an uncursed ring of protection", "ring", "ring of protection");
        named("an amulet of ESP", "amulet", "amulet of esp");
        named("a splint mail", "armor", "splint mail");
        named("a lock pick", "tool", "keys");
        named("a bag of holding", "tool", "bag");
        named("a purple worm tooth", "weapon", "purple worm tooth");
        named("a widget", "tool", "widget");
        yes(WikiLibrary.forObservedItem("tool","tool").id.equals("tool"),"Generic map tile is a category, not a named known tool");
        yes(WikiLibrary.forObservedItem("scroll","scroll").id.equals("scroll"),"A map tile can't reveal a scroll type");
        yes(WikiLibrary.forObservedItem("gem","gem").id.equals("gem"),"A map tile can't reveal the actual gem");
        yes(WikiLibrary.forObservedItem("5 gold pieces","gold").id.equals("gold"),"Gold uses known category help");
        yes(WikiLibrary.forInventoryItem("a pink potion").id.equals("potion"),"Randomized appearance not identified");
        yes(WikiLibrary.forInventoryItem("an uncursed scroll labeled DAIYEN FOOELS").id.equals("scroll"),"Randomized scroll label not exposed");
        yes(WikiLibrary.forInventoryItem("an oak wand called zappy").id.equals("wand"),"User nickname not treated as identification");
        yes(WikiLibrary.forInventoryItem("a silver ring").id.equals("ring"),"Ring appearance remains unidentified");
        yes(WikiLibrary.forInventoryItem("a spellbook labeled VE FORBRYDERNE").id.equals("spellbook"),"Spellbook appearance remains unidentified");
        yes(WikiLibrary.get("unexpected-topic").id.equals("inventory"),"Missing topic must not claim mystery");
        yes(WikiLibrary.get("unknown").id.equals("unknown"),"Genuine unknown has explicit representation");
        yes(WikiLibrary.categoryForObservedName("a leash").equals("tool"),"Leash tool category");
        yes(WikiLibrary.categoryForObservedName("a string").equals("object"),"No false ring match in string");
        yes(WikiLibrary.categoryForObservedName("a spring").equals("object"),"No false ring match in spring");
        GroundMessage.Seen floor=GroundMessage.parse("You see here a leash.");
        yes(floor!=null && floor.name.equals("leash") && floor.category.equals("tool") && floor.topic.equals("leash"),"Ground name and topic");
        yes(WikiLibrary.forMessage("You see here a leash.").id.equals("leash"),"Message router to known tool");
        yes(WikiLibrary.forObservedItem("a wand of cancellation","wand").sourceLabel.contains("Guidebook"),"Official guide fallback");
        System.out.println("PASS: "+passed+" global help resolver assertions");
    }
}
