package com.tbd.NetHack5.tutorial;
import java.util.Arrays;

public class ContextualDoorTest {
    private static int checks=0;
    static void ok(boolean x,String message){if(!x)throw new AssertionError(message); checks++;}
    static boolean has(TutorialEngine.Advice advice,String command){
        for(TutorialEngine.Choice c:advice.choices)if(c.command.equals(command))return true;
        return false;
    }
    public static void main(String[] args){
        TutorialEngine.State state=new TutorialEngine.State();state.gameReady=true;
        TutorialEngine.Door west=new TutorialEngine.Door(-1,0);
        TutorialEngine.Door north=new TutorialEngine.Door(0,-1);
        ok(west.direction().equals("west"),"west orientation");
        ok(north.direction().equals("north"),"north orientation");
        try{new TutorialEngine.Door(1,1);throw new AssertionError("Diagonal door should fail");}
        catch(IllegalArgumentException expected){checks++;}
        state.doorAdjacent=true;state.adjacentDoors.add(west);
        TutorialEngine.Advice advice=TutorialEngine.assess(state);
        ok(advice.title.equals("Closed door nearby"),"closed door primary advice");
        ok(advice.choices.get(0).label.contains("west"),"one visible door gets direction label");
        ok(has(advice,"o"),"normal open door command preserved");
        state.adjacentDoors.add(north);
        advice=TutorialEngine.assess(state);
        ok(advice.choices.get(0).label.equals("Choose a door to open"),"two doors require selection");
        state.hp=1;state.maxHp=12;
        ok(!has(TutorialEngine.assess(state),"o"),"danger overrides door activity");
        state.hp=12;state.itemHere=true;
        state.groundItems.add(new TutorialEngine.GroundItem("potion",0,0));
        ok(has(TutorialEngine.assess(state),","),"item underfoot outranks nearby doors");
        state.itemHere=false;state.groundItems.clear();
        state.inventoryKnown=true;state.knownInventory=Arrays.asList("a - a skeleton key");
        state.recentMessage="This door is locked.";
        ok(has(TutorialEngine.assess(state),"M-u"),"locked door can be checked for traps");
        ok(has(TutorialEngine.assess(state),"a"),"unlock tool only with proven inventory");
        System.out.println("PASS: "+checks+" adjacent-door action assertions");
    }
}
