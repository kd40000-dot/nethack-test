from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
ENG = (ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialEngine.java').read_text()
UI = (ROOT/'app/src/main/java/com/tbd/NetHack5/tutorial/TutorialOverlay.java').read_text()

def test_untrap_atomic_direct_key():
    assert '"M-u","door",false' in ENG
    assert '"#untrap"' not in ENG
    assert 'if(command.equals("M-u"))' in UI
    assert 'modifiers.add(Input.Modifier.Meta)' in UI
    assert "char untrap='u'" in UI
    assert 'Input.nhKeyFromMod(untrap,modifiers)' in UI
    assert 'handler.postDelayed(this::refresh,250)' in UI
    assert 'command+"\\n"' in UI  # generic extended commands preserved
    assert UI.index('if(command.equals("M-u"))') < UI.index('if(command.startsWith("#")&&command.length()>1)')

def test_door_action_available_only_on_locked_door():
    assert 'if (s.doorAdjacent && lockedEvidence)' in ENG
    assert 'then choose the direction of the door' in ENG
    assert 'Not all traps can be detected' in ENG
