# Build status — NetHack 5 Guided Tutorial UI (October 9, 2026)

## Implemented in Android source

- A native Android status/header panel that follows the colors, sizes, labels, and order of the HTML preview: tutorial overline; weapon portrait; hero status and HP meter; depth; persistent round '?' help button.
- Real game map in the middle, using ForkFront/NetHack's actual renderer and touch interactions; there are NO dummy maps or mock scenes in the Android app.
- The preview's bottom 'WHAT'S HAPPENING' panel, contextual action rows, adjacent '?' buttons, list of additional valid choices, risk confirmation, and inventory / explanation footer.
- Bottom-sheet offline wiki summaries with uses, combinations, cautions and source URLs.
- Native NetHack inventory rows decorated with a per-item '?' button, and dark inventory menus.
- Conservative read-only introspection of existing UI state; item availability is based on observed inventory and invalidated on new turns, messages or movement.
- Pure-Java tutorial rule engine plus 33 wiki-inspired summary cards.
- No ChatGPT/OpenAI API, no GitHub integration in the application, no tracking.

## Verification performed

- `TutorialEngineTest`: 7 assertions passed.
- `WikiLibraryTest`: 6 assertions passed; reference library contains 33 cards.
- Pytest: 5 tests passed across overlay injection and new UI-contract checks.
- All three resource layouts parse as XML.
- Android-specific Java files compile against *hand-authored API/ForkFront stubs* to detect Java type/syntax mistakes. THIS IS NOT equivalent to an Android SDK build.

## Not yet verified / not complete

- Not built into an Android APK. No Android SDK/NDK or complete upstream source is available in this environment.
- Need Android Gradle compile, asset/resource merge, native build, game startup, menu selection testing, orientation testing, sound/touch and Fairphone 6 testing.
- Truly strict eligibility of every action requires a native read-only state/capabilities bridge: the existing frontend cannot tell which inventory items/equipment are current at all times, and map tile symbols alone cannot distinguish all doors, traps, and creatures. The overlay deliberately suppresses choices without evidence; it cannot yet guarantee every offered action succeeds.
- HTML `offline-ui-preview.html` remains a self-contained demo, NOT the real NetHack engine.
- Keep the old save data: an APK signed with a new key will not install as a normal update over old CI debug APKs. Follow data-preserving migration instructions after building/saving a permanent keystore.

For original source and further next steps see README.md and ARCHITECTURE.md.
