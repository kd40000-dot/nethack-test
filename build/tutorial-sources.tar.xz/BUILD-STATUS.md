# NetHack Tutorial v50042 build status

Source fix: post-pickup UI invalidation; remove stale game-message pickup
eligibility; require an actual new floor observation to reoffer a pickup.

Local tests: pure-Java FloorActionGuardTest (15 assertions) + context, menu,
input, Java and Python regression checks. Full Android CI still required.

Future builds use the existing pinned public test signing certificate.
