# NetHack 5 Tutorial Mode — UX / stability audit (v50043)

## Implemented

- **Door targeting:** the tutorial uses only rendered, cardinally adjacent *closed* doors. One verified door is selected automatically; two or more show a themed direction picker. The game must enter its real native direction-request state before a direction is sent. A failed command will not cause an unintended movement keystroke.
- **Modal action hardening:** actions shown in the expanded Actions menu are re-evaluated before dispatch and (for risky actions) again at final confirmation. Disappeared objects, changed doors, old inventory or invalid stairs refuse activation.
- **Contextual command menu:** conditional door, container/loot, underfoot, stair, inventory, equipment, potions, scrolls, food, wand, tool, quiver and exploration commands. General settings and full extended-command keyboard remain reachable as an escape hatch.
- **Visual polish:** system-tinted native action icons, recognizable floor-object pictograms, themed compass direction buttons, consistent action sections, improved header text room, descriptive labels and accessible content descriptions.
- **Crash tolerance:** one unexpected tutorial view/reflection exception during refresh is logged and the native game remains playable; subsequent refreshes can recover automatically. Asynchronous UI callbacks are ignored after the activity stops.
- **Game semantics:** all movement/equipment/loot/action commands execute in the actual NetHack engine. Known item appearances never reveal hidden randomized identities. Danger cases remain marked as risky and require confirmation.

## Code audited and highest-risk limitations

- **Critical:** Native NetHack and ForkFront input lifecycles are asynchronous. Previously queued multi-key commands could be interpreted by a later prompt. New *door* actions wait for a genuine native direction request instead of blindly pushing a second key. Rare advanced extended commands still use the original port's key sequence system; the tutorial cannot guarantee that arbitrary multi-step commands will never race.
- **High:** `StateProbe` reads the *displayed* map/status/inventory via reflection, not a native, atomic authoritative state snapshot. It cannot know hidden traps, whether an unidentified item is usable, exact active abilities, or all game-specific command preconditions. The UI hides dependent actions when evidence is unavailable rather than inventing them. A full native read-only capability bridge remains future work.
- **High:** A changing inventory is not assumed reliable after game turns. Action eligibility is rechecked on demand, but live weapon/armor/equipment status can still lag when the original port has not surfaced its inventory window.
- **Medium:** The original game still owns some complex nested prompts and equipment screens. Their styles are themed, but not all of them have equivalent custom tutorial panels yet.
- **Medium:** No device/emulator automation here verifies a multi-hour play session, keyboard focus, rotation, auto-saving, or all native dialogs. CI compilation and focused state-model regressions are not a substitute for device tests.
- **Security:** The repeatable public project test-signing certificate permits normal install-over updates but is not a private production signing identity.

## Test focus

- One north/west closed door; two-door choice; diagonal walls do not count as doors.
- Verified key vs no known inventory; dangerous kick suppressed during nearby threats or critical HP.
- Floor item underfoot beats a nearby door; former item pickup correctly disappears.
- Stale contextual menu actions cannot trigger when a door, stair or inventory item changes.
- Native direction answer only after `showDPad`, no unconditional second movement key.
- No runtime account/network dependence, no user-facing source-implementation messages.
- Full ARM64 native and Android resource/signing pipeline, including existing help/stale-floor regression suite.
