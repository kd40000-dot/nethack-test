# NetHack 5 — offline beginner tutorial mode (local source prototype)

**STATUS: REAL-GAME ANDROID TUTORIAL SOURCE INTEGRATION + TESTED OFFLINE PREVIEW. NOT YET A COMPILED APK.**

This experiment replaces the prior NetHack Android ChatGPT/Fennec/large-command-toolbar overlay with a locally running beginner tutorial. It contains **no GitHub integration, no ChatGPT dependency, no API calls, and no analytics**. The game itself is still the real NetHack engine; this patch only changes the Android front end.

## Intended player experience

- A close recreation of the interactive preview: **hero + HP meter + depth + ?** at the top, the actual live NetHack map in the center, a dark **WHAT'S HAPPENING** panel below, clear options with their own **?** buttons, and offline wiki sheets that slide up from the bottom.
- Persistent **? Help** affordance on the gameplay surface.
- A short description of what the game has *confirmed* and the next sensible action. Help never consumes a game turn.
- Contextual actions only: HP danger; hunger; nearby monsters; doors; items; stairs; exploration. Unrelated commands disappear.
- Explanations attached to each proposed action, with warning/confirmation for overtly risky actions.
- A **?** button inside inventory/menu rows, linking the item to an **offline, originally written encyclopedia summary**. Each card explains what it is, uses, possible combinations, dangers, and a URL to the NetHackWiki source article.
- Conservative identification: an unknown pink potion or scroll label is **not** translated into an identified magical item.
- Item-dependent actions such as unlocking only appear after the game has displayed relevant inventory information. Inventory observations are invalidated by tutorial actions that might change inventory, and the game remains authoritative.
- A first-run walkthrough; no unsolicited player movement, item use, or native commands.

## What's present

- `TutorialEngine.java`: offline rule-based suggestions, with eligibility tests.
- `WikiLibrary.java`: 33 concise offline topic/item cards with deep links to the wiki (original summaries, not copied page text).
- `StateProbe.java`: read-only reflection on the forked Android frontend's *displayed* status/map/log, plus menu item captions; does **not** inspect unrevealed dungeon rooms.
- `TutorialOverlay.java`: the preview-inspired native Android HUD, persistent ?, live hero/HP/depth labels, scrolling contextual choices, offline help sheets, real inventory entry help, and confirmation for risky actions.
- `TutorialActivity.java`: replacement Android launch activity extending upstream `ForkFront`.
- `menu_item.xml`: extended native inventory item row with an extra ? button.
- `tools/apply_to_upstream.py`: applies the patch to **local** NetHack source tree only. Does not communicate with GitHub.
- `offline-ui-preview.html`: standalone interactive **mock game-state** demonstration, open offline in a browser such as Fennec. This is NOT a playable NetHack engine. It previews the locked-door, hunger, low-HP and unknown-item tutorial flows.
- `preview-screenshot.png`: screenshot of the demo interface.

## Gaps and future engineering before release

1. **Not compiled or run against the actual Android APK** in this environment. The Android SDK/NDK and full upstream source were unavailable. The Android Java sources passed a type-check against self-written API stubs (which cannot replace an SDK build), and the pure-Java decision engine passed its tests. Gradle resource merging, JNI startup, emulator play, and device behavior remain unverified.
2. Access to actual native NetHack *inventory, worn equipment, and door lock/trap knowledge* is limited by the existing ForkFront frontend. Java observes inventory after the player opens it, but **cannot guarantee it stays fresh after every native change** (e.g. a monster steals a carried key). To honestly meet “never show actions I can't perform,” a read-only, game-thread-safe native C → Java state bridge is required, reporting only player-knowledge-visible data and invalidating suggestions whenever the game changes.
3. Item ? integration uses a cautious reflective hook to `NHW_Menu` and a replacement item layout. Native inventory layouts are now themed like the preview. Needs physical-device confirmation that touch selection, long-press counts, and scrolling remain intact.
4. The tutorial currently supplies **33 topics**, not the whole NetHackWiki corpus. More article coverage, message-pattern coverage, monster resistances, altar interactions, doors and object combinations are still needed.
5. Advanced mechanics, rare statuses and situations need explicit version-5 compatibility tests. Wiki pages sometimes describe 3.6 or 3.7, not necessarily 5.0.
6. Existing Android signing certificates remain incompatible with earlier ephemeral CI debug APKs. Keeping the application ID does **not** solve that. Do not uninstall an old app without backing up game saves and settings first.

## Build locally (requires Android toolchain)

Start with a clean, locally available `JodiJodington/NetHack-Android` source tree matching the original game. Keep a backup of the tree.

```sh
python3 tools/apply_to_upstream.py /path/to/NetHack-Android
```

Build NetHack for Android using upstream `sys/android/README.md`, the Android SDK and NDK matching its Makefiles, and Gradle. Typical assembly after the native library and assets have been built:

```sh
cd /path/to/NetHack-Android/sys/android
./gradlew :app:assembleDebug
```

A locally built unsigned/ephemeral-debug APK may not install over previously signed NetHack. For future seamless upgrades, sign **all** builds with the same securely stored private signing keystore. Keep the key and password backed up.

## Testing the independently runnable pieces

```sh
javac -d /tmp/nethack-test \
  app/src/main/java/com/tbd/NetHack5/tutorial/{TutorialEngine,WikiLibrary}.java \
  tests/TutorialEngineTest.java tests/WikiLibraryTest.java
java -cp /tmp/nethack-test TutorialEngineTest
java -cp /tmp/nethack-test WikiLibraryTest
python3 -m pytest -q tests/test_overlay.py
```

The browser demo was exercised with headless Chromium to test scenario switching, help sheets, inventory ?, eating and low-HP advice.

## Sources and attribution

Game: NetHack 5 (upstream NetHack General Public License) and JodiJodington's Android frontend. This patch doesn't include the native NetHack source or executable.

References: [NetHackWiki](https://nethackwiki.com/wiki/) contributors, in particular [Door](https://nethackwiki.com/wiki/Door), [Unlocking tool](https://nethackwiki.com/wiki/Unlocking_tool), [Identification](https://nethackwiki.com/wiki/Identification), [Food](https://nethackwiki.com/wiki/Food), [Beginners' guide](https://nethackwiki.com/wiki/Beginners%27_guide), and article URLs embedded in each card. NetHackWiki content is generally [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/), subject to exceptions: https://nethackwiki.com/wiki/NetHackWiki:Copyrights. Our cards are newly authored summaries, not verbatim mirrors. Version-specific claims require source-code checks.

## v50033: exact floor names

The newest explicit `You see here a lichen corpse` message now links to the
current player coordinate and supersedes generic `food` tile help. A named
lichen-corpse wiki card explains food safety, nutrition, and pet uses.
Stale evidence is cleared on movement and item removal; unidentified effects
are not guessed.


## v50034: Global known-item help fallback

The offline resolver treats an observed object name as **known** when the game
explicitly displays it, even if our prewritten card set lacks that name.
It first uses verified item-specific advice; otherwise it uses the visible
object class and the NetHack 5.0 Guidebook/source as cautious references.
A truly unidentified appearance (e.g. a pink potion or a scroll *labeled*
with arbitrary text) only gets category help and does not leak the randomized
underlying effect.

The native NetHack game remains authoritative. For any object with missing
verified mechanics, the tutorial gives the exact name, possible class-level
commands and clearly labels its coverage limitations rather than inventing
spells, recipes or combinations. The source link for dynamic fallbacks is
https://nethack.org/v500/Guidebook.html and the full game code is at
https://github.com/NetHack/NetHack/tree/NetHack-5.0.

Dedicated reference cards for leash, whistle, magic whistle, towel, blindfold,
saddle, mirror, magic marker, touchstone, bags, and food rations were reviewed
against the official NetHack 5.0 implementation and the relevant community
NetHackWiki entries. Unit tests check that 'leash' isn't routed to an
unknown-magical-item card, that random scroll labels stay unidentified, and
that all missing topic IDs fall back gracefully.
