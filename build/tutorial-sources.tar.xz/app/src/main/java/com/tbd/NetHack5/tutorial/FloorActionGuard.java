package com.tbd.NetHack5.tutorial;

/** Prevents a pre-pickup floor observation from being advertised as live.
 *  NetHack message history and its rendered player tile are NOT floor inventory.
 *  Once pickup begins, the same square needs a NEW game observation or a
 *  fresh visit before we can offer another pickup. Handles partial piles.
 */
final class FloorActionGuard {
    private boolean waitingForNewEvidence;
    private int x, y;
    private String eventAtPickup="";

    void pickupRequested(int px, int py, String currentLogEvent) {
        x=px; y=py;
        eventAtPickup=currentLogEvent==null?"":currentLogEvent;
        waitingForNewEvidence=true;
    }

    void observePosition(int px, int py) {
        if(waitingForNewEvidence && (px!=x || py!=y))waitingForNewEvidence=false;
    }

    /** True when old tile/message evidence must not offer a second pickup. */
    boolean blocks(int px, int py) {
        return waitingForNewEvidence && px==x && py==y;
    }

    /** Only a NEW affirmative report can re-enable an item on that square. */
    boolean acceptFreshReport(int px,int py,String eventToken,boolean saysItemRemains) {
        if(!blocks(px,py) || !saysItemRemains) return false;
        if(eventToken==null || eventToken.isEmpty() || eventToken.equals(eventAtPickup))return false;
        waitingForNewEvidence=false;
        return true;
    }
}
