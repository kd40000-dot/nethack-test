package com.tbd.NetHack5.tutorial;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Only identifies an object from an explicit message that the game showed.
 * A floor glyph or tile alone never reveals a randomized item identity. */
final class GroundMessage {
    private static final Pattern HERE = Pattern.compile(
        "^\\s*You (?:see|feel) here\\s+(.+?)\\s*[.!]?\\s*$", Pattern.CASE_INSENSITIVE);
    private GroundMessage() {}

    static final class Seen {
        final String name, category, topic;
        Seen(String name, String category, String topic) {
            this.name = name; this.category = category; this.topic = topic;
        }
    }

    static Seen parse(String message) {
        if (message == null) return null;
        Matcher m = HERE.matcher(message.trim());
        if (!m.matches()) return null;
        String name = m.group(1).trim().replaceFirst("[.!]+$", "").trim();
        name = name.replaceFirst("(?i)^(?:an?|the|some)\\s+", "").trim();
        if (name.isEmpty() || name.equalsIgnoreCase("something")
                || name.length() > 170) return null;
        String low = name.toLowerCase(Locale.ROOT);
        String category=WikiLibrary.categoryForObservedName(name);
        String known=WikiLibrary.specificTopic(name);
        String topic=known!=null?known:category.equals("object")?"inventory":category;
        return new Seen(name,category,topic);
    }

    static boolean invalidates(String message) {
        if (message==null) return false;
        String m=message.toLowerCase(Locale.ROOT).trim();
        return m.contains("you pick up") || m.contains("you have no")
             || m.contains("nothing here to pick up") || m.contains("nothing here")
             || m.contains("you eat") || m.contains("finish eating")
             || m.contains("you drop") || m.contains("you destroy")
             || m.startsWith("things that are here") || m.contains("you see no objects")
             || m.contains("you see here "); // A new floor description supersedes the old one.
    }
}
