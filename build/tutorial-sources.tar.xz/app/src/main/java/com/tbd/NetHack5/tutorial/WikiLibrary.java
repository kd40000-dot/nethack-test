package com.tbd.NetHack5.tutorial;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Offline, ORIGINAL concise explanations based on NetHackWiki; linked pages and authors acknowledged.
 *  Do not infer item identities from randomized appearances. The app should
 *  keep unknown items unknown even when consulting encyclopedia entries. */
public final class WikiLibrary {
    private WikiLibrary() { }
    public static final String LICENSE = "Sources: official NetHack 5.0 Guidebook and game source; " +
        "individual NetHackWiki pages where explicitly linked. The descriptions are " +
        "original summaries, not copied wiki text. The installed game's messages " +
        "take priority over third-party information.";
    private static final String GUIDE_URL = "https://nethack.org/v500/Guidebook.html";
    private static final String GAME_SOURCE = "https://github.com/NetHack/NetHack/tree/NetHack-5.0";
    public static final class Card {
        public final String id, title, what, interactions, cautions, wikiUrl;
        public final String sourceLabel;
        Card(String id,String title,String what,String interactions,String cautions,String url) {
            this(id,title,what,interactions,cautions,
                "NetHackWiki (community reference; verify 5.0 mechanics against the game)",
                "https://nethackwiki.com/wiki/"+url);
        }
        Card(String id,String title,String what,String interactions,String cautions,
             String provenance,String url) {
            this.id=id;this.title=title;this.what=what;this.interactions=interactions;
            this.cautions=cautions;this.sourceLabel=provenance;this.wikiUrl=url;
        }
    }
    private static final Map<String,Card> CARDS = new LinkedHashMap<>();
    private static void put(String id,String title,String what,String interactions,String cautions,String url) {
        CARDS.put(id,new Card(id,title,what,interactions,cautions,url));
    }
    static {
        put("beginner", "Your first turns",
            "NetHack is turn-based. Time normally advances when you act, not when you read these cards. Discover what your character can do before experimenting.",
            "Inspect inventory, read status, observe messages, then explore one step at a time. Use the Help (?) button whenever something changes.",
            "Avoid attacking pets or peaceful creatures. Don't experiment with unidentified magic in emergencies.", "Beginners%27_guide");
        put("commands", "Actions and prompts",
            "Commands are actions like eat, open, apply, and look. Many start a second question asking which item or direction you want.",
            "Use the touchscreen prompts. Cancel with Escape. The tutorial never auto-selects an unknown item for you.",
            "Issuing a second command before finishing the first may be interpreted as a menu answer.", "Commands");
        put("door", "Doors and locks",
            "A + indicates a closed door. It may be unlocked, locked, or trapped, and the glyph alone does not reveal which.",
            "Try open (o) first. If locked: apply (a) a skeleton key, lock pick, or credit card; target the door's cardinal direction. You can also try the untrap command, find another route, or use confirmed unlocking magic. Kicking (Ctrl+D) may smash a door.",
            "Kicking creates noise and can anger guards or shopkeepers. Locked doors may be trapped. A key is not available unless the current inventory confirms one.", "Door");
        put("unlocking", "Keys, picks, and credit cards",
            "These are tools for opening locked doors and certain containers.",
            "Apply the tool, then choose the adjacent locked door. For boxes or chests, apply while on their square. Skeleton keys and lock picks can also lock things; credit cards generally cannot.",
            "Opening a trapped lock can trigger a trap. Never assume the nearby door is locked based only on its + glyph.", "Unlocking_tool");
        put("combat", "Survive encounters",
            "Walking into a hostile creature typically makes a melee attack. A creature you can see may instead be peaceful or your pet.",
            "Inspect the creature before acting. Check HP, your AC, escape routes, and whether your weapon is equipped. Tactical retreat is often safer than fighting.",
            "Even apparently easy fights can turn deadly because unexpected monsters and status effects can change the situation.", "Combat");
        put("fox", "Fox — fast early enemy",
            "A fox is a small canine, usually hostile when generated. In NetHack 5 its speed is 15, faster than many beginning adventurers. It has a 1d3 bite attack and AC 7.",
            "A single fox is less dangerous than some later monsters, but it can get extra opportunities to act while you move. Check HP, choose a safe retreat route and use an already equipped weapon. A pet may help, but don't force it into danger.",
            "Don't assume speed 15 means every player action gets one fox attack; turn order is more complicated. Do not blindly attack a tame fox.", "Fox");
        put("pet", "Pets — your allies",
            "A tame animal follows you, helps fight hostile monsters, and may pick up or bring back items. Tameness represents loyalty, and a surviving pet may grow into a stronger form.",
            "Feed your pet appropriate food, let it fight manageable enemies, and use the swap/displace movement mechanic rather than attacking it. Dogs and cats eat meat; herbivorous pets have different diets.",
            "Hunger, abuse, traps and leaving pets behind can cost you your companion. A visible animal of a pet species is not necessarily tame; look for confirmed pet highlighting.", "Pet");
        put("kitten", "Kitten — your feline companion",
            "A tame kitten is a common starting pet, especially for Wizards. It helps fight monsters, follows you and can grow into a housecat, then a large cat. Its 'f' map symbol alone does not prove it is yours.",
            "Keep it fed with suitable meat or other cat food, let it gain experience, and avoid striking it. Meowing can signal hunger; mewing may mean it will need food soon. Unlike a dog, a kitten grows through the feline family and has feline-specific behavior.",
            "Do not attack or kick your kitten. A wild kitten can be hostile, and a tame kitten can starve or lose loyalty if neglected.", "Kitten");
        put("little dog", "Little dog — your canine companion",
            "The little dog is the other common starting pet. A tame little dog fights for you, follows you and grows into a dog, then a large dog. Its 'd' symbol is shared by foxes, jackals and other canines.",
            "Care for it with suitable meaty food and let it tackle enemies it can defeat. Like a kitten it can accompany you and gather things, but it grows along the canine progression rather than the feline one.",
            "The 'd' glyph by itself never proves a creature is your dog. Do not attack a tame companion or assume a wild little dog is harmless.", "Little_dog");
        put("dog", "Dog — canine creature or companion",
            "Dogs are domestic canines, and a tame dog may have grown up from a little dog. They can help fight threats and accompany you through the dungeon.",
            "Feed tame dogs appropriate meat and avoid hurting them. An encountered wild dog is not automatically your ally. Use pet highlighting to confirm it is tame.",
            "An unidentified 'd' symbol might represent a fox, jackal, wolf or another canine. The specific visual monster tile is more reliable.", "Dog");
        put("housecat", "Housecat — growing feline",
            "A tame kitten can mature into a housecat, a stronger intermediate stage before a large cat.",
            "Protect and feed a tame housecat; let it gain experience against manageable threats. Like kittens, cats are carnivorous pets.",
            "Never infer that all 'f' creatures are tame; jaguars, lynxes and other wild felines use the same class glyph.", "Housecat");
        put("pony", "Pony — possible starting mount",
            "Knights can start with a saddled pony. Ponies can grow into horses and eventually warhorses; they are herbivores, unlike cats and dogs.",
            "Feed suitable vegetarian foods. A properly equipped tame pony can become a riding mount. Learn riding requirements before attempting to mount.",
            "A wild pony is not necessarily tame. Careful handling and suitable food differ from a kitten or dog.", "Pony");
        put("food", "Hunger and eating",
            "Hunger is dangerous. Food rations are typically more predictable than unknown corpses.",
            "Select eat (e) with known food. Corpses can be poisonous, old, or carry special effects. Use a tin opener with a tin if you possess both; some tins can be opened without it.",
            "Don't infer corpse freshness from its appearance. Eating takes time and can be dangerous with nearby monsters.", "Food");
        put("lichen-corpse", "Lichen corpse — reliable food",
            "Your game has identified this as a lichen corpse, not just a generic floor object. Unlike ordinary monster corpses, lichen corpses never rot or become tainted with age and give 200 nutrition in standard NetHack. They are vegan food.",
            "Pick up (,) while standing on it, or eat (e) from the floor when the game offers that choice. Lichen corpses can also feed herbivorous/omnivorous pets, including ponies, and may pacify carnivorous domestic animals.",
            "Eating takes game time and carrying a corpse adds weight. Most OTHER corpses can rot or be dangerous, and details can differ in NetHack 5.", "Lichen");
        put("corpse", "Monster corpses",
            "A corpse may feed you, but risks depend on the monster species, its age, and your resistances.",
            "Inspect the creature type and whether the corpse is fresh. Some corpses grant properties; others can cause poison or sickness.",
            "An unidentified or old corpse is not automatically safe. Avoid treating every corpse as emergency food.", "Corpse");
        put("inventory", "Your inventory",
            "Your bag is more than a list: worn items are different from carried items, and an unidentified item's appearance is not its identity.",
            "Tap an item row's ? for relevant uses and combinations. Wield weapons, wear armor, apply tools, read scrolls, and quaff potions only when appropriate.",
            "A cursed item can be hard to take off. Many magical item appearances are randomized between games.", "Inventory");
        put("identification", "Identifying items",
            "Potion colors, wand materials, scroll labels, ring gems, and many spellbook appearances are randomized each game.",
            "Use in-game identification and observation to learn what you carry. The tutorial shows class-level advice until your inventory explicitly names the item.",
            "Unknown 'pink potion' does NOT mean potion of healing. Trying unidentified consumables is risky.", "Identification");
        put("potion", "Unidentified potion",
            "A potion can have beneficial, dangerous, or context-dependent effects. Its bottle color does not reveal its identity.",
            "Quaff (q) to drink, or use other item interactions once you know the actual type. Identify when possible.",
            "Never assume an unidentified potion is healing. Reading a label/color is not enough.", "Potion");
        put("healing", "Potion of healing",
            "A formally identified healing potion restores some HP, although effects depend on its blessings and the game version.",
            "Quaff (q) this *identified* potion when restoration is useful. Other identified potions may have different healing strengths.",
            "Do not confuse the name with randomized-color unknown potions; the game must explicitly identify it.", "Potion_of_healing");
        put("gold", "Gold pieces on the dungeon floor",
            "The $ symbol indicates coins, commonly called gold pieces. Gold is a visible object, not an unidentified magical item.",
            "Walk onto the gold's square, then use pick up (,) if the game has not collected it automatically. You can spend gold at shops and on some dungeon services. The amount in a pile varies.",
            "Nearby does not mean underfoot. You cannot pick up a pile one square away. A shop may charge for taking merchandise, but ordinary dungeon-floor gold is not automatically shop-owned.", "Gold_piece");
        put("spellbook", "Spellbooks",
            "The + floor symbol can represent a spellbook. Its precise spell may be unidentified.",
            "First move onto its square, then pick it up. Read a spellbook when you have enough time and understand the risks; it teaches spells rather than being an instant scroll.",
            "Reading can take many turns and some books can be dangerous. Never guess a book's exact spell from an unidentified appearance.", "Spellbook");
        put("gem", "Gems and stones",
            "A * floor symbol may be a gem or stone. Different gems look similar and appearances can be misleading.",
            "Pick it up from its own square; identify it later if helpful. Some stones can be applied as tools or thrown.",
            "Unknown stones can be worthless or dangerous; don't assume every gem is valuable.", "Gem");
        put("tool", "Tools on the ground",
            "An ( symbol denotes a tool or related object category; its exact use depends on identification.",
            "Pick it up on its square, then inspect it from inventory. Many tools use apply (a).",
            "Unknown items may be cursed, heavy, or context-dependent.", "Tool");
        put("boulder", "Boulders",
            "The 0 symbol is usually a large rock such as a boulder and can block corridors.",
            "You may be able to push a boulder by walking into it, depending on terrain and strength. Look for pits and special puzzles before pushing.",
            "A boulder isn't a normal portable item. Pushing it may trap you or make passages inaccessible.", "Boulder");
        put("scroll", "Unidentified scroll",
            "Most scroll labels do not identify their effects and are shuffled per game.",
            "Read (r) a scroll only after considering its possible effects; formally identify it when practical.",
            "Reading unidentified scrolls can consume scarce resources or have harmful side effects.", "Scroll");
        put("wand", "Unidentified wand",
            "A wand casts a magical effect, sometimes requiring direction. Wand appearance generally does not reveal the effect.",
            "Zap (z), choose an item, then aim if the game asks. Identify unknown wands before relying on them.",
            "Some wand effects rebound or harm you. A blind zap is not a safe tutorial shortcut.", "Wand");
        put("wand-opening", "Wand of opening",
            "This identified wand can open or unlock certain things, including doors.",
            "Zap it in a suitable direction toward a locked door. You may still need to open the door afterwards.",
            "Requires a confirmed wand of opening; unknown wands aren't offered as substitutes.", "Wand_of_opening");
        put("wand-striking", "Wand of striking",
            "This identified wand can strike creatures and smash a closed door.",
            "Zap in the intended direction. It can break a door as an alternative to kicking.",
            "Noise and collateral damage can matter, especially near shops or guards.", "Wand_of_striking");
        put("ring", "Rings",
            "Rings may grant passive abilities while worn. Most appearance descriptions are randomized.",
            "Use put on (P) to wear a known ring and remove (R) to take one off. Ring slots are limited.",
            "A cursed ring may not come off easily. Unknown ring effects are not guessed.", "Ring");
        put("amulet", "Amulets",
            "Amulets can have powerful effects when worn; many are initially unidentified.",
            "Use put on (P) and remove (R) when possible.",
            "Unknown amulets can have severe side effects. Don't assume they are safe.", "Amulet");
        put("armor", "Armor and AC",
            "Armor reduces vulnerability to physical attacks. In NetHack, a *lower* AC number is generally better.",
            "Use wear (W) to put on, take off (T) to remove, and inspect slots to compare what you actually have equipped.",
            "Putting on armor may cost several turns. A cursed piece may resist removal.", "Armor");
        put("weapon", "Weapons",
            "Weapons vary by type, damage, skill, and special properties. Wielding a weapon does not by itself attack.",
            "Wield (w), then select a weapon. Swap (x) exchanges main and alternate weapons. Ammunition may pair with a launcher.",
            "Some items are cursed or dangerous to wield; avoid swapping gear in the middle of a fight without considering turns.", "Weapon");
        put("missile", "Launchers and ammunition",
            "Bows, crossbows, and similar weapons work with appropriate ammunition.",
            "Equip a matching launcher; prepare the appropriate arrows or bolts and use fire (f), or throw (t) an item deliberately.",
            "Don't assume every projectile works with every launcher. Firing can consume limited ammunition.", "Ranged_attack");
        put("pickaxe", "Pick-axes and digging tools",
            "Digging tools can modify terrain and sometimes break through obstacles.",
            "Apply (a) a pick-axe or related tool and pick a direction when prompted. Some versions also allow breaking doors with an axe-like tool.",
            "Mining can cause noise and other hazards; not all terrain or doors are safely breakable.", "Pick-axe");
        put("lamp", "Lamps and light",
            "A lamp can help reveal dark surroundings when it is lit; fuel or charges are limited depending on the lamp.",
            "Apply (a) to switch on or off. Some oil lamps interact with potions of oil.",
            "Don't assume an unknown lamp is magical or unlimited. Use light conservatively.", "Lamp");
        put("tin", "Tins and tin openers",
            "Tins hold food. The food's identity and effects vary with their contents.",
            "Eat (e) a tin; having an identified tin opener makes opening convenient, although alternatives exist.",
            "The contents may be unexpected. Not every tin is useful in every situation.", "Tin");
        put("tinopener", "Tin opener",
            "A tin opener is an ordinary tool useful for opening tins of food.",
            "Keep it with tins. When you choose to eat a tin, the game can use the opener.",
            "It is not a universal key or a weapon worth relying on.", "Tin_opener");
        put("unicornhorn", "Unicorn horn",
            "This tool interacts with certain adverse conditions and can be useful in some circumstances.",
            "Apply (a) a confirmed unicorn horn when appropriate; effects and reliability depend on enchantment/blessings and game version.",
            "Don't assume it is a universal cure. NetHack 5 behavior should be verified against its rules.", "Unicorn_horn");
        put("stethoscope", "Stethoscope",
            "A stethoscope can reveal useful information about creatures and some objects.",
            "Apply (a), choose an appropriate direction or target, and read the resulting information.",
            "It does not substitute for identifying every magical item.", "Stethoscope");
        put("container", "Chests and boxes",
            "Boxes and chests may hold items, be locked, or be trapped.",
            "Loot (extended command) to inspect contents. Use an unlocking tool on a locked container, or force the lock with risk.",
            "Breaking a container can damage its contents or trigger a trap. Check your surroundings first.", "Container");
        put("stairs", "Stairs and dungeon depth",
            "Stairs connect dungeon levels. Down usually means deeper and potentially greater danger.",
            "Stand on the correct staircase and choose up (<) or down (>). Prepare food and health before descending.",
            "Going deeper too early can strand a weak character among dangerous monsters.", "Stairs");
        put("exploration", "Exploring safely",
            "Explore in small steps rather than running blind into unseen corridors.",
            "Use look (;) to identify visible things; search (s) for secret doors or traps when there is a reason to suspect them.",
            "Blank areas on the cached dungeon map may be unexplored. A glyph can represent different objects or creatures.", "Exploration");
        put("traps", "Traps",
            "Hidden traps can harm, transport, or inconvenience your character. Detecting them takes skill or luck.",
            "Search when suspicious; untrap when an appropriate interactive option is available.",
            "Failing to find a trap does not prove it isn't present.", "Trap");
        put("confusion", "Confusion and stunning",
            "These statuses can make movement or actions unpredictable.",
            "Prioritize avoiding danger until the effect ends or you have a known way to treat it.",
            "Long commands, navigation, and unsafe item use can become especially risky.", "Confusion");
        put("shop", "Shops and guards",
            "Some people and shops react to theft, violence, or property damage.",
            "Look at creatures before fighting. Avoid kicking or smashing doors if a shopkeeper or watchman may see you.",
            "A seemingly harmless destructive action can permanently change how NPCs react.", "Shop");
        // Verified against NetHack 5.0 src/apply.c use_leash(), check_leash():
        // tools must be identified by their displayed name, not inferred from a tile.
        put("leash", "Leash — keep a pet nearby",
            "NetHack has identified an ordinary leash. It is an apply-able tool for keeping a tame pet close, not an unidentified magical object. Leashing limits a companion's movement and can also limit where it fights.",
            "Pick it up if it is on the floor (,), then apply it (a) from your inventory and choose the direction of an adjacent tame pet. Apply the same leash to that pet again to remove it. NetHack 5 normally allows up to two leashed pets.",
            "A cursed leash cannot be removed normally and can choke or kill a pet when stretched. Don't sprint away or drag leashed pets through tight obstacles; leashes are not universally safe or suitable for every monster.", "Leash");
        put("whistle", "Whistle — call nearby pets",
            "An ordinary whistle makes a noise and may attract your pets' attention. It does not teleport them.",
            "Apply it (a); pets may respond to its sound. An identified magic whistle behaves differently and can bring pets adjacent to you.",
            "Noise can wake other creatures. A plain whistle isn't the same as a magic whistle.", "Whistle");
        put("magic-whistle", "Magic whistle — summon pets nearby",
            "A positively identified magic whistle has a special pet-summoning effect.",
            "Apply (a) the magic whistle to bring tame pets close when the effect succeeds.",
            "Only use this explanation when the game actually says magic whistle; an ordinary whistle cannot be assumed to have this property.", "Magic_whistle");
        put("towel", "Towel — clean or cover your face",
            "A towel is an ordinary tool used for cleaning away some material from your face or for covering your eyes.",
            "Apply (a) to use it; its available effects depend on how it is carried or worn.",
            "Do not assume a towel cures blindness caused by magic or injury.", "Towel");
        put("blindfold", "Blindfold — deliberately block vision",
            "A blindfold is a tool that deliberately blinds you while it is worn.",
            "Apply (a) to put it on or remove it. It can be useful for special challenges and certain sensory tactics.",
            "Blinding yourself makes navigation and fighting more difficult, particularly if the blindfold is cursed.", "Blindfold");
        put("saddle", "Saddle — equipment for riding",
            "A saddle equips an appropriate creature for riding. This does not automatically tame or control a wild animal.",
            "Apply (a) to attempt to saddle an adjacent mount. Use the game's #ride command after a suitable tamed or rideable creature is saddled.",
            "Wild creatures may resist. Horse-riding skill and character role matter; removing a saddle is a separate action.", "Saddle");
        put("mirror", "Mirror — reflective tool",
            "A mirror is a tool that can interact with monsters which react to their reflection.",
            "Apply (a) toward a visible direction or target. Its effect depends on the monster you aim it at.",
            "A mirror is not a general attack weapon and can have unexpected effects against certain monsters.", "Mirror");
        put("magic-marker", "Magic marker — write scrolls or books",
            "An identified magic marker is a writing tool with a limited amount of magical ink.",
            "Apply (a) and select appropriate paper, such as a scroll of blank paper, to attempt writing. What you can write depends on knowledge and game rules.",
            "Writing consumes ink, can fail, and is not safe to improvise mid-combat.", "Magic_marker");
        put("touchstone", "Touchstone — examine gems",
            "A touchstone is a tool used to test gems and stones.",
            "Rub a gem against it with the game's rub command when prompted, then read the result. Success and interpretation depend on identification and character properties.",
            "An untested gem's color doesn't prove its identity. Testing the wrong material may not be informative.", "Touchstone");
        put("bag", "Bags — carry other items",
            "Some bags are containers, while special kinds have magical behavior. Their descriptions must be taken literally; not all bags are bags of holding.",
            "Apply a bag (a) to put items into or take items out if the game offers those choices; check its contents before relying on it.",
            "Don't assume an ordinary sack reduces weight or that all magical bags are safe with every item.", "Sack");
        put("flute", "Musical instruments",
            "An instrument can make sound and some identified instruments have special effects.",
            "Apply (a) the instrument. NetHack may ask you to play notes or select an action.",
            "Music can wake monsters. Never assume an unidentified instrument has an additional magical effect.", "Musical_instrument");
        put("food-ration", "Food ration — dependable provisions",
            "A food ration is ordinary carried food. In NetHack it is generally a predictable early source of nutrition.",
            "Pick up (,) if it is on the floor, or eat (e) from your inventory when hungry. Some versions allow eating directly from the floor.",
            "Eating takes game turns. Inspect for nearby enemies before eating.", "Food_ration");
        put("scroll-identified", "Identified scroll — a one-use spell",
            "The game has provided this scroll's magical name. Unlike a scroll 'labeled' with a randomized inscription, 'scroll of ...' identifies its type.",
            "Read (r) the scroll from inventory when you understand and want its effect. It is generally consumed when read.",
            "This card covers scroll commands, not the particular spell's full effects; consult the NetHack 5 reference before consuming one in a dangerous situation.", "Scroll");
        put("potion-identified", "Identified potion — drinkable effect",
            "The game has supplied the potion's type rather than just a randomized color or appearance.",
            "Quaff (q) to drink it, or use specific combinations only if you know their effects.",
            "Identified does not necessarily mean beneficial. This reference cannot guarantee the potion is safe in your circumstances.", "Potion");
        put("wand-identified", "Identified wand — magical tool",
            "The game has supplied this wand's effect name. Wand appearances alone would not establish that name.",
            "Zap (z) and choose a direction or target when the game asks. The precise interaction depends on its confirmed effect.",
            "Some wand effects are dangerous or bounce. Verify the particular spell before testing it in a corridor.", "Wand");
        put("spellbook-identified", "Identified spellbook — learn a spell",
            "The game has provided this book's spell name. Books teach spells rather than acting like single-use scrolls.",
            "Read (r) when safe to spend time studying. Your skill, intelligence and the book's difficulty affect the outcome.",
            "Reading can take multiple turns and a difficult book may be risky.", "Spellbook");
        put("unknown", "I don't know what this is yet",
            "This thing hasn't been identified clearly by the game, or the available item description is too vague.",
            "Inspect it, use the game's discoveries/identification features, and ask for help after the true name is revealed.",
            "The tutorial deliberately refuses to guess an unknown magical item's identity.", "Identification");
    }

    /** Topic resolution must NOT equate "not in our help pack" with "item unidentified". */
    public static Card get(String id) {
        Card c=CARDS.get(id);
        if(c!=null)return c;
        // A typo or unhandled topic is not evidence of a magical mystery.
        return CARDS.get("inventory");
    }
    public static int count() { return CARDS.size(); }
    public static String monsterTopic(String species, boolean pet) {
        String x=species==null?"":species.toLowerCase(Locale.ROOT);
        if(CARDS.containsKey(x))return x;
        if(x.equals("large dog")||x.equals("dog"))return "dog";
        if(x.equals("large cat")||x.equals("housecat"))return "housecat";
        if(x.equals("horse")||x.equals("warhorse"))return "pony";
        return pet?"pet":"combat";
    }

    // NetHack's noun phrases can begin with a count, article, blessing, +n,
    // corrosion, erosion-proofing, or display-only equipment status. These
    // prefixes do not change an object's revealed identity.
    private static final Pattern PREFIX = Pattern.compile(
        "^(?:(?:\\d+|an?|the|some|uncursed|blessed|cursed|greased|"+
        "rustproof|fireproof|fixed|diluted|very|thoroughly|rusty|burnt|"+
        "corroded|rotted|partly eaten|\\+[0-9]+|-[0-9]+)\\s+)+",
        Pattern.CASE_INSENSITIVE);
    private static String clean(String text) {
        if(text==null)return "";
        String x=text.trim().toLowerCase(Locale.ROOT)
            .replaceFirst("\\s*\\((?:being worn|weapon in hand|in quiver|on left hand|on right hand|unpaid|for sale|alternate weapon)[^)]*\\)\\s*$", "");
        String old;
        do { old=x; x=PREFIX.matcher(x).replaceFirst("").trim(); } while(!old.equals(x));
        return x;
    }
    private static boolean containsWord(String text,String word) {
        return Pattern.compile("(?<![a-z])"+Pattern.quote(word)+"(?![a-z])")
            .matcher(text).find();
    }
    private static boolean isLabelOrAppearance(String x) {
        // "labeled" and "called" may be random appearance text or a player
        // nickname. They do NOT reveal the underlying magical effect.
        return x.contains(" labeled ") || (x.contains(" called ") && !x.contains(" of "))
            || x.startsWith("scroll labeled ") || x.startsWith("spellbook labeled ")
            || x.startsWith("scroll called ") || x.startsWith("wand called ")
            || x.startsWith("potion called ") || x.startsWith("ring called ");
    }
    /** Categories describe the displayed OBJECT CLASS, never a randomized effect. */
    public static String categoryForObservedName(String label) {
        String x=clean(label);
        if(x.isEmpty()||x.equals("something")||x.equals("unknown object"))return "object";
        if(x.contains("gold piece")||x.contains("pieces of gold")||x.equals("gold")||x.equals("zorkmid"))return "gold";
        if(x.contains("corpse")||x.contains("corpses"))return "corpse";
        if(x.contains("scroll"))return "scroll";
        if(x.contains("potion"))return "potion";
        if(x.contains("wand"))return "wand";
        if(x.contains("spellbook")||x.contains("book of "))return "spellbook";
        if(containsWord(x,"ring")||containsWord(x,"rings"))return "ring";
        if(containsWord(x,"amulet")||containsWord(x,"amulets"))return "amulet";
        if(x.contains("sword")||x.contains("dagger")||x.contains("mace")||x.contains("spear")||x.contains("axe")||x.contains("bow")||x.contains("arrow")||x.contains("crossbow")||x.contains("bolt")||x.contains("dart")||x.contains("shuriken")||x.contains("whip")||x.contains("staff")||x.contains("trident"))return "weapon";
        if(x.contains("armor")||x.contains("mail")||x.contains("helm")||x.contains("boots")||x.contains("gloves")||x.contains("cloak")||x.contains("shield")||x.contains("robe")||x.contains("shirt"))return "armor";
        if(x.contains("ration")||x.contains("apple")||x.contains("banana")||x.contains("lembas")||x.contains("orange")||x.contains("tripe")||x.contains("meatball")||x.contains("egg")||x.contains("carrot")||x.contains("tin of")||x.equals("tin"))return "food";
        if(containsWord(x,"leash")||containsWord(x,"leashes")||x.contains("whistle")||x.contains("stethoscope")||x.contains("saddle")||x.contains("blindfold")||x.contains("towel")||x.contains("mirror")||x.contains("pick-axe")||x.contains("mattock")||x.contains("lock pick")||x.contains("key")||x.contains("credit card")||x.contains("tin opener")||x.contains("horn")||x.contains("lamp")||x.contains("candle")||x.contains("lantern")||x.contains("magic marker")||x.contains("touchstone")||x.contains("flute")||x.contains("harp")||x.contains("drum")||x.contains("bag")||x.contains("sack")||x.contains("chest")||x.contains("box")||x.contains("camera")||x.contains("bell")||x.contains("tinning kit")||x.contains("figurine"))return "tool";
        if(x.contains("gem")||x.contains("stone")||x.contains("ruby")||x.contains("emerald")||x.contains("diamond"))return "gem";
        return "object";
    }

    /** Stable IDs for cards with researched specific mechanics. */
    public static String specificTopic(String label) {
        String x=clean(label);
        if(x.isEmpty())return null;
        if(x.contains("lichen corpse")||x.contains("lichen corpses"))return "lichen-corpse";
        if(x.contains("corpse"))return "corpse";
        if(x.equals("leash")||x.equals("leashes"))return "leash";
        if(x.equals("magic whistle"))return "magic-whistle";
        if(x.equals("whistle")||x.equals("whistles"))return "whistle";
        if(x.equals("towel")||x.equals("towels"))return "towel";
        if(x.equals("blindfold"))return "blindfold";
        if(x.equals("saddle"))return "saddle";
        if(x.equals("mirror"))return "mirror";
        if(x.equals("magic marker"))return "magic-marker";
        if(x.equals("touchstone"))return "touchstone";
        if(x.equals("food ration")||x.equals("food rations"))return "food-ration";
        if(x.contains("wand of opening"))return "wand-opening";
        if(x.contains("wand of striking"))return "wand-striking";
        if(x.contains("potion of healing"))return "healing";
        if(x.contains("skeleton key")||x.contains("lock pick")||x.contains("credit card")||x.equals("osaku"))return "unlocking";
        if(x.contains("tin opener"))return "tinopener";
        if(x.contains("pick-axe")||x.contains("dwarvish mattock"))return "pickaxe";
        if(x.contains("unicorn horn"))return "unicornhorn";
        if(x.contains("stethoscope"))return "stethoscope";
        if(x.contains("lamp")||x.contains("lantern"))return "lamp";
        if(x.startsWith("tin of ")||x.equals("tin"))return "tin";
        if(x.contains("chest")||x.contains("large box")||x.contains("ice box"))return "container";
        if(x.contains("sack")||x.contains("bag"))return "bag";
        if(x.contains("flute")||x.contains("harp")||x.contains("drum"))return "flute";
        return null;
    }
    private static String classTopic(String category) {
        if(category==null)return "inventory";
        if(category.equals("corpse"))return "corpse";
        if(category.equals("gold"))return "gold";
        if(category.equals("scroll"))return "scroll";
        if(category.equals("potion"))return "potion";
        if(category.equals("wand"))return "wand";
        if(category.equals("spellbook"))return "spellbook";
        if(category.equals("ring"))return "ring";
        if(category.equals("amulet"))return "amulet";
        if(category.equals("weapon"))return "weapon";
        if(category.equals("armor"))return "armor";
        if(category.equals("food"))return "food";
        if(category.equals("tool"))return "tool";
        if(category.equals("gem"))return "gem";
        return "inventory";
    }
    /** Name from the game + category from the visible tile / description. */
    public static Card forObservedItem(String label,String visibleCategory) {
        String x=clean(label);
        String category=categoryForObservedName(label);
        if(visibleCategory!=null && !visibleCategory.equals("object") &&
           (category.equals("object") || !category.equals(visibleCategory) &&
            !category.equals("corpse") && !category.equals("gold")))
            category=visibleCategory;
        String direct=specificTopic(label);
        if(direct!=null)return get(direct);
        // A generic map tile may show only "tool" or "scroll". That is a
        // *category*, not an explicitly observed item name. Treat it as such.
        if(x.equals(category) || x.equals("item") || x.equals("items") ||
           x.equals("object") || x.equals("corpse") || x.equals("gold pieces") ||
           x.equals("gold piece"))return get(classTopic(category));
        boolean magicalCategory=category.equals("scroll")||category.equals("potion")
            ||category.equals("wand")||category.equals("ring")||category.equals("amulet")
            ||category.equals("spellbook");
        // Verified magical type: e.g. "scroll of identify". Appearance-only:
        // "scroll labeled ...", "pink potion", "oak wand". Never guess.
        boolean namedEffect=magicalCategory && !isLabelOrAppearance(x) &&
           (x.startsWith("scroll of ")||x.startsWith("potion of ")||
            x.startsWith("wand of ")||x.startsWith("ring of ")||
            x.startsWith("amulet of ")||x.startsWith("spellbook of ")||
            x.startsWith("book of "));
        if(x.isEmpty()||x.equals("something")||x.equals("unknown object"))
            return get(category.equals("object")?"unknown":classTopic(category));
        if(magicalCategory && !namedEffect) {
            // The displayed *appearance* is known but the effect is not.
            return get(classTopic(category));
        }
        String id="named-"+category;
        Card categoryCard=get(classTopic(category));
        String item=Character.toUpperCase(x.charAt(0))+x.substring(1);
        String kind=category.equals("object")?"object":category;
        String what="NetHack has explicitly displayed the name ‘"+x+"’. This is a known " + kind +
            ", even if this offline help library has no dedicated entry for it. " +
            "General "+kind+" mechanics: "+categoryCard.what;
        String interactions=categoryCard.interactions +
            " This is category-level guidance, not a claim about an unverified special effect.";
        String caution=categoryCard.cautions +
            " Exact effects or combinations not listed here must be checked against the game's own descriptions or the NetHack 5.0 source; do not experiment during combat.";
        if(category.equals("object")) {
            what="NetHack has explicitly identified this floor/inventory object as ‘"+x+"’. " +
                "The offline reference lacks a verified description for this particular name; " +
                "that is a coverage gap, NOT evidence that the object is unidentified or magical.";
            interactions="Pick up (,) only when standing on it, or inspect it from inventory. " +
                "Use NetHack's look/what-is and item-action prompts to establish its category " +
                "before applying, equipping or consuming it.";
            caution="The tutorial does not invent item effects, recipes or combinations when the NetHack 5 code has not been checked.";
        }
        String provenance="Official NetHack 5.0 Guidebook; class mechanics only";
        return new Card(id,item+" — "+kind,what,interactions,caution,provenance,GUIDE_URL);
    }
    public static Card forInventoryItem(String label) {
        return forObservedItem(label,null);
    }

    public static Card forMessage(String msg) {
        String m=msg==null?"":msg.toLowerCase(Locale.ROOT);
        if(m.contains("kitten")||m.contains("housecat"))return get(m.contains("housecat")?"housecat":"kitten");
        if(m.contains("little dog"))return get("little dog");
        if(m.contains("fox"))return get("fox");
        if(m.contains("your dog")||m.contains("the dog"))return get("dog");
        if(m.contains("your pony")||m.contains("the pony"))return get("pony");
        if(m.contains("door")||m.contains("whammm"))return get("door");
        if(m.contains("hungry")||m.contains("weak")||m.contains("faint"))return get("food");
        if(m.contains("lichen corpse")||m.contains("lichen corpses"))return get("lichen-corpse");
        if(m.contains("poison")||m.contains("corpse"))return get("corpse");
        if(m.contains("trap"))return get("traps");
        if(m.contains("confus")||m.contains("stun"))return get("confusion");
        if(m.contains("shopkeeper")||m.contains("watchman")||m.contains("guard"))return get("shop");
        if(m.contains("you see here ")||m.contains("you feel here ")) {
            GroundMessage.Seen floor=GroundMessage.parse(msg);
            if(floor!=null)return forObservedItem(floor.name,floor.category);
        }
        if(m.contains("potion")||m.contains("scroll")||m.contains("wand"))
            return get(m.contains("potion")?"potion":m.contains("scroll")?"scroll":"wand");
        return get("beginner");
    }
}
