package com.tbd.NetHack5.tutorial;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Offline, ORIGINAL concise explanations based on NetHackWiki; linked pages and authors acknowledged.
 *  Do not infer item identities from randomized appearances. The app should
 *  keep unknown items unknown even when consulting encyclopedia entries. */
public final class WikiLibrary {
    private WikiLibrary() { }
    public static final String LICENSE = "Reference: NetHackWiki contributors, https://nethackwiki.com/wiki/ — " +
        "NetHackWiki text is generally CC BY-SA 3.0. These cards are original summaries, " +
        "not verbatim copies. Mechanics may differ in NetHack 5.0.";
    public static final class Card {
        public final String id, title, what, interactions, cautions, wikiUrl;
        Card(String id,String title,String what,String interactions,String cautions,String url) {
            this.id=id;this.title=title;this.what=what;this.interactions=interactions;
            this.cautions=cautions;wikiUrl="https://nethackwiki.com/wiki/"+url;
        }
    }
    private static final Map<String,Card> CARDS = new LinkedHashMap<>();
    private static void put(String id,String title,String what,String interactions,String cautions,String url) {
        CARDS.put(id,new Card(id,title,what,interactions,cautions,url));
    }
    static {
        put("beginner", "Your first turns",
            "NetHack is turn-based. Time normally advances when you act, not when you read these cards. Discover what your character can do before experimenting.",
            "Inspect inventory, read status, observe messages, then explore one step at a time. Use the Help (?) button whenever something changes.",
            "Avoid attacking pets or peaceful creatures. Don't experiment with unidentified magic in emergencies.", "Beginners%27_guide");
        put("commands", "Actions and prompts",
            "Commands are actions like eat, open, apply, and look. Many start a second question asking which item or direction you want.",
            "Use the touchscreen prompts. Cancel with Escape. The tutorial never auto-selects an unknown item for you.",
            "Issuing a second command before finishing the first may be interpreted as a menu answer.", "Commands");
        put("door", "Doors and locks",
            "A + indicates a closed door. It may be unlocked, locked, or trapped, and the glyph alone does not reveal which.",
            "Try open (o) first. If locked: apply (a) a skeleton key, lock pick, or credit card; target the door's cardinal direction. You can also try the untrap command, find another route, or use confirmed unlocking magic. Kicking (Ctrl+D) may smash a door.",
            "Kicking creates noise and can anger guards or shopkeepers. Locked doors may be trapped. A key is not available unless the current inventory confirms one.", "Door");
        put("unlocking", "Keys, picks, and credit cards",
            "These are tools for opening locked doors and certain containers.",
            "Apply the tool, then choose the adjacent locked door. For boxes or chests, apply while on their square. Skeleton keys and lock picks can also lock things; credit cards generally cannot.",
            "Opening a trapped lock can trigger a trap. Never assume the nearby door is locked based only on its + glyph.", "Unlocking_tool");
        put("combat", "Survive encounters",
            "Walking into a hostile creature typically makes a melee attack. A creature you can see may instead be peaceful or your pet.",
            "Inspect the creature before acting. Check HP, your AC, escape routes, and whether your weapon is equipped. Tactical retreat is often safer than fighting.",
            "Even apparently easy fights can turn deadly because unexpected monsters and status effects can change the situation.", "Combat");
        put("food", "Hunger and eating",
            "Hunger is dangerous. Food rations are typically more predictable than unknown corpses.",
            "Select eat (e) with known food. Corpses can be poisonous, old, or carry special effects. Use a tin opener with a tin if you possess both; some tins can be opened without it.",
            "Don't infer corpse freshness from its appearance. Eating takes time and can be dangerous with nearby monsters.", "Food");
        put("corpse", "Monster corpses",
            "A corpse may feed you, but risks depend on the monster species, its age, and your resistances.",
            "Inspect the creature type and whether the corpse is fresh. Some corpses grant properties; others can cause poison or sickness.",
            "An unidentified or old corpse is not automatically safe. Avoid treating every corpse as emergency food.", "Corpse");
        put("inventory", "Your inventory",
            "Your bag is more than a list: worn items are different from carried items, and an unidentified item's appearance is not its identity.",
            "Tap an item row's ? for relevant uses and combinations. Wield weapons, wear armor, apply tools, read scrolls, and quaff potions only when appropriate.",
            "A cursed item can be hard to take off. Many magical item appearances are randomized between games.", "Inventory");
        put("identification", "Identifying items",
            "Potion colors, wand materials, scroll labels, ring gems, and many spellbook appearances are randomized each game.",
            "Use in-game identification and observation to learn what you carry. The tutorial shows class-level advice until your inventory explicitly names the item.",
            "Unknown 'pink potion' does NOT mean potion of healing. Trying unidentified consumables is risky.", "Identification");
        put("potion", "Unidentified potion",
            "A potion can have beneficial, dangerous, or context-dependent effects. Its bottle color does not reveal its identity.",
            "Quaff (q) to drink, or use other item interactions once you know the actual type. Identify when possible.",
            "Never assume an unidentified potion is healing. Reading a label/color is not enough.", "Potion");
        put("healing", "Potion of healing",
            "A formally identified healing potion restores some HP, although effects depend on its blessings and the game version.",
            "Quaff (q) this *identified* potion when restoration is useful. Other identified potions may have different healing strengths.",
            "Do not confuse the name with randomized-color unknown potions; the game must explicitly identify it.", "Potion_of_healing");
        put("scroll", "Unidentified scroll",
            "Most scroll labels do not identify their effects and are shuffled per game.",
            "Read (r) a scroll only after considering its possible effects; formally identify it when practical.",
            "Reading unidentified scrolls can consume scarce resources or have harmful side effects.", "Scroll");
        put("wand", "Unidentified wand",
            "A wand casts a magical effect, sometimes requiring direction. Wand appearance generally does not reveal the effect.",
            "Zap (z), choose an item, then aim if the game asks. Identify unknown wands before relying on them.",
            "Some wand effects rebound or harm you. A blind zap is not a safe tutorial shortcut.", "Wand");
        put("wand-opening", "Wand of opening",
            "This identified wand can open or unlock certain things, including doors.",
            "Zap it in a suitable direction toward a locked door. You may still need to open the door afterwards.",
            "Requires a confirmed wand of opening; unknown wands aren't offered as substitutes.", "Wand_of_opening");
        put("wand-striking", "Wand of striking",
            "This identified wand can strike creatures and smash a closed door.",
            "Zap in the intended direction. It can break a door as an alternative to kicking.",
            "Noise and collateral damage can matter, especially near shops or guards.", "Wand_of_striking");
        put("ring", "Rings",
            "Rings may grant passive abilities while worn. Most appearance descriptions are randomized.",
            "Use put on (P) to wear a known ring and remove (R) to take one off. Ring slots are limited.",
            "A cursed ring may not come off easily. Unknown ring effects are not guessed.", "Ring");
        put("amulet", "Amulets",
            "Amulets can have powerful effects when worn; many are initially unidentified.",
            "Use put on (P) and remove (R) when possible.",
            "Unknown amulets can have severe side effects. Don't assume they are safe.", "Amulet");
        put("armor", "Armor and AC",
            "Armor reduces vulnerability to physical attacks. In NetHack, a *lower* AC number is generally better.",
            "Use wear (W) to put on, take off (T) to remove, and inspect slots to compare what you actually have equipped.",
            "Putting on armor may cost several turns. A cursed piece may resist removal.", "Armor");
        put("weapon", "Weapons",
            "Weapons vary by type, damage, skill, and special properties. Wielding a weapon does not by itself attack.",
            "Wield (w), then select a weapon. Swap (x) exchanges main and alternate weapons. Ammunition may pair with a launcher.",
            "Some items are cursed or dangerous to wield; avoid swapping gear in the middle of a fight without considering turns.", "Weapon");
        put("missile", "Launchers and ammunition",
            "Bows, crossbows, and similar weapons work with appropriate ammunition.",
            "Equip a matching launcher; prepare the appropriate arrows or bolts and use fire (f), or throw (t) an item deliberately.",
            "Don't assume every projectile works with every launcher. Firing can consume limited ammunition.", "Ranged_attack");
        put("pickaxe", "Pick-axes and digging tools",
            "Digging tools can modify terrain and sometimes break through obstacles.",
            "Apply (a) a pick-axe or related tool and pick a direction when prompted. Some versions also allow breaking doors with an axe-like tool.",
            "Mining can cause noise and other hazards; not all terrain or doors are safely breakable.", "Pick-axe");
        put("lamp", "Lamps and light",
            "A lamp can help reveal dark surroundings when it is lit; fuel or charges are limited depending on the lamp.",
            "Apply (a) to switch on or off. Some oil lamps interact with potions of oil.",
            "Don't assume an unknown lamp is magical or unlimited. Use light conservatively.", "Lamp");
        put("tin", "Tins and tin openers",
            "Tins hold food. The food's identity and effects vary with their contents.",
            "Eat (e) a tin; having an identified tin opener makes opening convenient, although alternatives exist.",
            "The contents may be unexpected. Not every tin is useful in every situation.", "Tin");
        put("tinopener", "Tin opener",
            "A tin opener is an ordinary tool useful for opening tins of food.",
            "Keep it with tins. When you choose to eat a tin, the game can use the opener.",
            "It is not a universal key or a weapon worth relying on.", "Tin_opener");
        put("unicornhorn", "Unicorn horn",
            "This tool interacts with certain adverse conditions and can be useful in some circumstances.",
            "Apply (a) a confirmed unicorn horn when appropriate; effects and reliability depend on enchantment/blessings and game version.",
            "Don't assume it is a universal cure. NetHack 5 behavior should be verified against its rules.", "Unicorn_horn");
        put("stethoscope", "Stethoscope",
            "A stethoscope can reveal useful information about creatures and some objects.",
            "Apply (a), choose an appropriate direction or target, and read the resulting information.",
            "It does not substitute for identifying every magical item.", "Stethoscope");
        put("container", "Chests and boxes",
            "Boxes and chests may hold items, be locked, or be trapped.",
            "Loot (extended command) to inspect contents. Use an unlocking tool on a locked container, or force the lock with risk.",
            "Breaking a container can damage its contents or trigger a trap. Check your surroundings first.", "Container");
        put("stairs", "Stairs and dungeon depth",
            "Stairs connect dungeon levels. Down usually means deeper and potentially greater danger.",
            "Stand on the correct staircase and choose up (<) or down (>). Prepare food and health before descending.",
            "Going deeper too early can strand a weak character among dangerous monsters.", "Stairs");
        put("exploration", "Exploring safely",
            "Explore in small steps rather than running blind into unseen corridors.",
            "Use look (;) to identify visible things; search (s) for secret doors or traps when there is a reason to suspect them.",
            "Blank areas on the cached dungeon map may be unexplored. A glyph can represent different objects or creatures.", "Exploration");
        put("traps", "Traps",
            "Hidden traps can harm, transport, or inconvenience your character. Detecting them takes skill or luck.",
            "Search when suspicious; untrap when an appropriate interactive option is available.",
            "Failing to find a trap does not prove it isn't present.", "Trap");
        put("confusion", "Confusion and stunning",
            "These statuses can make movement or actions unpredictable.",
            "Prioritize avoiding danger until the effect ends or you have a known way to treat it.",
            "Long commands, navigation, and unsafe item use can become especially risky.", "Confusion");
        put("shop", "Shops and guards",
            "Some people and shops react to theft, violence, or property damage.",
            "Look at creatures before fighting. Avoid kicking or smashing doors if a shopkeeper or watchman may see you.",
            "A seemingly harmless destructive action can permanently change how NPCs react.", "Shop");
        put("unknown", "I don't know what this is yet",
            "This thing hasn't been identified clearly by the game, or the available item description is too vague.",
            "Inspect it, use the game's discoveries/identification features, and ask for help after the true name is revealed.",
            "The tutorial deliberately refuses to guess an unknown magical item's identity.", "Identification");
    }

    public static Card get(String id) {
        Card c=CARDS.get(id);
        return c==null?CARDS.get("unknown"):c;
    }
    public static int count() { return CARDS.size(); }
    public static Card forInventoryItem(String label) {
        String x=label==null?"":label.toLowerCase(Locale.ROOT);
        // Explicitly named item identity overrides broad randomized classes.
        if(x.contains("wand of opening"))return get("wand-opening");
        if(x.contains("wand of striking"))return get("wand-striking");
        if(x.contains("potion of healing"))return get("healing");
        if(x.contains("skeleton key")||x.contains("lock pick")||x.contains("credit card")||x.contains("osaku"))return get("unlocking");
        if(x.contains("tin opener"))return get("tinopener");
        if(x.contains("pick-axe")||x.contains("dwarvish mattock"))return get("pickaxe");
        if(x.contains("unicorn horn"))return get("unicornhorn");
        if(x.contains("stethoscope"))return get("stethoscope");
        if(x.contains("lamp"))return get("lamp");
        if(x.contains("corpse"))return get("corpse");
        if(x.contains("tin of")||x.contains("a tin")||x.contains("tins"))return get("tin");
        if(x.contains("ration")||x.contains("apple")||x.contains("lembas")||x.contains("banana"))return get("food");
        if(x.contains("potion"))return get("potion");
        if(x.contains("scroll"))return get("scroll");
        if(x.contains("wand"))return get("wand");
        if(x.contains("ring"))return get("ring");
        if(x.contains("amulet"))return get("amulet");
        if(x.contains("helmet")||x.contains("helm")||x.contains("boots")||x.contains("cloak")||x.contains("armor")||x.contains("mail")||x.contains("robe")||x.contains("gloves"))return get("armor");
        if(x.contains("bow")||x.contains("crossbow")||x.contains("arrow")||x.contains("bolt"))return get("missile");
        if(x.contains("sword")||x.contains("dagger")||x.contains("mace")||x.contains("axe")||x.contains("spear"))return get("weapon");
        return get("unknown");
    }
    public static Card forMessage(String msg) {
        String m=msg==null?"":msg.toLowerCase(Locale.ROOT);
        if(m.contains("door")||m.contains("whammm"))return get("door");
        if(m.contains("hungry")||m.contains("weak")||m.contains("faint"))return get("food");
        if(m.contains("poison")||m.contains("corpse"))return get("corpse");
        if(m.contains("trap"))return get("traps");
        if(m.contains("confus")||m.contains("stun"))return get("confusion");
        if(m.contains("shopkeeper")||m.contains("watchman")||m.contains("guard"))return get("shop");
        if(m.contains("potion")||m.contains("scroll")||m.contains("wand"))return get("identification");
        return get("beginner");
    }
}
