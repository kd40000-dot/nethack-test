package com.tbd.NetHack5.tutorial;

import android.os.Bundle;
import android.content.Intent;
import com.tbd.forkfront.Settings;
import com.tbd.forkfront.ForkFront;

/** Native game remains NetHack 5, unchanged. No ChatGPT, GitHub, account, or API dependency. */
public final class TutorialActivity extends ForkFront {
    private TutorialOverlay tutorial;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tutorial = new TutorialOverlay(this);
        tutorial.install();
    }
    /** Opens the original game's preferences, including custom tileset import.
     * ForkFront uses request 42 to re-apply the new tileset on return.
     */
    void openOriginalSettings() {
        startActivityForResult(new Intent(this, Settings.class), 42);
    }
    @Override protected void onResume() {
        super.onResume();
        if (tutorial != null) tutorial.resume();
    }
    @Override protected void onPause() {
        if (tutorial != null) tutorial.pause();
        super.onPause();
    }
}
