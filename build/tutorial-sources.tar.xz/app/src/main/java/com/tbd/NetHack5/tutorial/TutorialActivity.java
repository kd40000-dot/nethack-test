package com.tbd.NetHack5.tutorial;

import android.os.Bundle;
import com.tbd.forkfront.ForkFront;

/** Native game remains NetHack 5, unchanged. No ChatGPT, GitHub, account, or API dependency. */
public final class TutorialActivity extends ForkFront {
    private TutorialOverlay tutorial;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        tutorial = new TutorialOverlay(this);
        tutorial.install();
    }
    @Override protected void onResume() {
        super.onResume();
        if (tutorial != null) tutorial.resume();
    }
    @Override protected void onPause() {
        if (tutorial != null) tutorial.pause();
        super.onPause();
    }
}
