package com.tbd.NetHack5.tutorial;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Pure, testable conservative tutor: never uses hidden state or guesses unidentified item types. */
public final class TutorialEngine {
    private TutorialEngine() { }

    public static final class State {
        public int hp = -1, maxHp = -1;
        public String conditions = "";
        public String recentMessage = "";
        public boolean doorAdjacent;
        public boolean monsterAdjacent;
        public boolean unidentifiedCreatureAdjacent;
        public final List<Monster> nearbyMonsters = new ArrayList<>();
        public boolean itemHere;
        public boolean stairsUpHere, stairsDownHere;
        public boolean inventoryKnown;
        public List<String> knownInventory = Collections.emptyList();
        public boolean inputPromptActive;
        public boolean gameReady;
    }
    public static final class Monster {
        public final String species;
        public final boolean confirmedPet;
        public final int dx, dy;
        public Monster(String name, boolean pet, int x, int y) {
            species=name; confirmedPet=pet; dx=x; dy=y;
        }
    }
    public static final class Choice {
        public final String label, explanation, command, wikiTopic;
        public final boolean risky;
        Choice(String label, String explanation, String command, String wikiTopic, boolean risky) {
            this.label = label; this.explanation = explanation;
            this.command = command; this.wikiTopic = wikiTopic; this.risky = risky;
        }
    }
    public static final class Advice {
        public final String title, explanation, wikiTopic;
        public final List<Choice> choices;
        Advice(String title, String explanation, String wikiTopic, List<Choice> choices) {
            this.title = title; this.explanation = explanation; this.wikiTopic = wikiTopic;
            this.choices = Collections.unmodifiableList(choices);
        }
    }
    private static void add(List<Choice> choices, String title, String text, String cmd, String topic, boolean risky) {
        choices.add(new Choice(title,text,cmd,topic,risky));
    }
    private static boolean contains(String text, String fragment) {
        return text != null && text.toLowerCase(Locale.ROOT).contains(fragment.toLowerCase(Locale.ROOT));
    }
    private static boolean hasVerifiedItem(State s, String... possibleNames) {
        if (!s.inventoryKnown) return false;
        for (String item : s.knownInventory) {
            String t = item.toLowerCase(Locale.ROOT);
            for (String name : possibleNames) if (t.contains(name)) return true;
        }
        return false;
    }
    public static Advice assess(State s) {
        List<Choice> out = new ArrayList<>();
        if (!s.gameReady) {
            return new Advice("Welcome to NetHack", "Start or restore your character. The tutor uses only what your game has shown you.",
                    "beginner", out);
        }
        if (s.inputPromptActive) {
            add(out,"Cancel this choice", "Return to the game without committing the pending command.", "ESC", "commands", false);
            return new Advice("Finish the question on screen", "The game is awaiting a direction or answer. Choose in its dialog or cancel; unrelated actions are hidden.", "commands", out);
        }
        if (s.hp >= 0 && s.maxHp > 0 && s.hp * 3 <= s.maxHp) {
            add(out,"Review your bag", "Look for known healing or escape options. Do not blindly use unidentified potions.","i","inventory",false);
            add(out,"Examine around you", "Look at nearby threats and exits before your next turn.",";","combat",false);
            return new Advice("Danger: very low health", "One unexpected hit might be fatal. Avoid unnecessary attacks, kicks, and long waits. Only take a step after checking what is beside you.","combat",out);
        }
        if (contains(s.conditions,"fainting") || contains(s.conditions,"weak") || contains(s.conditions,"hungry")) {
            if (hasVerifiedItem(s,"food ration","cram ration","lembas wafer","apple","orange","banana","tripe ration","pancake")) {
                add(out,"Eat known food", "Select a known food item. Eating costs time, so check for nearby monsters.","e","food",false);
            }
            add(out,"Check your provisions", "Inspect food in your inventory. Some corpses can poison you; unknown food is not assumed safe.","i","food",false);
            return new Advice("Hunger needs attention", "Hunger progressively weakens your character. Plan to eat a reliably safe food item soon; avoid unverified corpses.", "food",out);
        }
        if (s.monsterAdjacent || s.unidentifiedCreatureAdjacent) {
            Monster focus=null;
            // Prioritize a confirmed non-pet monster before a friendly companion.
            // Without MG_PET, hostility is still unknown: don't call it hostile.
            for(Monster m:s.nearbyMonsters)if(!m.confirmedPet){focus=m;break;}
            if(focus==null && !s.nearbyMonsters.isEmpty())focus=s.nearbyMonsters.get(0);
            if(focus!=null) {
                String species=focus.species;
                String topic=WikiLibrary.monsterTopic(species,focus.confirmedPet);
                String label=Character.toUpperCase(species.charAt(0))+species.substring(1);
                if(focus.confirmedPet) {
                    add(out,"Meet your "+species,"A confirmed tame companion can fight monsters and grow stronger. Learn how to keep it fed and loyal.","HELP:"+topic,topic,false);
                    add(out,"Look around","Inspect another creature or the tile under your feet without attacking your pet.",";","combat",false);
                    return new Advice("Your pet "+species+" is nearby",
                        "The game has marked this "+species+" as tame. Avoid hitting it. Pets follow you, defend you and need care; a kitten can grow into a housecat.",topic,out);
                }
                add(out,"Learn about the "+species,
                    "The visible monster tile identifies a "+species+". Learn its attacks, speed and risks before moving into it.","HELP:"+topic,topic,false);
                add(out,"Inspect the "+species,"Check the creature's position before attacking; a visible species is not proof of hostility.",";",topic,false);
                add(out,"Check equipment","Inspect your weapon and armor before choosing to fight.","i","inventory",false);
                return new Advice(label+" nearby", "A "+species+" is beside you. Its species is confirmed from the visible game tile, but its attitude isn't necessarily known. Avoid attacking peaceful creatures or pets.",topic,out);
            }
            add(out,"Inspect the creature","The visible glyph alone is ambiguous; request more information before fighting.",";","combat",false);
            add(out,"Review your inventory", "Look for a known safe escape or defensive item.","i","inventory",false);
            return new Advice("Unidentified creature nearby", "The map shows a possible creature but its identity is not yet reliable. Look before attacking.","combat",out);
        }
        boolean lockedEvidence = contains(s.recentMessage,"door is locked") || contains(s.recentMessage,"door is securely locked") || contains(s.recentMessage,"locked door");
        if (s.doorAdjacent && lockedEvidence) {
            boolean key = hasVerifiedItem(s,"skeleton key","lock pick","credit card","osaku");
            if (key) add(out,"Use an unlocking tool", "Apply your carried key/pick/card, then select the door's direction. Check for traps first if worried.","a","door",false);
            add(out,"Check the door for traps", "Use the game's untrap command where available; not all traps can be detected.","#untrap","door",false);
            add(out,"Kick the door — risky", "May break it, wake monsters, or anger guards/shopkeepers. Only proceed if you accept these risks.","^d","door",true);
            if (!s.inventoryKnown) add(out,"Check for a key", "The tutor has not confirmed your current inventory. Inspect it to unlock contextual tool suggestions.","i","inventory",false);
            return new Advice("This door appears to be locked", "You can't simply open a locked door. Unlocking is usually quieter than kicking; magic or going around may be options, but they are not offered until you confirm the relevant capability.","door",out);
        }
        if (s.doorAdjacent) {
            add(out,"Try opening the door", "If it is locked, NetHack will tell you. You must select the correct direction.","o","door",false);
            add(out,"Inspect the door", "Read about locks, traps, unlocking, and breaking doors.","HELP:door","door",false);
            return new Advice("Closed door nearby", "A + symbol shows a closed door, not whether it is locked. Try opening it first. If the game reports a lock, the advice will change.","door",out);
        }
        if (s.itemHere) {
            add(out,"Look at what's here", "Identify what the game actually reports on your square.",":","inventory",false);
            add(out,"Pick up", "Take the item only if it's safe to approach and you have carrying capacity.",",","inventory",false);
            return new Advice("Something may be at your feet", "Dungeon symbols can be ambiguous. Use Look first, then decide whether to pick the item up.","inventory",out);
        }
        if (s.stairsDownHere || s.stairsUpHere) {
            if (s.stairsDownHere) add(out,"Descend", "Travel to the next dungeon level. You may not be ready yet.",">","stairs",true);
            if (s.stairsUpHere) add(out,"Go upstairs", "Return to the previous level if permitted.","<","stairs",false);
            return new Advice("You are on stairs", "Stairs are one of the main ways to progress. Check health, food, and equipment before going deeper.","stairs",out);
        }
        add(out,"Inspect surroundings", "Find out what is visible around you.",";","exploration",false);
        add(out,"Open inventory", "Let the tutor learn what items you have.","i","inventory",false);
        return new Advice("Explore carefully", "Choose a known floor tile to move. Look at unknown creatures and objects before interacting with them. The tutorial does not guess what lies in darkness.","exploration",out);
    }
}
