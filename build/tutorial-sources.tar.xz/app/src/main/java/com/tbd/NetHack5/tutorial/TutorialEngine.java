package com.tbd.NetHack5.tutorial;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;

/** Pure, testable conservative tutor: never uses hidden state or guesses unidentified item types. */
public final class TutorialEngine {
    private TutorialEngine() { }

    public static final class State {
        public int hp = -1, maxHp = -1;
        public String conditions = "";
        public String recentMessage = "";
        public boolean doorAdjacent;
        public boolean monsterAdjacent;
        public boolean unidentifiedCreatureAdjacent;
        public final List<Monster> nearbyMonsters = new ArrayList<>();
        public boolean itemHere;
        public final List<GroundItem> groundItems = new ArrayList<>();
        public final List<Stair> visibleStairs = new ArrayList<>();
        public final Set<String> acknowledgedPets = new HashSet<>();
        public boolean stairsUpHere, stairsDownHere;
        public boolean inventoryKnown;
        public List<String> knownInventory = Collections.emptyList();
        public boolean inputPromptActive;
        public boolean gameReady;
    }
    public static final class Monster {
        public final String species;
        public final boolean confirmedPet;
        public final int dx, dy;
        public Monster(String name, boolean pet, int x, int y) {
            species=name; confirmedPet=pet; dx=x; dy=y;
        }
    }
    /** Seen floor object; category only, never its hidden randomized identity. */
    public static final class GroundItem {
        public final String category;
        public final int dx, dy;
        public final boolean underfoot;
        public final String observedName, observedTopic;
        public GroundItem(String category, int dx, int dy) {
            this(category,dx,dy,null,null);
        }
        public GroundItem(String category, int dx, int dy, String observedName, String observedTopic) {
            this.category=category; this.dx=dx; this.dy=dy;
            this.underfoot=(dx==0 && dy==0);
            this.observedName=observedName; this.observedTopic=observedTopic;
        }
        public String label() {
            return observedName!=null && !observedName.isEmpty() ? observedName :
                category.equals("gold") ? "gold" : category;
        }
        public String topic() {
            if(observedTopic!=null)return observedTopic;
            if(category.equals("corpse"))return "corpse";
            if(category.equals("gold"))return "gold";
            if(category.equals("scroll"))return "scroll";
            if(category.equals("potion"))return "potion";
            if(category.equals("wand"))return "wand";
            if(category.equals("food"))return "food";
            if(category.equals("ring"))return "ring";
            if(category.equals("amulet"))return "amulet";
            if(category.equals("armor"))return "armor";
            if(category.equals("weapon"))return "weapon";
            return "inventory";
        }
        public String direction() {
            if(underfoot)return "under your feet";
            String y=dy<0?"north":dy>0?"south":"";
            String x=dx<0?"west":dx>0?"east":"";
            return y.isEmpty()?x:x.isEmpty()?y:y+"-"+x;
        }
    }
    /** A remembered, visibly mapped staircase; location is relative to the hero. */
    public static final class Stair {
        public final int dx, dy;
        public final boolean down;
        public Stair(int dx,int dy,boolean down){this.dx=dx;this.dy=dy;this.down=down;}
        public int distance(){return Math.max(Math.abs(dx),Math.abs(dy));}
        public boolean underfoot(){return dx==0 && dy==0;}
        public String direction(){
            if(underfoot())return "under your feet";
            String ns=dy<0?"north":dy>0?"south":"";
            String ew=dx<0?"west":dx>0?"east":"";
            return ns.isEmpty()?ew:ew.isEmpty()?ns:ns+"-"+ew;
        }
        public String label(){return "Staircase "+(down?"down":"up");}
    }
    public static final class Choice {
        public final String label, explanation, command, wikiTopic;
        public final boolean risky;
        Choice(String label, String explanation, String command, String wikiTopic, boolean risky) {
            this.label = label; this.explanation = explanation;
            this.command = command; this.wikiTopic = wikiTopic; this.risky = risky;
        }
    }
    public static final class Advice {
        public final String title, explanation, wikiTopic;
        public final List<Choice> choices;
        Advice(String title, String explanation, String wikiTopic, List<Choice> choices) {
            this.title = title; this.explanation = explanation; this.wikiTopic = wikiTopic;
            this.choices = Collections.unmodifiableList(choices);
        }
    }
    private static void add(List<Choice> choices, String title, String text, String cmd, String topic, boolean risky) {
        choices.add(new Choice(title,text,cmd,topic,risky));
    }
    private static boolean contains(String text, String fragment) {
        return text != null && text.toLowerCase(Locale.ROOT).contains(fragment.toLowerCase(Locale.ROOT));
    }
    private static boolean hasVerifiedItem(State s, String... possibleNames) {
        if (!s.inventoryKnown) return false;
        for (String item : s.knownInventory) {
            String t = item.toLowerCase(Locale.ROOT);
            for (String name : possibleNames) if (t.contains(name)) return true;
        }
        return false;
    }
    private static String capitalize(String str) {
        return str.isEmpty()?str:Character.toUpperCase(str.charAt(0))+str.substring(1);
    }
    public static Advice assess(State s) {
        List<Choice> out = new ArrayList<>();
        if (!s.gameReady) {
            return new Advice("Welcome to NetHack", "Start or restore your character. The tutor uses only what your game has shown you.",
                    "beginner", out);
        }
        if (s.inputPromptActive) {
            add(out,"Cancel this choice", "Return to the game without committing the pending command.", "ESC", "commands", false);
            return new Advice("Finish the question on screen", "The game is awaiting a direction or answer. Choose in its dialog or cancel; unrelated actions are hidden.", "commands", out);
        }
        if (s.hp >= 0 && s.maxHp > 0 && s.hp * 3 <= s.maxHp) {
            add(out,"Review your bag", "Look for known healing or escape options. Do not blindly use unidentified potions.","i","inventory",false);
            add(out,"Examine around you", "Look at nearby threats and exits before your next turn.",";","combat",false);
            return new Advice("Danger: very low health", "One unexpected hit might be fatal. Avoid unnecessary attacks, kicks, and long waits. Only take a step after checking what is beside you.","combat",out);
        }
        if (contains(s.conditions,"fainting") || contains(s.conditions,"weak") || contains(s.conditions,"hungry")) {
            if (hasVerifiedItem(s,"food ration","cram ration","lembas wafer","apple","orange","banana","tripe ration","pancake")) {
                add(out,"Eat known food", "Select a known food item. Eating costs time, so check for nearby monsters.","e","food",false);
            }
            add(out,"Check your provisions", "Inspect food in your inventory. Some corpses can poison you; unknown food is not assumed safe.","i","food",false);
            return new Advice("Hunger needs attention", "Hunger progressively weakens your character. Plan to eat a reliably safe food item soon; avoid unverified corpses.", "food",out);
        }
        boolean nonPetNearby=s.unidentifiedCreatureAdjacent;
        for(Monster m:s.nearbyMonsters)if(!m.confirmedPet)nonPetNearby=true;
        // A tame companion is informational, not an imminent enemy.
        if (nonPetNearby) {
            Monster focus=null;
            // Prioritize a confirmed non-pet monster before a friendly companion.
            // Without MG_PET, hostility is still unknown: don't call it hostile.
            for(Monster m:s.nearbyMonsters)if(!m.confirmedPet){focus=m;break;}

            if(focus!=null) {
                String species=focus.species;
                String topic=WikiLibrary.monsterTopic(species,focus.confirmedPet);
                String label=Character.toUpperCase(species.charAt(0))+species.substring(1);
                add(out,"Learn about the "+species,
                    "The visible monster tile identifies a "+species+". Learn its attacks, speed and risks before moving into it.","HELP:"+topic,topic,false);
                add(out,"Inspect the "+species,"Check the creature's position before attacking; a visible species is not proof of hostility.",";",topic,false);
                add(out,"Check equipment","Inspect your weapon and armor before choosing to fight.","i","inventory",false);
                return new Advice(label+" nearby", "A "+species+" is beside you. Its species is confirmed from the visible game tile, but its attitude isn't necessarily known. Avoid attacking peaceful creatures or pets.",topic,out);
            }
            add(out,"Inspect the creature","The visible glyph alone is ambiguous; request more information before fighting.",";","combat",false);
            add(out,"Review your inventory", "Look for a known safe escape or defensive item.","i","inventory",false);
            return new Advice("Unidentified creature nearby", "The map shows a possible creature but its identity is not yet reliable. Look before attacking.","combat",out);
        }
        boolean lockedEvidence = contains(s.recentMessage,"door is locked") || contains(s.recentMessage,"door is securely locked") || contains(s.recentMessage,"locked door");
        if (s.doorAdjacent && lockedEvidence) {
            boolean key = hasVerifiedItem(s,"skeleton key","lock pick","credit card","osaku");
            if (key) add(out,"Use an unlocking tool", "Apply your carried key/pick/card, then select the door's direction. Check for traps first if worried.","a","door",false);
            add(out,"Check the door for traps", "Use Untrap (Alt+U), then choose the direction of the door. Not all traps can be detected, and attempts may take a turn.","M-u","door",false);
            add(out,"Kick the door — risky", "May break it, wake monsters, or anger guards/shopkeepers. Only proceed if you accept these risks.","^d","door",true);
            if (!s.inventoryKnown) add(out,"Check for a key", "The tutor has not confirmed your current inventory. Inspect it to unlock contextual tool suggestions.","i","inventory",false);
            return new Advice("This door appears to be locked", "You can't simply open a locked door. Unlocking is usually quieter than kicking; magic or going around may be options, but they are not offered until you confirm the relevant capability.","door",out);
        }
        if (s.doorAdjacent) {
            add(out,"Try opening the door", "If it is locked, NetHack will tell you. You must select the correct direction.","o","door",false);
            add(out,"Inspect the door", "Read about locks, traps, unlocking, and breaking doors.","HELP:door","door",false);
            return new Advice("Closed door nearby", "A + symbol shows a closed door, not whether it is locked. Try opening it first. If the game reports a lock, the advice will change.","door",out);
        }
        if ((s.stairsDownHere || s.stairsUpHere) && !s.itemHere) {
            if (s.stairsDownHere) add(out,"Descend","Go down to the next level. Check supplies and HP first.",">","stairs",true);
            if (s.stairsUpHere) add(out,"Go upstairs","Return to the previous level when permitted.","<","stairs",false);
            return new Advice("Stairs under your feet","You can use these stairs to change dungeon levels, or stay and explore this floor first.","stairs",out);
        }
        if (s.itemHere || !s.groundItems.isEmpty()) {
            GroundItem item=s.groundItems.isEmpty()?null:s.groundItems.get(0);
            if(s.itemHere || (item!=null && item.underfoot)) {
                String label=item==null?"Something":item.observedName!=null?
                        capitalize(item.observedName):item.category.equals("gold")?"Gold":
                        "A "+item.category;
                add(out,item!=null && item.observedName!=null ? "Pick up "+item.observedName : "Pick up what's here",
                    "Pick up an item on this square. NetHack may ask which objects to take.",",",item==null?"inventory":item.topic(),false);
                if(item!=null && "lichen-corpse".equals(item.topic()))
                    add(out,"Eat the lichen corpse", "Lichen corpses are normally safe, non-rotting food. Eating takes turns; check nearby danger first.","e","lichen-corpse",false);
                add(out,"Inspect the floor", "Look at the items under your feet without picking anything up.",":",item==null?"inventory":item.topic(),false);
                return new Advice(label+" at your feet",
                    "You can pick it up or inspect it without taking it. Check nearby creatures before spending a turn handling items.",
                    item==null?"inventory":item.topic(),out);
            }
            String noun=item.category.equals("gold")?"Gold":"A "+item.category;
            String where=item.direction();
            add(out,"Learn about this "+item.category,
                "Read about a visible "+item.category+" without using it or spending a turn.","HELP:"+item.topic(),item.topic(),false);
            if(!item.category.equals("boulder")) add(out,"Move toward "+item.category,
                "The "+item.category+" is one square to your "+where+". Step there only if the square is safe, then pick it up with the action offered on your square.",
                "MOVE:"+item.dx+":"+item.dy,item.topic(),false);
            add(out,"Check your surroundings", "Look for nearby monsters and traps before stepping toward an object.",";","exploration",false);
            return new Advice(noun+" to the "+where,
                "There's "+(item.category.equals("gold")?"gold":"a "+item.category)+" nearby. Step onto its square when safe, then pick it up. Tap ? to learn more before using it.",
                item.topic(),out);
        }
        if (!s.visibleStairs.isEmpty() && !s.stairsUpHere && !s.stairsDownHere) {
            Stair stair=s.visibleStairs.get(0);
            add(out,"Learn about the stairs","Stairs connect dungeon levels. Inspect them without moving or descending.","HELP:stairs","stairs",false);
            add(out,"Check your supplies","Before changing levels, check your HP, food and equipment.","i","inventory",false);
            return new Advice(stair.label()+" to the "+stair.direction(),
                "A staircase is mapped "+stair.distance()+" tile"+(stair.distance()==1?"":"s")+
                " away. Move to it when you're ready; you can change levels only when standing on the stairs.","stairs",out);
        }
        // A companion gets a single introductory tip, then yields to exploration.
        // Its help remains available from the companion row at any time.
        for(Monster pet:s.nearbyMonsters)if(pet.confirmedPet && !s.acknowledgedPets.contains(pet.species)) {
            String topic=WikiLibrary.monsterTopic(pet.species,true);
            add(out,"Meet your "+pet.species,"Find out how to care for this tame companion.","HELP:"+topic,topic,false);
            add(out,"Look around","Check what else is in the room.",";","exploration",false);
            return new Advice("Your pet "+pet.species+" is nearby",
                "This tame companion can help you fight and explore. Learn how to keep it safe and fed.",topic,out);
        }
        add(out,"Inspect surroundings", "Find out what is visible around you.",";","exploration",false);
        add(out,"Open inventory", "Let the tutor learn what items you have.","i","inventory",false);
        return new Advice("Explore carefully", "Choose a known floor tile to move. Look at unknown creatures and objects before interacting with them. The tutorial does not guess what lies in darkness.","exploration",out);
    }
}
