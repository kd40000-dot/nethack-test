package com.tbd.NetHack5.tutorial;

import android.graphics.Point;
import android.content.Context;
import android.view.View;
import android.widget.TextView;
import android.widget.ListView;
import com.tbd.forkfront.ForkFront;
import com.tbd.forkfront.NH_State;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads *only* displayed knowledge from the NetHack UI.
 * Unknown terrain, lock state, unidentified objects etc. are never invented.
 */
final class StateProbe {
    private final TutorialActivity activity;
    private List<String> observedBag=Collections.emptyList();
    private boolean bagCurrent=false;
    private boolean awaitingBag=false;
    private String lastObservedMessage="";
    private TutorialEngine.State previous;
    private int observedTurn=-1;
    private String lastEvidenceMessage="";
    private Point lastMessagePosition;
    private String lastMessageAtPosition="";
    private String logEventToken="";
    private String handledLogEventToken=null;
    private Point lastPlayerPosition;
    private Point confirmedFloorPosition;
    private GroundMessage.Seen confirmedFloorItem;
    private final FloorActionGuard floorGuard=new FloorActionGuard();

    StateProbe(TutorialActivity activity) { this.activity=activity; }
    static Field field(Class<?> cls,String key)throws Exception {
        while(cls!=null) {
            try {Field f=cls.getDeclaredField(key); f.setAccessible(true);return f;}
            catch (NoSuchFieldException e) {cls=cls.getSuperclass();}
        }
        throw new NoSuchFieldException(key);
    }
    static Object get(Object o,String key)throws Exception {return field(o.getClass(),key).get(o);}
    static int id(TutorialActivity activity,String key) {
        for(String namespace:new String[]{activity.getPackageName(),"com.tbd.NetHack5","com.tbd.forkfront"}) {
            int id=activity.getResources().getIdentifier(key,"id",namespace);
            if(id!=0) return id;
        }
        return 0;
    }
    private String viewText(String key) {
        int id=id(activity,key);
        View v=id==0?null:activity.findViewById(id);
        return v instanceof TextView?((TextView)v).getText().toString():"";
    }
    NH_State game() {
        try {
            Field f=ForkFront.class.getDeclaredField("nhState");
            f.setAccessible(true);
            return (NH_State)f.get(null);
        } catch(Exception e) {return null;}
    }
    /** Remember which companion guides the player has already opened.
     *  Only user help interaction can mark a species understood. */
    void markPetExplained(String species) {
        if(!isPetTopic(species))return;
        activity.getSharedPreferences("nethack_tutorial",Context.MODE_PRIVATE).edit()
            .putBoolean("pet_explained_"+species.replace(' ','_'),true).apply();
    }
    static boolean isPetTopic(String species) {
        return species.equals("kitten") || species.equals("housecat") ||
            species.equals("large cat") || species.equals("little dog") ||
            species.equals("dog") || species.equals("large dog") ||
            species.equals("pony") || species.equals("horse") || species.equals("warhorse");
    }
    void expectsBag() {awaitingBag=true;}
    void invalidateBag() {bagCurrent=false; awaitingBag=false; observedBag=Collections.emptyList();}
    /** Called BEFORE sending pickup. The old message and player-covered tile
     * cannot prove there is still something to pick up when it completes. */
    void pickupRequested() {
        if(lastPlayerPosition!=null)
            floorGuard.pickupRequested(lastPlayerPosition.x,lastPlayerPosition.y,logEventToken);
        confirmedFloorItem=null;
        confirmedFloorPosition=null;
    }


    /** The inventory is captured ONLY after opening the game's real inventory.
     *  Do not reuse the cache after an action changes game state. */
    void observeMenu() {
        if(!awaitingBag) return;
        try {
            Object state=game();
            if(state==null)return;
            Object windows=get(state,"mWindows");
            if(!(windows instanceof List))return;
            List<?> w=(List<?>)windows;
            for(int k=w.size()-1;k>=0;k--) {
                Object menu=w.get(k);
                if(!menu.getClass().getName().endsWith("NHW_Menu"))continue;
                if(!Boolean.TRUE.equals(get(menu,"mIsVisible")))continue;
                Object contents=get(menu,"mItems");
                if(!(contents instanceof List))continue;
                List<String> bag=new ArrayList<>();
                for(Object item:(List<?>)contents) {
                    Method selectable=item.getClass().getMethod("isSelectable");
                    if(!Boolean.TRUE.equals(selectable.invoke(item)))continue;
                    Method name=item.getClass().getMethod("getName");
                    String label=String.valueOf(name.invoke(item));
                    if(!label.trim().isEmpty())bag.add(label);
                }
                if(!bag.isEmpty()) {
                    observedBag=bag;bagCurrent=true;awaitingBag=false;
                }
                return;
            }
        }catch(Exception ignored) { /* No invisible inventory guesses. */ }
    }
    List<String> currentMenuItemNames() {
        try {
            NH_State state=game();
            if(state==null)return Collections.emptyList();
            Object windows=get(state,"mWindows");
            if(!(windows instanceof List))return Collections.emptyList();
            List<?> w=(List<?>)windows;
            for(int k=w.size()-1;k>=0;k--) {
                Object menu=w.get(k);
                if(!menu.getClass().getName().endsWith("NHW_Menu"))continue;
                if(!Boolean.TRUE.equals(get(menu,"mIsVisible")))continue;
                Object contents=get(menu,"mItems");
                if(!(contents instanceof List))return Collections.emptyList();
                List<String> labels=new ArrayList<>();
                for(Object item:(List<?>)contents) {
                    Method name=item.getClass().getMethod("getName");
                    labels.add(String.valueOf(name.invoke(item)));
                }
                return labels;
            }
        }catch(Exception ignored) { }
        return Collections.emptyList();
    }
    String latestMessage() {
        try {
            Object state=game();
            if(state==null)return lastObservedMessage;
            Object log=get(get(state,"mMessage"),"mLog");
            int index=((Number)get(get(state,"mMessage"),"mCurrentIdx")).intValue();
            int count=((Number)get(get(state,"mMessage"),"mLogCount")).intValue();
            int len=Array.getLength(log);
            if(len==0)return lastObservedMessage;
            // Ring current index is implementation-specific; scan close slots.
            for(int i=0;i<Math.min(3,len);i++) {
                Object str=Array.get(log,(index-i+len)%len);
                if(str instanceof String&&!((String)str).trim().isEmpty()) {
                    lastObservedMessage=(String)str;
                    logEventToken=count+":"+index+":"+lastObservedMessage;
                    return lastObservedMessage;
                }
            }
        } catch(Exception ignored) { }
        String v=viewText("nh_message");
        if(!v.trim().isEmpty()) {
            lastObservedMessage=v;
            logEventToken="view:"+v;
        }
        return lastObservedMessage;
    }
    /** Screen message belonging to a direction request; does not use old
     * inventory data, cached map symbols, or a historical help message. */
    String visibleDirectionPrompt(){
        String current=viewText("nh_message");
        if(current==null)return "";
        String normalized=current.toLowerCase(java.util.Locale.ROOT);
        return normalized.contains("what direction") ? current : "";
    }
    /** The native port reuses windows and retains input-state flags between
     * actions.  A flag alone is not evidence that a player-facing dialog
     * still exists: inspect the actual visible, attached view instead. */
    static boolean hasVisiblePopup(Object nativeWindow) {
        if (nativeWindow == null) return false;
        try {
            Object ui=get(nativeWindow,"mUI");
            if(ui==null)return false;
            Object root=get(ui,"mRoot");
            if(!(root instanceof View))return false;
            View view=(View)root;
            return view.getParent()!=null && view.isShown();
        }catch(Exception ignored){return false;}
    }

    private boolean activeNativePrompt(NH_State state) {
        try {
            if(hasVisiblePopup(get(state,"mQuestion")))return true;
            if(hasVisiblePopup(get(state,"mGetLine")))return true;
        }catch(Exception ignored){}
        try {
            Object windows=get(state,"mWindows");
            if(windows instanceof List) for(Object window:(List<?>)windows) {
                if(window.getClass().getName().endsWith("NHW_Menu")
                        && hasVisiblePopup(window))return true;
            }
        }catch(Exception ignored){}
        // Only a *visible active* direction pad counts as a direction query.
        // mIsDPadActive can temporarily outlive a cancelled question.
        try {
            if(state.expectsDirection() && state.isDPadVisible()) {
                int viewId=id(activity,"dpad");
                View dpad=viewId==0?null:activity.findViewById(viewId);
                return dpad!=null && dpad.isShown();
            }
        }catch(Exception ignored){}
        return false;
    }

    private static int[] hp(String status) {
        Matcher m=Pattern.compile("\\bHP\\s*:?\\s*(\\d+)\\s*(?:\\(|/)\\s*(\\d+)\\s*\\)?", Pattern.CASE_INSENSITIVE).matcher(status);
        if(m.find())return new int[]{Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2))};
        return new int[]{-1,-1};
    }
    TutorialEngine.State snapshot() {
        TutorialEngine.State s=new TutorialEngine.State();
        NH_State state=game();
        if(state==null)return s;
        s.gameReady=true;
        String status=viewText("nh_stat0")+" "+viewText("nh_stat1");
        // Re-read item evidence after every NetHack turn: monsters can steal,
        // polymorph can affect equipment, and a past menu is not authoritative.
        Matcher turns=Pattern.compile("\\bT\\s*:?\\s*(\\d+)",Pattern.CASE_INSENSITIVE).matcher(status);
        if(turns.find()) {
            try {
                int currentTurn=Integer.parseInt(turns.group(1));
                if(observedTurn>=0 && currentTurn!=observedTurn) {
                    invalidateBag();
                    // A past "You see here" does not prove that this item
                    // survives the next game turn (pickup, pet, trap, etc.).
                    confirmedFloorItem=null;
                    confirmedFloorPosition=null;
                }
                observedTurn=currentTurn;
            } catch(NumberFormatException ignored) {}
        }
        int[] h=hp(status);s.hp=h[0];s.maxHp=h[1];
        s.conditions=status;
        s.recentMessage=latestMessage();
        if(!turns.find(0) && !s.recentMessage.equals(lastEvidenceMessage)) {
            // No numeric turn available: a new game message is a conservative
            // signal that an off-screen event may have changed carried items.
            if(!lastEvidenceMessage.isEmpty())invalidateBag();
        }
        lastEvidenceMessage=s.recentMessage;
        s.inventoryKnown=bagCurrent;
        s.knownInventory=bagCurrent?new ArrayList<>(observedBag):Collections.emptyList();
        s.inputPromptActive=activeNativePrompt(state);
        try {
            Object m=get(state,"mMap");
            Point player=(Point)get(m,"mPlayerPos");
            Object tiles=get(m,"mTiles");
            if(player!=null) {
                // The message log contains *history*, not the live floor state.
                // Bind a freshly displayed "You see here ..." to the player's
                // current map coordinate. Invalidate on movement, pickup/eat,
                // or a new report of what is on this tile. Never label a floor
                // item on a second square using a report from the first.
                boolean moved=lastPlayerPosition!=null && !lastPlayerPosition.equals(player);
                floorGuard.observePosition(player.x,player.y);

                boolean fresh=!logEventToken.equals(handledLogEventToken);
                if(moved) {
                    confirmedFloorItem=null;
                    confirmedFloorPosition=null;
                    if(!fresh) s.recentMessage="";
                }
                if(fresh) {
                    GroundMessage.Seen newItem=GroundMessage.parse(s.recentMessage);
                    if(newItem!=null &&
                        (!floorGuard.blocks(player.x,player.y) ||
                          floorGuard.acceptFreshReport(player.x,player.y,
                                                       logEventToken,true))) {
                        confirmedFloorItem=newItem;
                        confirmedFloorPosition=new Point(player);
                    } else if(GroundMessage.invalidates(s.recentMessage)) {
                        confirmedFloorItem=null;
                        confirmedFloorPosition=null;
                    }
                    handledLogEventToken=logEventToken;
                }
                lastPlayerPosition=new Point(player);
                // A door lock report is only relevant while we remain at
                // the location where it was displayed; do not apply a stale
                // message to a completely different door on a later tile.
                if(lastMessagePosition!=null && !lastMessagePosition.equals(player)) {
                    if(s.recentMessage.equals(lastMessageAtPosition)) s.recentMessage="";
                    invalidateBag();
                    s.inventoryKnown=false;
                    s.knownInventory=Collections.emptyList();
                }
                if(!s.recentMessage.isEmpty()) {
                    lastMessageAtPosition=s.recentMessage;
                    lastMessagePosition=new Point(player);
                }
                char under=glyph(tiles,player.x,player.y);
                s.stairsDownHere=under=='>';
                s.stairsUpHere=under=='<';
                // Visible object *class* is available from the map, even when
                // its randomized item identity has not been discovered.
                // An object on our own tile may be covered by the hero glyph;
                // the game's printed "You see here" message is handled below.
                char onSquare=glyph(tiles,player.x,player.y);
                if(onSquare != ' ' && onSquare!='@') {
                    int ownTile=tileId(tiles,player.x,player.y);
                    String kind=visibleObjectClass(onSquare,ownTile);
                    if(kind!=null && !floorGuard.blocks(player.x,player.y)) {
                        s.groundItems.add(new TutorialEngine.GroundItem(kind,0,0));
                        s.itemHere=true;
                    }
                }
                // Nearby floor landmarks are shown even when an adjacent pet
                // occupies attention. Scan only revealed rendered cells and
                // never interpret blank unexplored cache as known terrain.
                // A map symbol may represent a previously seen staircase,
                // so the UI calls it mapped rather than claiming live vision.
                for(int dy=-6;dy<=6;dy++)for(int dx=-6;dx<=6;dx++) {
                    if(dx==0 && dy==0)continue;
                    char symbol=glyph(tiles,player.x+dx,player.y+dy);
                    if(symbol=='>' || symbol=='<')
                        s.visibleStairs.add(new TutorialEngine.Stair(dx,dy,symbol=='>'));
                }
                s.visibleStairs.sort((a,b)->Integer.compare(a.distance(),b.distance()));
                // NetHack's visual tile id encodes the *actual rendered species*.
                // Unlike the ASCII character 'd', which can mean a fox, jackal,
                // dog, etc., these indices come from the pinned game tilemap.
                // Only inspect the eight visible neighboring map cells.
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
                    if(dx==0 && dy==0)continue;
                    int x=player.x+dx,y=player.y+dy;
                    char c=glyph(tiles,x,y);
                    int visualTile=tileId(tiles,x,y);
                    // 'd' is a creature class; '$' and '?' are OBJECT
                    // symbols and were incorrectly ignored by the old scan.
                    // Validate tile provenance so '+' doors aren't mistaken
                    // for a spellbook and object identity remains concealed.
                    String groundKind=visibleObjectClass(c,visualTile);
                    if(groundKind!=null) {
                        s.groundItems.add(new TutorialEngine.GroundItem(groundKind,dx,dy));
                        continue;
                    }
                    if(c=='+' && Math.abs(dx)+Math.abs(dy)==1){
                        s.doorAdjacent=true;
                        s.adjacentDoors.add(new TutorialEngine.Door(dx,dy));
                    }
                    if(!Character.isLetter(c))continue;
                    Object row=Array.get(tiles,y);
                    Object tile=Array.get(row,x);
                    if(tile==null)continue;
                    String species=MonsterCatalog.fromTile(visualTile);
                    if(species!=null) {
                        short effects=((Number)get(tile,"overlay")).shortValue();
                        // MG_PET (0x10) is provided by the NetHack renderer
                        // when the 'hilite_pet' option is enabled. Absence of
                        // the flag does NOT prove a creature is hostile.
                        boolean pet=(effects & 0x10)!=0;
                        s.nearbyMonsters.add(new TutorialEngine.Monster(species,pet,dx,dy));
                        s.monsterAdjacent=true;
                    } else {
                        // Never interpret a random alphabet glyph as a fox.
                        s.unidentifiedCreatureAdjacent=true;
                    }
                }
            }
        } catch(Exception ignored) { }
        for(TutorialEngine.Monster monster:s.nearbyMonsters)if(monster.confirmedPet && isPetTopic(monster.species)) {
            if(activity.getSharedPreferences("nethack_tutorial",Context.MODE_PRIVATE)
                    .getBoolean("pet_explained_"+monster.species.replace(' ','_'),false))
                s.acknowledgedPets.add(monster.species);
        }
        String message=s.recentMessage.toLowerCase(java.util.Locale.ROOT);
        // The displayed player glyph can cover the underlying staircase.
        // A fresh game message can confirm the stairs when the map cannot.
        if(message.contains("staircase down") || message.contains("stairs down"))s.stairsDownHere=true;
        if(message.contains("staircase up") || message.contains("stairs up"))s.stairsUpHere=true;
        // No itemHere from log history: only map glyph or newly confirmed
        // evidence from this precise square is allowed to enable pickup.
        s.floorPickupUnverified=lastPlayerPosition!=null &&
            floorGuard.blocks(lastPlayerPosition.x,lastPlayerPosition.y);
        if(confirmedFloorItem!=null && confirmedFloorPosition!=null
                && confirmedFloorPosition.equals(lastPlayerPosition) &&
                !floorGuard.blocks(lastPlayerPosition.x,lastPlayerPosition.y)) {
            // The player glyph can hide the underlying item in the map.
            // The exact *displayed* message is better evidence than a broad
            // tile category. Replace category-only information at our feet.
            for(int i=s.groundItems.size()-1;i>=0;i--)
                if(s.groundItems.get(i).underfoot) s.groundItems.remove(i);
            s.groundItems.add(0,new TutorialEngine.GroundItem(
                confirmedFloorItem.category,0,0,confirmedFloorItem.name,
                confirmedFloorItem.topic));
            s.itemHere=true;
        }
        // If a known underfoot object is visible, keep it ahead of nearby objects.
        s.groundItems.sort((a,b)->Boolean.compare(!a.underfoot,!b.underfoot));
        // Prompt state was verified against actually attached UI earlier.

        previous=s;
        return s;
    }
    private static int tileId(Object tiles,int x,int y) throws Exception {
        if(y<0||y>=Array.getLength(tiles))return -1;
        Object row=Array.get(tiles,y);
        if(row==null||x<0||x>=Array.getLength(row))return -1;
        Object tile=Array.get(row,x);
        return tile==null?-1:((Number)get(tile,"glyph")).intValue();
    }
    static String visibleObjectClass(char c,int tile) {
        if(!ObjectCatalog.isGroundObjectTile(tile))return null;
        switch(c) {
            case '$': return "gold";
            case '?': return "scroll";
            case '!': return "potion";
            case '/': return "wand";
            case '=': return "ring";
            case '"': return "amulet";
            case '%': return "food";
            case ')': return "weapon";
            case '[': return "armor";
            case '(': return "tool";
            case '+': return "spellbook";
            case '*': return "gem";
            case '0': return "boulder";
            default: return null;
        }
    }
    static char glyph(Object tiles,int x,int y) throws Exception {
        if(y<0||y>=Array.getLength(tiles))return ' ';
        Object row=Array.get(tiles,y);
        if(row==null||x<0||x>=Array.getLength(row))return ' ';
        Object tile=Array.get(row,x);
        if(tile==null)return ' ';
        char[] ch=(char[])get(tile,"ch");
        return ch==null||ch.length==0?' ':ch[0];
    }
}
