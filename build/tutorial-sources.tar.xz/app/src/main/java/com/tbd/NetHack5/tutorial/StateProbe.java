package com.tbd.NetHack5.tutorial;

import android.graphics.Point;
import android.view.View;
import android.widget.TextView;
import android.widget.ListView;
import com.tbd.forkfront.ForkFront;
import com.tbd.forkfront.NH_State;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads *only* displayed knowledge from the NetHack UI.
 * Unknown terrain, lock state, unidentified objects etc. are never invented.
 */
final class StateProbe {
    private final TutorialActivity activity;
    private List<String> observedBag=Collections.emptyList();
    private boolean bagCurrent=false;
    private boolean awaitingBag=false;
    private String lastObservedMessage="";
    private TutorialEngine.State previous;
    private int observedTurn=-1;
    private String lastEvidenceMessage="";
    private Point lastMessagePosition;
    private String lastMessageAtPosition="";

    StateProbe(TutorialActivity activity) { this.activity=activity; }
    static Field field(Class<?> cls,String key)throws Exception {
        while(cls!=null) {
            try {Field f=cls.getDeclaredField(key); f.setAccessible(true);return f;}
            catch (NoSuchFieldException e) {cls=cls.getSuperclass();}
        }
        throw new NoSuchFieldException(key);
    }
    static Object get(Object o,String key)throws Exception {return field(o.getClass(),key).get(o);}
    static int id(TutorialActivity activity,String key) {
        for(String namespace:new String[]{activity.getPackageName(),"com.tbd.NetHack5","com.tbd.forkfront"}) {
            int id=activity.getResources().getIdentifier(key,"id",namespace);
            if(id!=0) return id;
        }
        return 0;
    }
    private String viewText(String key) {
        int id=id(activity,key);
        View v=id==0?null:activity.findViewById(id);
        return v instanceof TextView?((TextView)v).getText().toString():"";
    }
    NH_State game() {
        try {
            Field f=ForkFront.class.getDeclaredField("nhState");
            f.setAccessible(true);
            return (NH_State)f.get(null);
        } catch(Exception e) {return null;}
    }
    void expectsBag() {awaitingBag=true;}
    void invalidateBag() {bagCurrent=false; awaitingBag=false; observedBag=Collections.emptyList();}

    /** The inventory is captured ONLY after opening the game's real inventory.
     *  Do not reuse the cache after an action changes game state. */
    void observeMenu() {
        if(!awaitingBag) return;
        try {
            Object state=game();
            if(state==null)return;
            Object windows=get(state,"mWindows");
            if(!(windows instanceof List))return;
            List<?> w=(List<?>)windows;
            for(int k=w.size()-1;k>=0;k--) {
                Object menu=w.get(k);
                if(!menu.getClass().getName().endsWith("NHW_Menu"))continue;
                if(!Boolean.TRUE.equals(get(menu,"mIsVisible")))continue;
                Object contents=get(menu,"mItems");
                if(!(contents instanceof List))continue;
                List<String> bag=new ArrayList<>();
                for(Object item:(List<?>)contents) {
                    Method selectable=item.getClass().getMethod("isSelectable");
                    if(!Boolean.TRUE.equals(selectable.invoke(item)))continue;
                    Method name=item.getClass().getMethod("getName");
                    String label=String.valueOf(name.invoke(item));
                    if(!label.trim().isEmpty())bag.add(label);
                }
                if(!bag.isEmpty()) {
                    observedBag=bag;bagCurrent=true;awaitingBag=false;
                }
                return;
            }
        }catch(Exception ignored) { /* No invisible inventory guesses. */ }
    }
    List<String> currentMenuItemNames() {
        try {
            NH_State state=game();
            if(state==null)return Collections.emptyList();
            Object windows=get(state,"mWindows");
            if(!(windows instanceof List))return Collections.emptyList();
            List<?> w=(List<?>)windows;
            for(int k=w.size()-1;k>=0;k--) {
                Object menu=w.get(k);
                if(!menu.getClass().getName().endsWith("NHW_Menu"))continue;
                if(!Boolean.TRUE.equals(get(menu,"mIsVisible")))continue;
                Object contents=get(menu,"mItems");
                if(!(contents instanceof List))return Collections.emptyList();
                List<String> labels=new ArrayList<>();
                for(Object item:(List<?>)contents) {
                    Method name=item.getClass().getMethod("getName");
                    labels.add(String.valueOf(name.invoke(item)));
                }
                return labels;
            }
        }catch(Exception ignored) { }
        return Collections.emptyList();
    }
    String latestMessage() {
        try {
            Object state=game();
            if(state==null)return lastObservedMessage;
            Object log=get(get(state,"mMessage"),"mLog");
            int index=((Number)get(get(state,"mMessage"),"mCurrentIdx")).intValue();
            int len=Array.getLength(log);
            if(len==0)return lastObservedMessage;
            // Ring current index is implementation-specific; scan close slots.
            for(int i=0;i<Math.min(3,len);i++) {
                Object str=Array.get(log,(index-i+len)%len);
                if(str instanceof String&&!((String)str).trim().isEmpty()) {
                    lastObservedMessage=(String)str;
                    return lastObservedMessage;
                }
            }
        } catch(Exception ignored) { }
        String v=viewText("nh_message");
        if(!v.trim().isEmpty())lastObservedMessage=v;
        return lastObservedMessage;
    }
    private static int[] hp(String status) {
        Matcher m=Pattern.compile("\\bHP\\s*:?\\s*(\\d+)\\s*(?:\\(|/)\\s*(\\d+)\\s*\\)?", Pattern.CASE_INSENSITIVE).matcher(status);
        if(m.find())return new int[]{Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2))};
        return new int[]{-1,-1};
    }
    TutorialEngine.State snapshot() {
        TutorialEngine.State s=new TutorialEngine.State();
        NH_State state=game();
        if(state==null)return s;
        s.gameReady=true;
        String status=viewText("nh_stat0")+" "+viewText("nh_stat1");
        // Re-read item evidence after every NetHack turn: monsters can steal,
        // polymorph can affect equipment, and a past menu is not authoritative.
        Matcher turns=Pattern.compile("\\bT\\s*:?\\s*(\\d+)",Pattern.CASE_INSENSITIVE).matcher(status);
        if(turns.find()) {
            try {
                int currentTurn=Integer.parseInt(turns.group(1));
                if(observedTurn>=0 && currentTurn!=observedTurn)invalidateBag();
                observedTurn=currentTurn;
            } catch(NumberFormatException ignored) {}
        }
        int[] h=hp(status);s.hp=h[0];s.maxHp=h[1];
        s.conditions=status;
        s.recentMessage=latestMessage();
        if(!turns.find(0) && !s.recentMessage.equals(lastEvidenceMessage)) {
            // No numeric turn available: a new game message is a conservative
            // signal that an off-screen event may have changed carried items.
            if(!lastEvidenceMessage.isEmpty())invalidateBag();
        }
        lastEvidenceMessage=s.recentMessage;
        s.inventoryKnown=bagCurrent;
        s.knownInventory=bagCurrent?new ArrayList<>(observedBag):Collections.emptyList();
        try {s.inputPromptActive=state.expectsDirection();}
        catch(Exception ignored) { }
        try {
            Object m=get(state,"mMap");
            Point player=(Point)get(m,"mPlayerPos");
            Object tiles=get(m,"mTiles");
            if(player!=null) {
                // A door lock report is only relevant while we remain at
                // the location where it was displayed; do not apply a stale
                // message to a completely different door on a later tile.
                if(lastMessagePosition!=null && !lastMessagePosition.equals(player)) {
                    if(s.recentMessage.equals(lastMessageAtPosition)) s.recentMessage="";
                    invalidateBag();
                    s.inventoryKnown=false;
                    s.knownInventory=Collections.emptyList();
                }
                if(!s.recentMessage.isEmpty()) {
                    lastMessageAtPosition=s.recentMessage;
                    lastMessagePosition=new Point(player);
                }
                char under=glyph(tiles,player.x,player.y);
                s.stairsDownHere=under=='>';
                s.stairsUpHere=under=='<';
                for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++) {
                    if(dx==0 && dy==0)continue;
                    char c=glyph(tiles,player.x+dx,player.y+dy);
                    if(c=='+')s.doorAdjacent=true;
                    // Alphabetic glyphs are *possible* monsters, not identities.
                    if(Character.isLetter(c))s.monsterAdjacent=true;
                }
            }
        } catch(Exception ignored) { }
        String message=s.recentMessage.toLowerCase(java.util.Locale.ROOT);
        // The displayed player glyph can cover the underlying staircase.
        // A fresh game message can confirm the stairs when the map cannot.
        if(message.contains("staircase down") || message.contains("stairs down"))s.stairsDownHere=true;
        if(message.contains("staircase up") || message.contains("stairs up"))s.stairsUpHere=true;
        s.itemHere=message.contains("you see here")||message.contains("things that are here");
        try {
            Object windows=get(state,"mWindows");
            if(windows instanceof List) for(Object wnd:(List<?>)windows) {
                if(wnd.getClass().getName().endsWith("NHW_Menu") &&
                    Boolean.TRUE.equals(get(wnd,"mIsVisible"))) s.inputPromptActive=true;
            }
        }catch(Exception ignored) { }
        previous=s;
        return s;
    }
    static char glyph(Object tiles,int x,int y) throws Exception {
        if(y<0||y>=Array.getLength(tiles))return ' ';
        Object row=Array.get(tiles,y);
        if(row==null||x<0||x>=Array.getLength(row))return ' ';
        Object tile=Array.get(row,x);
        if(tile==null)return ' ';
        char[] ch=(char[])get(tile,"ch");
        return ch==null||ch.length==0?' ':ch[0];
    }
}
