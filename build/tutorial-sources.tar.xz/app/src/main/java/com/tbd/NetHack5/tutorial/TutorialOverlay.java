package com.tbd.NetHack5.tutorial;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.tbd.forkfront.Cmd;
import com.tbd.forkfront.Input;
import com.tbd.forkfront.NH_State;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** An offline NetHack tutor drawn around the real ForkFront dungeon view.
 * UI colors, structure and interactions match the local preview; the game itself
 * retains sole control of character movement, items, menus and saved games.
 */
final class TutorialOverlay {
    private static final int BACK=0xff10191e, HEAD=0xff14242c, PANEL=0xff21343b,
        SURFACE=0xff314951, BORDER=0xff60818b, WHITE=0xffe8f0eb,
        GOLD=0xffecc890, MINT=0xff70e0bd, SUB=0xffc9dad6,
        WARNING=0xffffd8a1, RED=0xffe86662, RISK=0xff47382f;

    private final TutorialActivity activity;
    private final StateProbe probe;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable timer=new Runnable(){@Override public void run(){
        if(!resumed) return;
        safeRefresh();handler.postDelayed(this,700);
    }};
    private boolean resumed;
    private long lastErrorAt;
    private int pendingDoorToken;
    private LinearLayout choices, groundHints, stairHints, companionHints;
    private TextView nameLabel,detailLabel,depthLabel,headline,description,bagCount;
    private ProgressBar hpBar;
    private String lastFingerprint="";
    private TutorialEngine.Advice currentAdvice;
    private TutorialEngine.State currentState;

    TutorialOverlay(TutorialActivity a){activity=a;probe=new StateProbe(a);}
    private int d(float dp){return (int)(dp*activity.getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int corners){
        GradientDrawable out=new GradientDrawable();out.setColor(color);
        out.setCornerRadius(d(corners));if(stroke!=0)out.setStroke(d(1),stroke);
        return out;
    }
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(activity);t.setText(value);t.setTextSize(size);
        t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private Button button(String label,int color){
        Button b=new Button(activity);b.setText(label);b.setAllCaps(false);
        b.setTextColor(WHITE);b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(color,BORDER,10));
        b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);
        b.setPadding(d(8),0,d(8),0);return b;
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(activity);v.setOrientation(LinearLayout.VERTICAL);return v;}

    void install(){
        int id=StateProbe.id(activity,"base_frame");
        View root=id==0?null:activity.findViewById(id);
        if(!(root instanceof LinearLayout)){
            Toast.makeText(activity,"Tutorial layout is not available",Toast.LENGTH_LONG).show();return;
        }
        LinearLayout base=(LinearLayout)root;
        base.setBackgroundColor(BACK);

        // Header: same hierarchy as the interactive HTML prototype.
        LinearLayout header=vertical();
        header.setPadding(d(12),d(7),d(12),d(9));header.setBackgroundColor(HEAD);
        TextView overline=text("TUTORIAL MODE  ·  OFFLINE",10,MINT,true);
        overline.setLetterSpacing(.15f);header.addView(overline);
        LinearLayout mast=new LinearLayout(activity);mast.setGravity(Gravity.CENTER_VERTICAL);
        TextView portrait=text("⚔",25,WHITE,true);portrait.setContentDescription("Your adventurer");portrait.setGravity(Gravity.CENTER);
        portrait.setBackground(shape(0xff334951,GOLD,8));
        mast.addView(portrait,new LinearLayout.LayoutParams(d(48),d(48)));
        LinearLayout vitals=vertical();vitals.setPadding(d(9),0,d(6),0);
        nameLabel=text("Novice Adventurer",16,WHITE,true);nameLabel.setSingleLine(true);
        vitals.addView(nameLabel);
        hpBar=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);
        hpBar.setIndeterminate(false);hpBar.setMax(100);hpBar.setProgress(100);
        hpBar.setProgressTintList(ColorStateList.valueOf(RED));
        hpBar.setProgressBackgroundTintList(ColorStateList.valueOf(0xff314146));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,d(9));hp.topMargin=d(6);
        vitals.addView(hpBar,hp);
        detailLabel=text("HP —/— · AC —",11,SUB,false);
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,-2);dl.topMargin=d(4);
        vitals.addView(detailLabel,dl);
        mast.addView(vitals,new LinearLayout.LayoutParams(0,d(62),1));
        depthLabel=text("DEPTH\n—",12,GOLD,true);depthLabel.setGravity(Gravity.CENTER);
        mast.addView(depthLabel,new LinearLayout.LayoutParams(d(55),d(48)));
        Button help=button("?",0xff334b51);help.setTextColor(GOLD);help.setTextSize(25);
        help.setContentDescription("What is happening? Offline wiki tutorial");
        help.setBackground(shape(0xff334b51,GOLD,100));
        help.setOnClickListener(v->explainCurrent());
        LinearLayout.LayoutParams bhl=new LinearLayout.LayoutParams(d(49),d(49));bhl.leftMargin=d(6);
        mast.addView(help,bhl);
        LinearLayout.LayoutParams ml=new LinearLayout.LayoutParams(-1,-2);ml.topMargin=d(5);
        header.addView(mast,ml);
        base.addView(header,0,new LinearLayout.LayoutParams(-1,-2));

        // The real NetHack map occupies the weighted center of base_frame.
        // We do NOT fabricate any terrain or replace the native map with a demo.
        int frameId=StateProbe.id(activity,"dlg_frame");
        View map=frameId==0?null:activity.findViewById(frameId);
        if(map!=null) {
            map.setBackgroundColor(BACK);
            // The real NetHack y/n/q prompt is an embedded native game view,
            // not an AlertDialog. Replace cryptic labels before its first draw
            // without changing its attached native key-selection listeners.
            map.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener(){
                @Override public boolean onPreDraw() { labelNativeChoices(map); return true; }
            });
        }

        // Bottom tutorial sheet visually mirrors the HTML preview.
        LinearLayout sheet=vertical();sheet.setPadding(d(12),d(10),d(12),d(12));
        sheet.setBackground(shape(PANEL,0xff496268,0));
        TextView kicker=text("WHAT'S HAPPENING",10,MINT,true);kicker.setLetterSpacing(.13f);
        sheet.addView(kicker);
        headline=text("Preparing your next step…",19,0xfff7eee0,true);
        LinearLayout.LayoutParams hnl=new LinearLayout.LayoutParams(-1,-2);hnl.topMargin=d(3);
        sheet.addView(headline,hnl);
        description=text("The tutor reads the current game. It never moves your hero automatically.",12,SUB,false);
        LinearLayout.LayoutParams descl=new LinearLayout.LayoutParams(-1,-2);descl.topMargin=d(3);descl.bottomMargin=d(6);
        sheet.addView(description,descl);
        choices=vertical();sheet.addView(choices);
        groundHints=vertical();sheet.addView(groundHints);
        stairHints=vertical();sheet.addView(stairHints);
        companionHints=vertical();sheet.addView(companionHints);
        LinearLayout footer=new LinearLayout(activity);footer.setGravity(Gravity.CENTER_VERTICAL);
        Button bag=button("▣ Bag",HEAD);bag.setOnClickListener(v->showInventory());
        footer.addView(bag,new LinearLayout.LayoutParams(0,d(45),1));
        Button actions=button("☰ Actions",HEAD);actions.setOnClickListener(v->showCommandCenter());
        LinearLayout.LayoutParams act=new LinearLayout.LayoutParams(0,d(45),1);act.leftMargin=d(6);
        footer.addView(actions,act);
        Button explain=button("? Help",HEAD);explain.setOnClickListener(v->explainCurrent());
        LinearLayout.LayoutParams exp=new LinearLayout.LayoutParams(0,d(45),1);exp.leftMargin=d(6);
        footer.addView(explain,exp);
        LinearLayout.LayoutParams foot=new LinearLayout.LayoutParams(-1,-2);foot.topMargin=d(10);
        sheet.addView(footer,foot);
        TextView status=text("NETHACK 5  ·  HELP IS FREE  ·  YOU CHOOSE",9,0xff8fa9ad,false);
        status.setGravity(Gravity.CENTER);status.setPadding(0,d(7),0,0);
        sheet.addView(status);

        ScrollView bottomScroll=new ScrollView(activity);
        bottomScroll.setFillViewport(false);bottomScroll.setVerticalScrollBarEnabled(false);
        bottomScroll.addView(sheet);
        // Keep map usable, particularly on compact devices / in landscape.
        int height=Math.min(d(345),activity.getResources().getDisplayMetrics().heightPixels*43/100);
        int position=base.getChildCount();
        View kbd=StateProbe.id(activity,"kbd_frame")==0?null:activity.findViewById(StateProbe.id(activity,"kbd_frame"));
        if(kbd!=null)position=Math.max(0,base.indexOfChild(kbd));
        base.addView(bottomScroll,position,new LinearLayout.LayoutParams(-1,height));

        // Default command panels are hidden; menus remain native, and the
        // unusual-command keyboard can still be shown when the game requests it.
        hideOldCommandPanel();
        int nativePanels=StateProbe.id(activity,"cmdPanelLayout1");
        View cmdLayout=nativePanels==0?null:activity.findViewById(nativePanels);
        if(cmdLayout!=null) {
            // Native CmdPanelLayout.show() makes the old action strips visible
            // every movement turn. Hiding from a 750ms timer causes flashing.
            // Keep their scroll views mounted (so native preferences don't
            // crash on a missing parent), but collapse them before *any* draw.
            cmdLayout.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener(){
                @Override public boolean onPreDraw(){hideOldCommandPanel();return true;}
            });
        }
        SharedPreferences prefs=activity.getSharedPreferences("nethack_tutorial",Context.MODE_PRIVATE);
        if(!prefs.getBoolean("seen_welcome_v2",false)){
            prefs.edit().putBoolean("seen_welcome_v2",true).apply();
            handler.postDelayed(this::showWelcome,1100);
        }
    }

    void resume(){resumed=true;handler.removeCallbacks(timer);handler.post(timer);}
    void pause(){resumed=false;pendingDoorToken++;handler.removeCallbacks(timer);}
    private void showWelcome(){
        if(activity.isFinishing())return;
        new AlertDialog.Builder(activity).setTitle("Welcome to NetHack Tutorial Mode")
          .setMessage("This is the real game, with an offline guide that explains what you see and why an action might help.\n\nRead the advice at the bottom. Tap ? in the header, beside actions or next to an inventory item for detailed help.\n\nHelp never uses a game turn. An action may; if it's dangerous, you will see a warning first.\n\nThe tutorial only offers item-based options after verifying what you've carried in the game's inventory.")
          .setPositiveButton("Start playing",null).show();
    }
    /** Expand question keystrokes for beginners; tapping still sends the original key. */
    private void labelNativeChoices(View root){
        for(int i=0;i<4;i++){
            int id=StateProbe.id(activity,"btn_"+i);
            View v=id==0?null:root.findViewById(id);
            if(!(v instanceof Button))continue;
            Button b=(Button)v;
            String code=b.getText().toString().trim();
            if(code.equals("y"))b.setText("Yes (y)");
            else if(code.equals("n"))b.setText("No (n)");
            else if(code.equals("q"))b.setText("Cancel (q)");
        }
    }

    private void hideOldCommandPanel(){
        try{
            View v=activity.findViewById(StateProbe.id(activity,"cmdPanelLayout1"));
            if(v instanceof com.tbd.forkfront.CmdPanelLayout){
                com.tbd.forkfront.CmdPanelLayout layout=(com.tbd.forkfront.CmdPanelLayout)v;
                layout.hide();
                for(int i=0;i<layout.getChildCount();i++){
                    View child=layout.getChildAt(i);
                    // Only command-panel strips are direct ScrollView children.
                    // Status, map touch area, native direction pad, and game
                    // messages are deliberately left alone.
                    if(!(child instanceof ScrollView)&&!(child instanceof HorizontalScrollView))continue;
                    child.setAlpha(0f);
                    child.setClickable(false);child.setFocusable(false);
                    ViewGroup.LayoutParams lp=child.getLayoutParams();
                    if(lp!=null&&(lp.width!=0||lp.height!=0)) {
                        lp.width=0;lp.height=0;child.setLayoutParams(lp);
                    }
                    child.setVisibility(View.GONE);
                }
            }
        }catch(Exception ignored){}
    }
    private static int parse(String source,String regex){
        Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(source);
        if(!m.find())return -1;
        try{return Integer.parseInt(m.group(1));}catch(Exception ignored){return -1;}
    }
    private String status(String id){
        int i=StateProbe.id(activity,id);View v=i==0?null:activity.findViewById(i);
        return v instanceof TextView?((TextView)v).getText().toString():"";
    }
    private void refreshHeader(TutorialEngine.State s){
        String row0=status("nh_stat0"), row1=status("nh_stat1");
        if(!row0.isEmpty()){
            String first=row0.split("\\s+",2)[0];
            nameLabel.setText(first.length()<3?"Your Adventurer":first);
        }
        if(s.hp>=0 && s.maxHp>0){
            hpBar.setMax(Math.max(1,s.maxHp));hpBar.setProgress(Math.max(0,Math.min(s.maxHp,s.hp)));
        }
        int ac=parse(row0+" "+row1,"\\bAC\\s*:?\\s*(-?\\d+)");
        int depth=parse(row0+" "+row1,"\\b(?:Dlvl|Depth)\\s*:?\\s*(\\d+)");
        depthLabel.setText("DEPTH\n"+(depth>=0?depth:"—"));
        String label="HP "+(s.hp<0?"—":s.hp)+"/"+(s.maxHp<0?"—":s.maxHp)+"  ·  AC "+(ac<0?"—":ac);
        if(s.conditions.matches("(?is).*\\b(hungry|weak|fainting|blind|stun|conf)\\b.*"))label+="  ·  STATUS!";
        detailLabel.setText(label);
    }
    /** Prevent one missing recycled native view or malformed message from crashing play. */
    private void safeRefresh(){
        if(!resumed || activity.isFinishing() || activity.isDestroyed()) return;
        try { refresh(); }
        catch(RuntimeException failure){
            Log.e("NetHackTutorial","Tutorial refresh failed; native game is still running",failure);
            lastFingerprint="";
            if(android.os.SystemClock.uptimeMillis()-lastErrorAt>15000){
                lastErrorAt=android.os.SystemClock.uptimeMillis();
                if(headline!=null) headline.setText("Game running — hints temporarily unavailable");
                if(description!=null) description.setText("Your progress is safe. Open Help or continue playing while the tutorial refreshes.");
            }
        }
    }
    private void refresh(){
        hideOldCommandPanel();
        probe.observeMenu();TutorialEngine.State s=probe.snapshot();
        TutorialEngine.Advice a=TutorialEngine.assess(s);
        currentState=s;currentAdvice=a;
        if(choices==null)return;
        refreshHeader(s);
        StringBuilder k=new StringBuilder(a.title).append('|').append(a.explanation);
        for(TutorialEngine.Choice c:a.choices)k.append('|').append(c.label).append(':').append(c.command);
        for(TutorialEngine.GroundItem item:s.groundItems)k.append("|floor:").append(item.category).append(":").append(item.dx).append(":").append(item.dy).append(":").append(item.label()).append(":").append(item.topic());
        for(TutorialEngine.Stair stair:s.visibleStairs)k.append("|stairs:").append(stair.down).append(":").append(stair.dx).append(":").append(stair.dy);
        for(TutorialEngine.Monster creature:s.nearbyMonsters)if(creature.confirmedPet)
            k.append("|companion:").append(creature.species).append(':').append(s.acknowledgedPets.contains(creature.species));
        if(k.toString().equals(lastFingerprint)){attachItemHelpButtons();return;}
        lastFingerprint=k.toString();headline.setText(a.title);description.setText(a.explanation);
        choices.removeAllViews();
        int max=3;int count=Math.min(max,a.choices.size());
        for(int i=0;i<count;i++)addChoiceRow(choices,a.choices.get(i));
        if(a.choices.size()>count){
            Button more=button("See all "+a.choices.size()+" available options…",HEAD);
            more.setOnClickListener(v->moreOptions(a));
            choices.addView(more,new LinearLayout.LayoutParams(-1,d(42)));
        }
        // Show visible floor objects even while a monster takes priority in the main advice.
        // The help is passive: tapping ? does not move, pick up, read, or identify anything.
        if(groundHints!=null){
            groundHints.removeAllViews();
            if(!s.groundItems.isEmpty()) {
                TextView nearby=text("VISIBLE FLOOR OBJECTS",10,MINT,true);
                nearby.setPadding(0,d(8),0,0);groundHints.addView(nearby);
                int shown=0;
                for(TutorialEngine.GroundItem object:s.groundItems){
                    if(shown++>=2)break;
                    LinearLayout row=new LinearLayout(activity);
                    String where=object.underfoot?"here":"to the "+object.direction();
                    TextView label=text(floorPictogram(object.category)+"  "+object.label()+" "+where,12,WHITE,false);
                    row.addView(label,new LinearLayout.LayoutParams(0,d(40),1));
                    Button q=button("?",HEAD);
                    q.setOnClickListener(v->showCard(WikiLibrary.forObservedItem(object.label(),object.category),null));
                    row.addView(q,new LinearLayout.LayoutParams(d(44),d(38)));
                    groundHints.addView(row);
                }
            }
        }
        // Mapped stairs and known companions are secondary discoveries.
        // Neither can continually override a useful item or exit in the
        // main WHAT'S HAPPENING panel.
        stairHints.removeAllViews();
        if(!s.visibleStairs.isEmpty()) {
            TextView title=text("MAPPED STAIRCASES",10,MINT,true);
            title.setPadding(0,d(8),0,0);stairHints.addView(title);
            int shown=0;
            for(TutorialEngine.Stair stair:s.visibleStairs) {
                if(shown++>=2)break;
                LinearLayout row=new LinearLayout(activity);
                TextView label=text((stair.down?"↓  ":"↑  ")+stair.label()+" to the "+stair.direction()+
                    " ("+stair.distance()+" tiles)",12,WHITE,false);
                row.addView(label,new LinearLayout.LayoutParams(0,d(40),1));
                Button why=button("?",HEAD);
                why.setContentDescription("Explain "+stair.label());
                why.setOnClickListener(v->showCard(WikiLibrary.get("stairs"),null));
                row.addView(why,new LinearLayout.LayoutParams(d(44),d(38)));
                stairHints.addView(row);
            }
        }
        companionHints.removeAllViews();
        // One unobtrusive line keeps pet instructions accessible without
        // occupying the primary advice slot every time the hero moves.
        for(TutorialEngine.Monster pet:s.nearbyMonsters)if(pet.confirmedPet) {
            if(a.title.startsWith("Your pet "))break; // already the focus
            String topic=WikiLibrary.monsterTopic(pet.species,true);
            LinearLayout row=new LinearLayout(activity);
            TextView label=text("Companion: "+pet.species+" nearby",11,SUB,false);
            row.addView(label,new LinearLayout.LayoutParams(0,d(35),1));
            Button why=button("?",HEAD);
            why.setContentDescription("Explain your "+pet.species);
            why.setOnClickListener(v->showCard(WikiLibrary.get(topic),null));
            row.addView(why,new LinearLayout.LayoutParams(d(40),d(34)));
            companionHints.addView(row);
            break;
        }
        attachItemHelpButtons();
    }
    /** Consistent, tinted native vector icons rather than mismatched toolbar glyphs. */
    private void decorateAction(Button b,String cmd){
        int icon=android.R.drawable.ic_menu_info_details;
        if(cmd.equals("i") || cmd.equals("w") || cmd.equals("W") || cmd.equals("P") || cmd.equals("R"))icon=android.R.drawable.ic_menu_agenda;
        else if(cmd.equals("o") || cmd.equals("M-u") || cmd.equals("a") || cmd.equals("^d"))icon=android.R.drawable.ic_menu_manage;
        else if(cmd.equals(";") || cmd.equals(":"))icon=android.R.drawable.ic_menu_search;
        else if(cmd.equals("s") || cmd.equals("20s") || cmd.startsWith("MOVE:"))icon=android.R.drawable.ic_menu_compass;
        else if(cmd.equals("<") || cmd.equals(">"))icon=android.R.drawable.ic_menu_directions;
        else if(cmd.equals("e") || cmd.equals("q") || cmd.equals("r"))icon=android.R.drawable.ic_menu_edit;
        try {
            Drawable image=activity.getDrawable(icon).mutate();
            image.setTint(MINT);
            image.setBounds(0,0,d(20),d(20));
            b.setCompoundDrawablesRelative(image,null,null,null);
            b.setCompoundDrawablePadding(d(9));
        }catch(RuntimeException e){Log.w("NetHackTutorial","Action icon unavailable",e);}
    }
    private String floorPictogram(String category){
        switch(category){
            case "potion":return "🧪";
            case "scroll":return "📜";
            case "gold":return "✦";
            case "weapon":return "⚔";
            case "armor":return "⬡";
            case "food":return "◈";
            case "ring":return "◉";
            case "wand":return "✧";
            case "tool":return "⚙";
            default:return "◇";
        }
    }
    private void addChoiceRow(LinearLayout box,TutorialEngine.Choice option){
        LinearLayout row=new LinearLayout(activity);
        Button main=button((option.risky?"⚠  ":"")+option.label,option.risky?RISK:SURFACE);
        decorateAction(main,option.command);
        main.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        main.setPadding(d(13),0,d(8),0);
        main.setOnClickListener(v->runChoice(option));
        row.addView(main,new LinearLayout.LayoutParams(0,d(48),1));
        Button help=button("?",0xff254049);help.setTextColor(GOLD);help.setTextSize(21);
        help.setContentDescription("Explain: "+option.label);
        help.setOnClickListener(v->showCard(WikiLibrary.get(option.wikiTopic),option.explanation));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(d(46),d(48));p.leftMargin=d(6);
        row.addView(help,p);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=d(6);
        box.addView(row,lp);
    }
    private void moreOptions(TutorialEngine.Advice advice){
        LinearLayout list=vertical();list.setPadding(d(14),d(14),d(14),d(14));
        list.addView(text("Choose an action or tap ? to understand what it does.",14,SUB,false));
        for(TutorialEngine.Choice choice:advice.choices)addChoiceRow(list,choice);
        ScrollView scroll=new ScrollView(activity);scroll.addView(list);
        new AlertDialog.Builder(activity).setTitle("Relevant options now")
            .setView(scroll).setNegativeButton("Back",null).show();
    }
    private void showInventory(){
        NH_State game=probe.game();if(game==null){
            Toast.makeText(activity,"Begin the game first",Toast.LENGTH_SHORT).show();return;
        }
        probe.expectsBag();dispatch("i");
    }
    private void runChoice(TutorialEngine.Choice choice){
        // A choice can become stale while a modal sheet is open.
        // Re-check live conditions and do not execute an action that has
        // disappeared from the engine's currently supported choice list.
        if(!choice.command.startsWith("HELP:")){
            TutorialEngine.Advice fresh=TutorialEngine.assess(probe.snapshot());
            boolean stillAllowed=false;
            for(TutorialEngine.Choice c:fresh.choices){
                if(c.command.equals(choice.command)&&c.label.equals(choice.label)){
                    stillAllowed=true;break;
                }
            }
            if(!stillAllowed){
                Toast.makeText(activity,"Situation changed; this option is no longer available",Toast.LENGTH_LONG).show();
                refresh();return;
            }
        }
        if(choice.command.startsWith("HELP:")){
            showCard(WikiLibrary.get(choice.command.substring(5)),choice.explanation);return;
        }
        if(choice.risky){
            new AlertDialog.Builder(activity).setTitle("⚠ This may be dangerous")
              .setMessage(choice.explanation+"\n\nTry this in the game? NetHack may ask you to choose a direction or item.")
              .setNegativeButton("Go back",null)
              .setNeutralButton("Learn more",(d,w)->showCard(WikiLibrary.get(choice.wikiTopic),null))
              .setPositiveButton("Try the action",(d,w)->dispatch(choice.command)).show();
        }else dispatch(choice.command);
    }
    /** If one known closed door is adjacent, answer NetHack's direction query
     * after its input boundary. More than one door gets an explicit choice. */
    private boolean handleDoorTarget(String command, NH_State state) {
        if(!(command.equals("o") || command.equals("M-u") || command.equals("^d"))) return false;
        TutorialEngine.State view=probe.snapshot();
        if(view.inputPromptActive) {
            Toast.makeText(activity,"Finish the current question first",Toast.LENGTH_SHORT).show();
            return true;
        }
        if(view.adjacentDoors.isEmpty()) return false; // retain NetHack's normal prompt
        if(view.adjacentDoors.size()==1){
            executeOnDoor(command,view.adjacentDoors.get(0));
            return true;
        }
        showDoorDirections(command,view.adjacentDoors);
        return true;
    }
    private char directionKey(TutorialEngine.Door door,boolean numpad){
        if(numpad)return door.dx<0?'4':door.dx>0?'6':door.dy<0?'8':'2';
        return door.dx<0?'h':door.dx>0?'l':door.dy<0?'k':'j';
    }
    /** Ask NetHack to start the action, but ONLY answer its direction request
     * once the native frontend actually enters direction mode. A failed action
     * must NEVER leave a queued direction that could move the hero into danger. */
    private void executeOnDoor(String command,TutorialEngine.Door choice){
        NH_State game=probe.game();if(game==null)return;
        TutorialEngine.State fresh=probe.snapshot();
        boolean confirmed=false;
        for(TutorialEngine.Door door:fresh.adjacentDoors)
            if(door.dx==choice.dx && door.dy==choice.dy){confirmed=true;break;}
        if(!confirmed || fresh.inputPromptActive){
            Toast.makeText(activity,"That door is no longer available",Toast.LENGTH_SHORT).show();
            safeRefresh();return;
        }
        char key=directionKey(choice,game.isNumPadOn());
        int token=++pendingDoorToken;
        char verb=command.equals("M-u")?'u':command.equals("^d")?'d':'o';
        EnumSet<Input.Modifier> mods=Input.modifiers();
        if(command.equals("M-u"))mods.add(Input.Modifier.Meta);
        if(command.equals("^d"))mods.add(Input.Modifier.Control);
        String priorDirectionMessage=probe.visibleDirectionPrompt();
        game.handleKeyDown(verb,Input.nhKeyFromMod(verb,mods),Input.toKeyCode(verb),mods,0,true);
        probe.invalidateBag();
        awaitDoorDirection(game,key,token,0,priorDirectionMessage);
    }
    private void awaitDoorDirection(NH_State game,char target,int token,int tries,String previousPrompt){
        handler.postDelayed(()->{
            if(token!=pendingDoorToken || !resumed || activity.isFinishing() || activity.isDestroyed())return;
            // The native showDPad() callback is authoritative: no direction is
            // sent after a failed command, an error message, or a quit dialog.
            String visible=probe.visibleDirectionPrompt();
            boolean directionPad=game.expectsDirection() && game.isDPadVisible();
            boolean newMapPrompt=!visible.isEmpty() && !visible.equals(previousPrompt);
            if(directionPad || newMapPrompt){
                game.sendDirKeyCmd(target);
                handler.postDelayed(this::safeRefresh,180);
            }else if(tries<12){
                awaitDoorDirection(game,target,token,tries+1,previousPrompt);
            }else{
                // The command may have rejected the action. Never guess that
                // the next keystroke would still be a direction answer.
                safeRefresh();
            }
        },70);
    }
    private void showDoorDirections(String command,List<TutorialEngine.Door> doors){
        final Dialog sheet=new Dialog(activity);
        LinearLayout content=vertical();content.setPadding(d(19),d(18),d(19),d(18));
        content.setBackground(shape(PANEL,BORDER,14));
        TextView heading=text("WHICH DOOR?",18,GOLD,true);content.addView(heading);
        TextView hint=text("Choose the door to use. Only visible adjacent doors are shown.",13,SUB,false);
        hint.setPadding(0,d(8),0,d(8));content.addView(hint);
        for(TutorialEngine.Door door:doors){
            String arrow=door.dx<0?"←":door.dx>0?"→":door.dy<0?"↑":"↓";
            Button button=button(arrow+"  "+door.direction().toUpperCase(Locale.ROOT),SURFACE);
            decorateAction(button,command);
            button.setContentDescription("Door to the "+door.direction());
            button.setOnClickListener(v->{sheet.dismiss();executeOnDoor(command,door);});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,d(52));p.topMargin=d(7);
            content.addView(button,p);
        }
        Button cancel=button("Cancel",HEAD);cancel.setOnClickListener(v->sheet.dismiss());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,d(48));cp.topMargin=d(13);
        content.addView(cancel,cp);
        sheet.setContentView(content);sheet.show();
        if(sheet.getWindow()!=null)sheet.getWindow().setLayout(-1,-2);
    }
    private void dispatch(String command){
        NH_State state=probe.game();if(state==null)return;
        pendingDoorToken++;
        if(handleDoorTarget(command,state)) return;
        // Re-evaluate the preconditions immediately before executing a visible choice.
        // Do not trigger stale actions after a move, menu or message change.
        if(!command.equals("i")&&!command.equals(";")&&!command.equals(":")&&!command.equals("ESC"))probe.invalidateBag();
        if(command.equals(",")) {
            probe.pickupRequested(); // immediately remove stale pickup option
            handler.post(this::safeRefresh);
        }
        if(command.startsWith("MOVE:")){
            String[] coord=command.substring(5).split(":");
            if(coord.length!=2)return;
            int dx=Integer.parseInt(coord[0]),dy=Integer.parseInt(coord[1]);
            if(dx<-1||dx>1||dy<-1||dy>1||(dx==0&&dy==0))return;
            // y is positive south; NetHack directions use hjkl/yubn or numpad.
            String vim=(dy==-1?(dx==-1?"y":dx==0?"k":"u"):
                dy==0?(dx==-1?"h":"l"):(dx==-1?"b":dx==0?"j":"n"));
            String pad=(dy==-1?(dx==-1?"7":dx==0?"8":"9"):
                dy==0?(dx==-1?"4":"6"):(dx==-1?"1":dx==0?"2":"3"));
            state.sendKeyCmd((state.isNumPadOn()?pad:vim).charAt(0));
            handler.postDelayed(this::safeRefresh,250);return;
        }
        // NetHack 5 maps Untrap to Meta+u directly (src/cmd.c).
        // Do not type "#untrap\n" into an asynchronous native prompt: the
        // trailing keys may be misinterpreted as other in-game commands.
        // One Meta+u keystroke is atomic and preserves NetHack's own
        // direction-selection prompt.
        if(command.equals("M-u") || command.equals("M-l")) {
            EnumSet<Input.Modifier> modifiers=Input.modifiers();
            modifiers.add(Input.Modifier.Meta);
            char metaKey=command.charAt(2);
            state.handleKeyDown(metaKey,Input.nhKeyFromMod(metaKey,modifiers),
                                Input.toKeyCode(metaKey),modifiers,0,true);
            handler.postDelayed(this::safeRefresh,250);
            return;
        }
        if(command.equals("ESC")){state.sendKeyCmd(27);return;}
        if(command.equals("KEYBOARD")){state.showKeyboard();return;}
        if(command.equals("20s")){
            new Cmd.KeySequnece(state,"20s","Search 20 times").execute(()->{});return;
        }
        if(command.startsWith("#")&&command.length()>1){
            new Cmd.KeySequnece(state,command+"\n",command).execute(()->{});return;
        }
        boolean ctrl=command.startsWith("^")&&command.length()==2;
        char ch=ctrl?command.charAt(1):command.charAt(0);
        EnumSet<Input.Modifier> mods=Input.modifiers();if(ctrl)mods.add(Input.Modifier.Control);
        state.handleKeyDown(ch,Input.nhKeyFromMod(ch,mods),Input.toKeyCode(ch),mods,0,true);
        handler.postDelayed(this::safeRefresh,250);
    }
    /** A command-center button can outlive the scene in which it was built.
     * Recheck relevant visible capabilities before dispatching from a dialog. */
    private boolean commandStillRelevant(String command){
        TutorialEngine.State s=probe.snapshot();
        if(!s.gameReady)return false;
        if(s.inputPromptActive)return command.equals("ESC");
        switch(command){
            case "o": case "M-u": return !s.adjacentDoors.isEmpty();
            case "^d":return !s.adjacentDoors.isEmpty() && !s.monsterAdjacent &&
                     !s.unidentifiedCreatureAdjacent && !(s.hp>=0 && s.maxHp>0 && s.hp*3<=s.maxHp);
            case ",":return s.itemHere;
            case "M-l":
                for(TutorialEngine.GroundItem obj:s.groundItems)
                    if(obj.underfoot && obj.observedName!=null &&
                       (obj.observedName.contains("box")||obj.observedName.contains("chest")))return true;
                return false;
            case "<":return s.stairsUpHere;
            case ">":return s.stairsDownHere;
            case "e":return bagHas(s,"food ration","cram ration","lembas wafer","apple","orange","banana","tripe ration");
            case "q":return bagHas(s,"potion");
            case "r":return bagHas(s,"scroll","spellbook");
            case "z":return bagHas(s,"wand");
            case "w":return bagHas(s,"dagger","sword","spear","axe","bow","mace","staff","arrow","dart","crossbow");
            case "a":return bagHas(s,"leash","key","pick","lamp","whistle","mirror","blindfold","stethoscope","tin opener","tinning kit","horn","flute","camera","candle","bag of tricks");
            case "W":return bagHasUnworn(s,"mail","helmet","cloak","gloves","boots","shield","shirt","robe","armor","helm");
            case "P":return bagHasUnworn(s,"ring","amulet");
            case "Q":return bagHas(s,"arrow","dart","shuriken","bolt","sling bullet");
            default:return true;
        }
    }
    private void commandButton(LinearLayout where, String label, String explanation,
                               String cmd, boolean risky, String topic,
                               AlertDialog[] parent) {
        LinearLayout row=new LinearLayout(activity);
        Button choice=button(label,risky?RISK:SURFACE);
        choice.setOnClickListener(v->{
            if(parent[0]!=null)parent[0].dismiss();
            if(!commandStillRelevant(cmd)){
                Toast.makeText(activity,"That action is no longer available",Toast.LENGTH_SHORT).show();
                safeRefresh();return;
            }
            if(risky){
                new AlertDialog.Builder(activity).setTitle("This advances game time")
                    .setMessage(explanation)
                    .setNegativeButton("Cancel",null)
                    .setPositiveButton("Continue",(dlg,w)->{
                        if(commandStillRelevant(cmd))dispatch(cmd);
                        else Toast.makeText(activity,"That action is no longer available",Toast.LENGTH_SHORT).show();
                    }).show();
            }else dispatch(cmd);
        });
        decorateAction(choice,cmd);
        row.addView(choice,new LinearLayout.LayoutParams(0,d(45),1));
        Button why=button("?",HEAD);
        why.setOnClickListener(v->showCard(WikiLibrary.get(topic),explanation));
        LinearLayout.LayoutParams whyLp=new LinearLayout.LayoutParams(d(45),d(45));whyLp.leftMargin=d(5);
        row.addView(why,whyLp);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=d(7);
        where.addView(row,lp);
    }
    private void heading(LinearLayout where,String title){
        TextView heading=text(title,12,MINT,true);heading.setPadding(0,d(12),0,0);
        where.addView(heading);
    }
    private static boolean itemNameMatches(String description,String needle){
        if(needle.equals("ring"))
            return !description.contains("ring mail") &&
                   Pattern.compile("\\bring\\b").matcher(description).find();
        return description.contains(needle);
    }
    private static boolean bagHas(TutorialEngine.State s,String... words){
        if(!s.inventoryKnown) return false;
        for(String item:s.knownInventory){
            String text=item.toLowerCase(Locale.ROOT);
            for(String word:words)if(itemNameMatches(text,word))return true;
        }
        return false;
    }
    private static boolean bagHasUnworn(TutorialEngine.State s,String... words){
        if(!s.inventoryKnown) return false;
        for(String item:s.knownInventory){
            String text=item.toLowerCase(Locale.ROOT);
            boolean matches=false;
            for(String word:words)if(itemNameMatches(text,word)){matches=true;break;}
            if(matches && !text.contains("being worn") && !text.contains("on left hand")
                  && !text.contains("on right hand") && !text.contains("around neck"))return true;
        }
        return false;
    }
    /** Main actions follow visible capabilities. Uncommon commands remain available
     * through the advanced keyboard rather than cluttering every turn. */
    private void showCommandCenter(){
        TutorialEngine.State s=probe.snapshot();
        LinearLayout inside=vertical();inside.setPadding(d(14),d(10),d(14),d(14));
        inside.setBackgroundColor(PANEL);
        AlertDialog[] dialog={null};
        if(s.inputPromptActive){
            heading(inside,"FINISH THE CURRENT CHOICE");
            inside.addView(text("Select an answer in NetHack's active question, or cancel.",13,SUB,false));
            commandButton(inside,"Cancel current prompt","Back out of this prompt without choosing an action.","ESC",false,"commands",dialog);
        } else {
            boolean threats=s.monsterAdjacent || s.unidentifiedCreatureAdjacent;
            boolean critical=s.hp>=0 && s.maxHp>0 && s.hp*3<=s.maxHp;
            boolean hasFloor=s.itemHere;
            boolean containerHere=false;
            for(TutorialEngine.GroundItem object:s.groundItems)
                if(object.underfoot && object.observedName!=null &&
                  (object.observedName.contains("box") || object.observedName.contains("chest")))containerHere=true;

            if(s.doorAdjacent){
                heading(inside,"🚪  NEARBY DOORS");
                String where=s.adjacentDoors.size()==1?" to the "+s.adjacentDoors.get(0).direction():"";
                commandButton(inside,s.adjacentDoors.size()>1?"Choose a door to open":"Open door"+where,
                    "Try opening a closed adjacent door. If there are multiple doors, pick one.","o",false,"door",dialog);
                commandButton(inside,"Check door for traps",
                    "Examine a door for traps. Failure to find one does not mean it is safe.","M-u",false,"door",dialog);
                if(bagHas(s,"skeleton key","lock pick","credit card"))
                    commandButton(inside,"Unlock using a carried tool",
                        "Select the known key or pick in NetHack, then choose the door.","a",false,"door",dialog);
                if(!threats && !critical)
                    commandButton(inside,"Kick a door — noisy and risky",
                        "Kicking may damage the door, wake monsters, or upset guards or shopkeepers.","^d",true,"door",dialog);
            }
            if(hasFloor || s.stairsDownHere || s.stairsUpHere || containerHere){
                heading(inside,"✦  AT YOUR FEET");
                if(hasFloor)commandButton(inside,"Pick up items here",
                    "Take objects on your current square. NetHack may offer a selection if several are present.",",",false,"inventory",dialog);
                if(containerHere)commandButton(inside,"Open or loot the container",
                    "Examine a box or chest where you stand. A lock or trap may require another choice.","M-l",false,"inventory",dialog);
                if(s.stairsDownHere && !critical)commandButton(inside,"Go downstairs",
                    "Descend to the next dungeon level.",">",true,"stairs",dialog);
                if(s.stairsUpHere)commandButton(inside,"Go upstairs",
                    "Travel up the staircase under your feet.","<",false,"stairs",dialog);
                if(hasFloor)commandButton(inside,"Describe items on this square",
                    "Ask NetHack to show the objects underfoot.",":",false,"inventory",dialog);
            }
            if(s.inventoryKnown){
                boolean potions=bagHas(s,"potion"), scrolls=bagHas(s,"scroll","spellbook");
                boolean food=bagHas(s,"food ration","cram ration","lembas wafer","apple","orange","banana","tripe ration");
                boolean weapons=bagHas(s,"dagger","sword","spear","axe","bow","mace","staff","arrow","dart","shuriken","crossbow");
                boolean tools=bagHas(s,"leash","key","pick","lamp","whistle","mirror","blindfold","stethoscope","tin opener","tinning kit","bag of tricks","horn","flute","camera","candle");
                boolean armor=bagHasUnworn(s,"mail","helmet","cloak","gloves","boots","shield","shirt","robe","armor","helm");
                boolean ring=bagHasUnworn(s,"ring","amulet");
                boolean ringWorn=false;
                for(String item:s.knownInventory){
                    String low=item.toLowerCase(Locale.ROOT);
                    if(low.contains("on left hand")||low.contains("on right hand")||low.contains("around neck"))ringWorn=true;
                }
                boolean wand=bagHas(s,"wand");
                if(potions||scrolls||food||weapons||tools||armor||ring||ringWorn||wand){
                    heading(inside,"▣  YOUR AVAILABLE ITEMS");
                    if(food)commandButton(inside,"Eat food", "Select something safe to eat. Time passes while eating.","e",false,"food",dialog);
                    if(potions)commandButton(inside,"Drink a potion", "Choose which potion to drink. Unknown potions can be dangerous.","q",true,"potion",dialog);
                    if(scrolls)commandButton(inside,"Read a scroll or spellbook", "Reading unknown scrolls or spellbooks can be hazardous.","r",true,"scroll",dialog);
                    if(tools)commandButton(inside,"Use a tool", "Choose a tool and follow NetHack's prompts.","a",false,"inventory",dialog);
                    if(wand)commandButton(inside,"Zap a wand", "Pick a wand and a direction. Unknown effects can be dangerous.","z",true,"wand",dialog);
                    if(weapons)commandButton(inside,"Wield a weapon", "Select a weapon to carry in your hands.","w",false,"weapon",dialog);
                    if(armor)commandButton(inside,"Wear armor", "Select a piece of armor you are carrying.","W",false,"armor",dialog);
                    if(ring)commandButton(inside,"Put on a ring or amulet", "Select an accessory and a slot.","P",false,"ring",dialog);
                    if(ringWorn)commandButton(inside,"Remove a ring or amulet", "Select a worn accessory to remove.","R",false,"ring",dialog);
                    if(bagHas(s,"arrow","dart","shuriken","bolt","sling bullet"))
                        commandButton(inside,"Ready ammunition", "Select ammunition for your quiver.","Q",false,"weapon",dialog);
                }
            }
            heading(inside,"☰  BAG & EXPLORATION");
            commandButton(inside,"Open backpack","Inspect your equipment and every carried item.","i",false,"inventory",dialog);
            commandButton(inside,"Look around", "Inspect visible creatures or terrain without attacking.",";",false,"exploration",dialog);
            if(!threats && !critical){
                commandButton(inside,"Search nearby", "Look for hidden doors and traps. Uses a turn.","s",true,"exploration",dialog);
                if(s.hp>0 && s.maxHp>0 && s.hp*2>s.maxHp &&
                   !s.conditions.toLowerCase(Locale.ROOT).contains("hungry") &&
                   !s.conditions.toLowerCase(Locale.ROOT).contains("weak"))
                    commandButton(inside,"Search repeatedly (20 turns)", "Twenty searches can be interrupted by danger; be careful.","20s",true,"exploration",dialog);
            }
            if(s.floorPickupUnverified)commandButton(inside,"Check for items remaining",
                "Check the floor after picking up an object; more may remain.",":",false,"inventory",dialog);
            heading(inside,"⚙  DISPLAY & ACCESSIBILITY");
            Button tiles=button("Choose map tileset",SURFACE);decorateAction(tiles,"TILESET");
            tiles.setContentDescription("Select ASCII, Default, Geoduck or Nevanda map tiles");
            tiles.setOnClickListener(v->{if(dialog[0]!=null)dialog[0].dismiss();openTilesetPicker();});
            LinearLayout.LayoutParams tilelp=new LinearLayout.LayoutParams(-1,d(46));tilelp.topMargin=d(7);
            inside.addView(tiles,tilelp);
            Button preferences=button("Advanced display settings",SURFACE);decorateAction(preferences,"SETTINGS");
            preferences.setOnClickListener(v->{if(dialog[0]!=null)dialog[0].dismiss();activity.openOriginalSettings();});
            LinearLayout.LayoutParams preflp=new LinearLayout.LayoutParams(-1,d(46));preflp.topMargin=d(7);
            inside.addView(preferences,preflp);
            heading(inside,"⌘  MORE NETHACK COMMANDS");
            commandButton(inside,"Extended commands", "Find less common commands through NetHack's built-in command picker.","#",false,"commands",dialog);
            commandButton(inside,"Show game keyboard", "Use the original command keyboard for any action not yet listed here.","KEYBOARD",false,"commands",dialog);
            commandButton(inside,"Game rules and options", "Change NetHack rules and settings.","O",false,"commands",dialog);
        }
        ScrollView scroll=new ScrollView(activity);scroll.setFillViewport(false);scroll.addView(inside);
        dialog[0]=new AlertDialog.Builder(activity).setTitle("Actions for this situation")
            .setView(scroll).setNegativeButton("Back to dungeon",null).create();
        dialog[0].show();
    }
    /** Direct map-tileset picker backed by the original game's own options.
     * Preferences are written in exactly the form ForkFront's TilesetPreference
     * expects, and NH_State is notified to reload the real map graphics.
     */
    private void openTilesetPicker(){
        final String[] names=activity.getResources().getStringArray(com.tbd.NetHack5.R.array.tileNames);
        final String[] values=activity.getResources().getStringArray(com.tbd.NetHack5.R.array.tileValues);
        if(names.length!=values.length || names.length==0){
            Toast.makeText(activity,"Tilesets are not available in this build",Toast.LENGTH_LONG).show();return;
        }
        final SharedPreferences prefs=PreferenceManager.getDefaultSharedPreferences(activity);
        final String selected=prefs.getString("tileset","TTY");
        final Dialog picker=new Dialog(activity);
        LinearLayout inside=vertical();inside.setBackground(shape(PANEL,BORDER,14));
        inside.setPadding(d(17),d(18),d(17),d(17));
        inside.addView(text("CHOOSE MAP TILESET",11,MINT,true));
        TextView expl=text("Change how the dungeon looks. Your character and save remain unchanged.",13,SUB,false);
        expl.setPadding(0,d(8),0,d(10));inside.addView(expl);
        for(int i=0;i<values.length;i++){
            final String name=names[i],value=values[i];
            Button choice=button((value.equals(selected)?"✓  ":"     ")+name,SURFACE);
            choice.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);
            choice.setOnClickListener(v->{
                int width=0,height=0;
                if(!value.equals("TTY")){
                    int underscore=value.lastIndexOf('_'), cross=value.lastIndexOf('x');
                    try{
                        if(underscore<0)throw new NumberFormatException("Missing tile size");
                        width=Integer.parseInt(value.substring(underscore+1,cross<0?value.length():cross));
                        height=cross<0?width:Integer.parseInt(value.substring(cross+1));
                        if(width<=0 || height<=0)throw new NumberFormatException("Bad size");
                    }catch(NumberFormatException e){
                        Toast.makeText(activity,"Invalid tileset dimensions",Toast.LENGTH_LONG).show();return;
                    }
                }
                // Never persist a built-in selection that Android cannot load.
                // The runtime resource package is the installed application ID,
                // NOT the Java R namespace used by the original NetHack build.
                if(!value.equals("TTY")){
                    int sheet=activity.getResources().getIdentifier(value,"drawable",activity.getPackageName());
                    int marks=activity.getResources().getIdentifier("overlays","drawable",activity.getPackageName());
                    if(sheet==0 || marks==0){
                        Toast.makeText(activity,"Tileset image unavailable in this APK",Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                boolean saved=prefs.edit().putString("tileset",value)
                    .putInt("tileW",width).putInt("tileH",height)
                    .putBoolean("customTiles",false).commit();
                if(!saved){Toast.makeText(activity,"Could not save tileset choice",Toast.LENGTH_LONG).show();return;}
                NH_State state=probe.game();
                if(state!=null)state.preferencesUpdated();
                picker.dismiss();handler.postDelayed(this::safeRefresh,200);
            });
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,d(50));cp.topMargin=d(6);
            inside.addView(choice,cp);
        }
        Button custom=button("Import custom tileset / More options",HEAD);
        custom.setOnClickListener(v->{picker.dismiss();activity.openOriginalSettings();});
        LinearLayout.LayoutParams customLp=new LinearLayout.LayoutParams(-1,d(49));customLp.topMargin=d(13);
        inside.addView(custom,customLp);
        Button close=button("Back to game",HEAD);close.setOnClickListener(v->picker.dismiss());
        LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,d(47));clp.topMargin=d(6);
        inside.addView(close,clp);
        ScrollView scroll=new ScrollView(activity);scroll.addView(inside);
        picker.setContentView(scroll);picker.show();
        if(picker.getWindow()!=null){
            picker.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            picker.getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            picker.getWindow().setDimAmount(.65f);
            picker.getWindow().setLayout(-1,-2);
            picker.getWindow().setGravity(Gravity.CENTER);
        }
    }

    private void explainCurrent(){
        TutorialEngine.Advice a=currentAdvice;
        if(a==null){showCard(WikiLibrary.get("beginner"),null);return;}
        String situation=a.title+"\n\n"+a.explanation;
        WikiLibrary.Card card=WikiLibrary.get(a.wikiTopic);
        if(currentState!=null && !currentState.groundItems.isEmpty() &&
           (a.wikiTopic.equals("inventory") || a.title.toLowerCase(Locale.ROOT).contains("floor") ||
            a.title.toLowerCase(Locale.ROOT).contains("corpse") || a.title.toLowerCase(Locale.ROOT).contains("item"))) {
            for(TutorialEngine.GroundItem obj:currentState.groundItems)if(obj.underfoot){
                card=WikiLibrary.forObservedItem(obj.label(),obj.category);break;
            }
        }
        if(currentState!=null&&!currentState.recentMessage.trim().isEmpty()){
            situation+="\n\nLATEST GAME MESSAGE:\n"+currentState.recentMessage;
            WikiLibrary.Card message=WikiLibrary.forMessage(currentState.recentMessage);
            if(a.wikiTopic.equals("exploration")&&!message.id.equals("beginner"))card=message;
        }
        if(currentState!=null&&!currentState.groundItems.isEmpty()) {
            situation+="\n\nVISIBLE FLOOR OBJECTS:";
            for(TutorialEngine.GroundItem obj:currentState.groundItems)
                situation+="\n• "+obj.label()+" "+(obj.underfoot?"under your feet":"to the "+obj.direction());
            situation+="\nTap the ? beside a floor object for its specific help.";
        }
        showCard(card,situation);
    }
    private TextView paragraph(String heading,String body,int color){
        TextView text=text(heading+"\n"+body,14,color,false);
        text.setPadding(0,d(9),0,d(8));return text;
    }
    private void showCard(WikiLibrary.Card card,String situation){
        // A pet becomes "introduced" only when its guide is actually opened,
        // never merely because its symbol stayed visible for another turn.
        probe.markPetExplained(card.id);
        LinearLayout inside=vertical();inside.setPadding(d(19),d(18),d(19),d(18));
        inside.setBackgroundColor(0xff1c2d34);
        TextView eyebrow=text("OFFLINE NETHACK 5 REFERENCE",10,MINT,true);
        eyebrow.setLetterSpacing(.12f);inside.addView(eyebrow);
        TextView title=text("ⓘ  "+card.title,21,GOLD,true);
        title.setPadding(0,d(6),0,d(9));inside.addView(title);
        // Player-facing reference content: no implementation or identity-detection commentary.
        // Situation text is only shown for a contextual choice, never when inspecting an item.
        if(situation!=null && !situation.trim().isEmpty())
            inside.addView(paragraph("RIGHT NOW",situation,WHITE));
        inside.addView(paragraph("DESCRIPTION",card.what,WHITE));
        if(card.stats!=null && card.stats.length>0){
            TextView statsTitle=text("STATS",13,MINT,true);
            statsTitle.setPadding(0,d(12),0,d(6));inside.addView(statsTitle);
            TableLayout stats=new TableLayout(activity);
            stats.setStretchAllColumns(true);
            for(int i=0;i<card.stats.length;i++){
                String[] pair=card.stats[i];if(pair==null || pair.length<2)continue;
                TableRow row=new TableRow(activity);
                row.setPadding(d(9),d(6),d(9),d(6));
                row.setBackgroundColor(i%2==0?0xff253b43:0xff1d3038);
                TextView label=text(pair[0],12,SUB,false);
                TextView value=text(pair[1],12,WHITE,true);
                value.setGravity(Gravity.END);
                row.addView(label);row.addView(value);
                stats.addView(row,new TableLayout.LayoutParams(-1,-2));
            }
            inside.addView(stats,new LinearLayout.LayoutParams(-1,-2));
            inside.addView(text("Base values; enchantment, skill and other effects can modify combat.",10,SUB,false));
        }
        inside.addView(paragraph("STRATEGY",card.interactions,WHITE));
        if(card.cautions!=null&&!card.cautions.isEmpty())
            inside.addView(paragraph("WATCH OUT",card.cautions,WARNING));
        // Keep attribution short. The reference remains available offline.
        inside.addView(paragraph("SOURCE",card.sourceLabel+"\n"+card.wikiUrl,SUB));
        Button close=button("Return to game",0xff385960);
        final Dialog dialog=new Dialog(activity);
        close.setOnClickListener(v->dialog.dismiss());
        inside.addView(close,new LinearLayout.LayoutParams(-1,d(47)));
        ScrollView scroll=new ScrollView(activity);scroll.addView(inside);
        dialog.setContentView(scroll);
        Window window=dialog.getWindow();
        if(window!=null){
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attr=window.getAttributes();
            attr.gravity=Gravity.BOTTOM;attr.width=WindowManager.LayoutParams.MATCH_PARENT;
            attr.height=WindowManager.LayoutParams.WRAP_CONTENT;
            attr.dimAmount=.7f;window.setAttributes(attr);
        }
        dialog.show();
        if(dialog.getWindow()!=null){
            dialog.getWindow().setLayout(-1,Math.min(d(650),activity.getResources().getDisplayMetrics().heightPixels*83/100));
            dialog.getWindow().setGravity(Gravity.BOTTOM);
        }
    }
    private void attachItemHelpButtons(){
        int id=StateProbe.id(activity,"menu_list");View v=id==0?null:activity.findViewById(id);
        if(!(v instanceof ListView))return;
        ListView list=(ListView)v;
        List<String> all=probe.currentMenuItemNames();if(all.isEmpty())return;
        for(int index=0;index<list.getChildCount();index++){
            int pos=list.getFirstVisiblePosition()+index;
            if(pos<0||pos>=all.size())continue;
            View row=list.getChildAt(index);
            int helpId=StateProbe.id(activity,"tutorial_item_help");
            Button help=helpId==0?null:row.findViewById(helpId);
            if(help==null)continue;
            String item=all.get(pos);
            help.setContentDescription("Explain "+item);
            help.setOnClickListener(clicked->showCard(WikiLibrary.forInventoryItem(item),
              null));
        }
    }
}
