package com.tbd.NetHack5.tutorial;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.tbd.forkfront.Cmd;
import com.tbd.forkfront.Input;
import com.tbd.forkfront.NH_State;
import java.util.EnumSet;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** An offline NetHack tutor drawn around the real ForkFront dungeon view.
 * UI colors, structure and interactions match the local preview; the game itself
 * retains sole control of character movement, items, menus and saved games.
 */
final class TutorialOverlay {
    private static final int BACK=0xff10191e, HEAD=0xff14242c, PANEL=0xff21343b,
        SURFACE=0xff314951, BORDER=0xff60818b, WHITE=0xffe8f0eb,
        GOLD=0xffecc890, MINT=0xff70e0bd, SUB=0xffc9dad6,
        WARNING=0xffffd8a1, RED=0xffe86662, RISK=0xff47382f;

    private final TutorialActivity activity;
    private final StateProbe probe;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable timer=new Runnable(){@Override public void run(){
        if(!resumed) return;
        refresh();handler.postDelayed(this,750);
    }};
    private boolean resumed;
    private LinearLayout choices, groundHints;
    private TextView nameLabel,detailLabel,depthLabel,headline,description,bagCount;
    private ProgressBar hpBar;
    private String lastFingerprint="";
    private TutorialEngine.Advice currentAdvice;
    private TutorialEngine.State currentState;

    TutorialOverlay(TutorialActivity a){activity=a;probe=new StateProbe(a);}
    private int d(float dp){return (int)(dp*activity.getResources().getDisplayMetrics().density+.5f);}
    private GradientDrawable shape(int color,int stroke,int corners){
        GradientDrawable out=new GradientDrawable();out.setColor(color);
        out.setCornerRadius(d(corners));if(stroke!=0)out.setStroke(d(1),stroke);
        return out;
    }
    private TextView text(String value,int size,int color,boolean bold){
        TextView t=new TextView(activity);t.setText(value);t.setTextSize(size);
        t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return t;
    }
    private Button button(String label,int color){
        Button b=new Button(activity);b.setText(label);b.setAllCaps(false);
        b.setTextColor(WHITE);b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        b.setBackground(shape(color,BORDER,10));
        b.setMinWidth(0);b.setMinimumWidth(0);b.setMinHeight(0);b.setMinimumHeight(0);
        b.setPadding(d(8),0,d(8),0);return b;
    }
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(activity);v.setOrientation(LinearLayout.VERTICAL);return v;}

    void install(){
        int id=StateProbe.id(activity,"base_frame");
        View root=id==0?null:activity.findViewById(id);
        if(!(root instanceof LinearLayout)){
            Toast.makeText(activity,"Tutorial layout is not available",Toast.LENGTH_LONG).show();return;
        }
        LinearLayout base=(LinearLayout)root;
        base.setBackgroundColor(BACK);

        // Header: same hierarchy as the interactive HTML prototype.
        LinearLayout header=vertical();
        header.setPadding(d(12),d(7),d(12),d(9));header.setBackgroundColor(HEAD);
        TextView overline=text("TUTORIAL MODE  ·  OFFLINE",10,MINT,true);
        overline.setLetterSpacing(.15f);header.addView(overline);
        LinearLayout mast=new LinearLayout(activity);mast.setGravity(Gravity.CENTER_VERTICAL);
        TextView portrait=text("⚔",25,WHITE,true);portrait.setGravity(Gravity.CENTER);
        portrait.setBackground(shape(0xff334951,GOLD,8));
        mast.addView(portrait,new LinearLayout.LayoutParams(d(48),d(48)));
        LinearLayout vitals=vertical();vitals.setPadding(d(9),0,d(6),0);
        nameLabel=text("Novice Adventurer",16,WHITE,true);nameLabel.setSingleLine(true);
        vitals.addView(nameLabel);
        hpBar=new ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal);
        hpBar.setIndeterminate(false);hpBar.setMax(100);hpBar.setProgress(100);
        hpBar.setProgressTintList(ColorStateList.valueOf(RED));
        hpBar.setProgressBackgroundTintList(ColorStateList.valueOf(0xff314146));
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,d(9));hp.topMargin=d(6);
        vitals.addView(hpBar,hp);
        detailLabel=text("HP —/— · AC —",11,SUB,false);
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(-1,-2);dl.topMargin=d(4);
        vitals.addView(detailLabel,dl);
        mast.addView(vitals,new LinearLayout.LayoutParams(0,d(52),1));
        depthLabel=text("DEPTH\n—",12,GOLD,true);depthLabel.setGravity(Gravity.CENTER);
        mast.addView(depthLabel,new LinearLayout.LayoutParams(d(55),d(48)));
        Button help=button("?",0xff334b51);help.setTextColor(GOLD);help.setTextSize(25);
        help.setContentDescription("What is happening? Offline wiki tutorial");
        help.setBackground(shape(0xff334b51,GOLD,100));
        help.setOnClickListener(v->explainCurrent());
        LinearLayout.LayoutParams bhl=new LinearLayout.LayoutParams(d(49),d(49));bhl.leftMargin=d(6);
        mast.addView(help,bhl);
        LinearLayout.LayoutParams ml=new LinearLayout.LayoutParams(-1,-2);ml.topMargin=d(5);
        header.addView(mast,ml);
        base.addView(header,0,new LinearLayout.LayoutParams(-1,-2));

        // The real NetHack map occupies the weighted center of base_frame.
        // We do NOT fabricate any terrain or replace the native map with a demo.
        int frameId=StateProbe.id(activity,"dlg_frame");
        View map=frameId==0?null:activity.findViewById(frameId);
        if(map!=null)map.setBackgroundColor(BACK);

        // Bottom tutorial sheet visually mirrors the HTML preview.
        LinearLayout sheet=vertical();sheet.setPadding(d(12),d(10),d(12),d(12));
        sheet.setBackground(shape(PANEL,0xff496268,0));
        TextView kicker=text("WHAT'S HAPPENING",10,MINT,true);kicker.setLetterSpacing(.13f);
        sheet.addView(kicker);
        headline=text("Preparing your next step…",19,0xfff7eee0,true);
        LinearLayout.LayoutParams hnl=new LinearLayout.LayoutParams(-1,-2);hnl.topMargin=d(3);
        sheet.addView(headline,hnl);
        description=text("The tutor reads the current game. It never moves your hero automatically.",12,SUB,false);
        LinearLayout.LayoutParams descl=new LinearLayout.LayoutParams(-1,-2);descl.topMargin=d(3);descl.bottomMargin=d(6);
        sheet.addView(description,descl);
        choices=vertical();sheet.addView(choices);
        groundHints=vertical();sheet.addView(groundHints);
        LinearLayout footer=new LinearLayout(activity);footer.setGravity(Gravity.CENTER_VERTICAL);
        Button bag=button("▣ Bag",HEAD);bag.setOnClickListener(v->showInventory());
        footer.addView(bag,new LinearLayout.LayoutParams(0,d(45),1));
        Button actions=button("☰ Actions",HEAD);actions.setOnClickListener(v->showCommandCenter());
        LinearLayout.LayoutParams act=new LinearLayout.LayoutParams(0,d(45),1);act.leftMargin=d(6);
        footer.addView(actions,act);
        Button explain=button("? Help",HEAD);explain.setOnClickListener(v->explainCurrent());
        LinearLayout.LayoutParams exp=new LinearLayout.LayoutParams(0,d(45),1);exp.leftMargin=d(6);
        footer.addView(explain,exp);
        LinearLayout.LayoutParams foot=new LinearLayout.LayoutParams(-1,-2);foot.topMargin=d(10);
        sheet.addView(footer,foot);
        TextView status=text("REAL NETHACK 5 · OFFLINE HELP · NO AUTOMATIC ACTIONS",9,0xff8fa9ad,false);
        status.setGravity(Gravity.CENTER);status.setPadding(0,d(7),0,0);
        sheet.addView(status);

        ScrollView bottomScroll=new ScrollView(activity);
        bottomScroll.setFillViewport(false);bottomScroll.setVerticalScrollBarEnabled(false);
        bottomScroll.addView(sheet);
        // Keep map usable, particularly on compact devices / in landscape.
        int height=Math.min(d(345),activity.getResources().getDisplayMetrics().heightPixels*43/100);
        int position=base.getChildCount();
        View kbd=StateProbe.id(activity,"kbd_frame")==0?null:activity.findViewById(StateProbe.id(activity,"kbd_frame"));
        if(kbd!=null)position=Math.max(0,base.indexOfChild(kbd));
        base.addView(bottomScroll,position,new LinearLayout.LayoutParams(-1,height));

        // Default command panels are hidden; menus remain native, and the
        // unusual-command keyboard can still be shown when the game requests it.
        hideOldCommandPanel();
        int nativePanels=StateProbe.id(activity,"cmdPanelLayout1");
        View cmdLayout=nativePanels==0?null:activity.findViewById(nativePanels);
        if(cmdLayout!=null) {
            // Native CmdPanelLayout.show() makes the old action strips visible
            // every movement turn. Hiding from a 750ms timer causes flashing.
            // Keep their scroll views mounted (so native preferences don't
            // crash on a missing parent), but collapse them before *any* draw.
            cmdLayout.getViewTreeObserver().addOnPreDrawListener(new ViewTreeObserver.OnPreDrawListener(){
                @Override public boolean onPreDraw(){hideOldCommandPanel();return true;}
            });
        }
        SharedPreferences prefs=activity.getSharedPreferences("nethack_tutorial",Context.MODE_PRIVATE);
        if(!prefs.getBoolean("seen_welcome_v2",false)){
            prefs.edit().putBoolean("seen_welcome_v2",true).apply();
            handler.postDelayed(this::showWelcome,1100);
        }
    }

    void resume(){resumed=true;handler.removeCallbacks(timer);handler.post(timer);}
    void pause(){resumed=false;handler.removeCallbacks(timer);}
    private void showWelcome(){
        if(activity.isFinishing())return;
        new AlertDialog.Builder(activity).setTitle("Welcome to NetHack Tutorial Mode")
          .setMessage("This is the real game, with an offline guide that explains what you see and why an action might help.\n\nRead the advice at the bottom. Tap ? in the header, beside actions or next to an inventory item for detailed help.\n\nHelp never uses a game turn. An action may; if it's dangerous, you will see a warning first.\n\nThe tutorial only offers item-based options after verifying what you've carried in the game's inventory.")
          .setPositiveButton("Start playing",null).show();
    }
    private void hideOldCommandPanel(){
        try{
            View v=activity.findViewById(StateProbe.id(activity,"cmdPanelLayout1"));
            if(v instanceof com.tbd.forkfront.CmdPanelLayout){
                com.tbd.forkfront.CmdPanelLayout layout=(com.tbd.forkfront.CmdPanelLayout)v;
                layout.hide();
                for(int i=0;i<layout.getChildCount();i++){
                    View child=layout.getChildAt(i);
                    // Only command-panel strips are direct ScrollView children.
                    // Status, map touch area, native direction pad, and game
                    // messages are deliberately left alone.
                    if(!(child instanceof ScrollView)&&!(child instanceof HorizontalScrollView))continue;
                    child.setAlpha(0f);
                    child.setClickable(false);child.setFocusable(false);
                    ViewGroup.LayoutParams lp=child.getLayoutParams();
                    if(lp!=null&&(lp.width!=0||lp.height!=0)) {
                        lp.width=0;lp.height=0;child.setLayoutParams(lp);
                    }
                    child.setVisibility(View.GONE);
                }
            }
        }catch(Exception ignored){}
    }
    private static int parse(String source,String regex){
        Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(source);
        if(!m.find())return -1;
        try{return Integer.parseInt(m.group(1));}catch(Exception ignored){return -1;}
    }
    private String status(String id){
        int i=StateProbe.id(activity,id);View v=i==0?null:activity.findViewById(i);
        return v instanceof TextView?((TextView)v).getText().toString():"";
    }
    private void refreshHeader(TutorialEngine.State s){
        String row0=status("nh_stat0"), row1=status("nh_stat1");
        if(!row0.isEmpty()){
            String first=row0.split("\\s+",2)[0];
            nameLabel.setText(first.length()<3?"Your Adventurer":first);
        }
        if(s.hp>=0 && s.maxHp>0){
            hpBar.setMax(Math.max(1,s.maxHp));hpBar.setProgress(Math.max(0,Math.min(s.maxHp,s.hp)));
        }
        int ac=parse(row0+" "+row1,"\\bAC\\s*:?\\s*(-?\\d+)");
        int depth=parse(row0+" "+row1,"\\b(?:Dlvl|Depth)\\s*:?\\s*(\\d+)");
        depthLabel.setText("DEPTH\n"+(depth>=0?depth:"—"));
        String label="HP "+(s.hp<0?"—":s.hp)+"/"+(s.maxHp<0?"—":s.maxHp)+"  ·  AC "+(ac<0?"—":ac);
        if(s.conditions.matches("(?is).*\\b(hungry|weak|fainting|blind|stun|conf)\\b.*"))label+="  ·  STATUS!";
        detailLabel.setText(label);
    }
    private void refresh(){
        hideOldCommandPanel();
        probe.observeMenu();TutorialEngine.State s=probe.snapshot();
        TutorialEngine.Advice a=TutorialEngine.assess(s);
        currentState=s;currentAdvice=a;
        if(choices==null)return;
        refreshHeader(s);
        StringBuilder k=new StringBuilder(a.title).append('|').append(a.explanation);
        for(TutorialEngine.Choice c:a.choices)k.append('|').append(c.label).append(':').append(c.command);
        for(TutorialEngine.GroundItem item:s.groundItems)k.append("|floor:").append(item.category).append(":").append(item.dx).append(":").append(item.dy).append(":").append(item.label()).append(":").append(item.topic());
        if(k.toString().equals(lastFingerprint)){attachItemHelpButtons();return;}
        lastFingerprint=k.toString();headline.setText(a.title);description.setText(a.explanation);
        choices.removeAllViews();
        int max=3;int count=Math.min(max,a.choices.size());
        for(int i=0;i<count;i++)addChoiceRow(choices,a.choices.get(i));
        if(a.choices.size()>count){
            Button more=button("See all "+a.choices.size()+" available options…",HEAD);
            more.setOnClickListener(v->moreOptions(a));
            choices.addView(more,new LinearLayout.LayoutParams(-1,d(42)));
        }
        // Show visible floor objects even while a monster takes priority in the main advice.
        // The help is passive: tapping ? does not move, pick up, read, or identify anything.
        if(groundHints!=null){
            groundHints.removeAllViews();
            if(!s.groundItems.isEmpty()) {
                TextView nearby=text("VISIBLE FLOOR OBJECTS",10,MINT,true);
                nearby.setPadding(0,d(8),0,0);groundHints.addView(nearby);
                int shown=0;
                for(TutorialEngine.GroundItem object:s.groundItems){
                    if(shown++>=2)break;
                    LinearLayout row=new LinearLayout(activity);
                    String where=object.underfoot?"here":"to the "+object.direction();
                    TextView label=text("• "+object.label()+" "+where,12,WHITE,false);
                    row.addView(label,new LinearLayout.LayoutParams(0,d(40),1));
                    Button q=button("?",HEAD);
                    q.setOnClickListener(v->showCard(WikiLibrary.forObservedItem(object.label(),object.category),null));
                    row.addView(q,new LinearLayout.LayoutParams(d(44),d(38)));
                    groundHints.addView(row);
                }
            }
        }
        attachItemHelpButtons();
    }
    private void addChoiceRow(LinearLayout box,TutorialEngine.Choice option){
        LinearLayout row=new LinearLayout(activity);
        Button main=button((option.risky?"⚠  ":"◆  ")+option.label,option.risky?RISK:SURFACE);
        main.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        main.setPadding(d(13),0,d(8),0);
        main.setOnClickListener(v->runChoice(option));
        row.addView(main,new LinearLayout.LayoutParams(0,d(48),1));
        Button help=button("?",0xff254049);help.setTextColor(GOLD);help.setTextSize(21);
        help.setContentDescription("Explain: "+option.label);
        help.setOnClickListener(v->showCard(WikiLibrary.get(option.wikiTopic),option.explanation));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(d(46),d(48));p.leftMargin=d(6);
        row.addView(help,p);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=d(6);
        box.addView(row,lp);
    }
    private void moreOptions(TutorialEngine.Advice advice){
        LinearLayout list=vertical();list.setPadding(d(14),d(14),d(14),d(14));
        list.addView(text("Choose an action or tap ? to understand what it does.",14,SUB,false));
        for(TutorialEngine.Choice choice:advice.choices)addChoiceRow(list,choice);
        ScrollView scroll=new ScrollView(activity);scroll.addView(list);
        new AlertDialog.Builder(activity).setTitle("Relevant options now")
            .setView(scroll).setNegativeButton("Back",null).show();
    }
    private void showInventory(){
        NH_State game=probe.game();if(game==null){
            Toast.makeText(activity,"Begin the game first",Toast.LENGTH_SHORT).show();return;
        }
        probe.expectsBag();dispatch("i");
    }
    private void runChoice(TutorialEngine.Choice choice){
        // A choice can become stale while a modal sheet is open.
        // Re-check live conditions and do not execute an action that has
        // disappeared from the engine's currently supported choice list.
        if(!choice.command.startsWith("HELP:")){
            TutorialEngine.Advice fresh=TutorialEngine.assess(probe.snapshot());
            boolean stillAllowed=false;
            for(TutorialEngine.Choice c:fresh.choices){
                if(c.command.equals(choice.command)&&c.label.equals(choice.label)){
                    stillAllowed=true;break;
                }
            }
            if(!stillAllowed){
                Toast.makeText(activity,"Situation changed; this option is no longer available",Toast.LENGTH_LONG).show();
                refresh();return;
            }
        }
        if(choice.command.startsWith("HELP:")){
            showCard(WikiLibrary.get(choice.command.substring(5)),choice.explanation);return;
        }
        if(choice.risky){
            new AlertDialog.Builder(activity).setTitle("⚠ This may be dangerous")
              .setMessage(choice.explanation+"\n\nTry this in the game? NetHack may ask you to choose a direction or item.")
              .setNegativeButton("Go back",null)
              .setNeutralButton("Learn more",(d,w)->showCard(WikiLibrary.get(choice.wikiTopic),null))
              .setPositiveButton("Try the action",(d,w)->dispatch(choice.command)).show();
        }else dispatch(choice.command);
    }
    private void dispatch(String command){
        NH_State state=probe.game();if(state==null)return;
        // Re-evaluate the preconditions immediately before executing a visible choice.
        // Do not trigger stale actions after a move, menu or message change.
        if(!command.equals("i")&&!command.equals(";")&&!command.equals(":")&&!command.equals("ESC"))probe.invalidateBag();
        if(command.startsWith("MOVE:")){
            String[] coord=command.substring(5).split(":");
            if(coord.length!=2)return;
            int dx=Integer.parseInt(coord[0]),dy=Integer.parseInt(coord[1]);
            if(dx<-1||dx>1||dy<-1||dy>1||(dx==0&&dy==0))return;
            // y is positive south; NetHack directions use hjkl/yubn or numpad.
            String vim=(dy==-1?(dx==-1?"y":dx==0?"k":"u"):
                dy==0?(dx==-1?"h":"l"):(dx==-1?"b":dx==0?"j":"n"));
            String pad=(dy==-1?(dx==-1?"7":dx==0?"8":"9"):
                dy==0?(dx==-1?"4":"6"):(dx==-1?"1":dx==0?"2":"3"));
            state.sendKeyCmd((state.isNumPadOn()?pad:vim).charAt(0));
            handler.postDelayed(this::refresh,250);return;
        }
        if(command.equals("ESC")){state.sendKeyCmd(27);return;}
        if(command.equals("KEYBOARD")){state.showKeyboard();return;}
        if(command.equals("20s")){
            new Cmd.KeySequnece(state,"20s","Search 20 times").execute(()->{});return;
        }
        if(command.startsWith("#")&&command.length()>1){
            new Cmd.KeySequnece(state,command+"\n",command).execute(()->{});return;
        }
        boolean ctrl=command.startsWith("^")&&command.length()==2;
        char ch=ctrl?command.charAt(1):command.charAt(0);
        EnumSet<Input.Modifier> mods=Input.modifiers();if(ctrl)mods.add(Input.Modifier.Control);
        state.handleKeyDown(ch,Input.nhKeyFromMod(ch,mods),Input.toKeyCode(ch),mods,0,true);
        handler.postDelayed(this::refresh,250);
    }
    private void commandButton(LinearLayout where, String label, String explanation,
                               String cmd, boolean risky, String topic,
                               AlertDialog[] parent) {
        LinearLayout row=new LinearLayout(activity);
        Button choice=button(label,risky?RISK:SURFACE);
        choice.setOnClickListener(v->{
            if(parent[0]!=null)parent[0].dismiss();
            if(risky){
                new AlertDialog.Builder(activity).setTitle("This advances game time")
                    .setMessage(explanation)
                    .setNegativeButton("Cancel",null)
                    .setPositiveButton("Continue",(dlg,w)->dispatch(cmd)).show();
            }else dispatch(cmd);
        });
        row.addView(choice,new LinearLayout.LayoutParams(0,d(45),1));
        Button why=button("?",HEAD);
        why.setOnClickListener(v->showCard(WikiLibrary.get(topic),explanation));
        LinearLayout.LayoutParams whyLp=new LinearLayout.LayoutParams(d(45),d(45));whyLp.leftMargin=d(5);
        row.addView(why,whyLp);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=d(7);
        where.addView(row,lp);
    }
    private void heading(LinearLayout where,String title){
        TextView heading=text(title,12,MINT,true);heading.setPadding(0,d(12),0,0);
        where.addView(heading);
    }
    /** Replaces the native Menu, ..., # and 20s strips with one readable menu. */
    private void showCommandCenter(){
        TutorialEngine.State s=probe.snapshot();
        LinearLayout inside=vertical();inside.setPadding(d(14),d(10),d(14),d(14));
        AlertDialog[] dialog={null};
        if(s.inputPromptActive){
            inside.addView(text("NetHack is awaiting a direction, item or confirmation. Finish that question first.",13,SUB,false));
            commandButton(inside,"Cancel current prompt","Abandon the pending prompt without making a new move.","ESC",false,"commands",dialog);
        } else {
            heading(inside,"LOOK & EXPLORE");
            commandButton(inside,"Inspect nearby creatures (;)","Look at a creature without attacking it.",";",false,"combat",dialog);
            commandButton(inside,"Search this spot (s)","Search for hidden doors and traps. One search normally uses a turn.","s",true,"exploration",dialog);
            if(!s.monsterAdjacent && !s.unidentifiedCreatureAdjacent && s.hp>0 && s.maxHp>0 && s.hp*2>s.maxHp
                && !s.conditions.toLowerCase(Locale.ROOT).contains("hungry") && !s.conditions.toLowerCase(Locale.ROOT).contains("weak")) {
                commandButton(inside,"Search 20 times (20s)","Repeats search 20 times, spending 20 turns. Monsters can arrive and you can get hungry; stop before doing this near danger.","20s",true,"exploration",dialog);
            }
            heading(inside,"YOUR CHARACTER");
            commandButton(inside,"Show inventory (i)","View the items the hero currently carries.","i",false,"inventory",dialog);
            commandButton(inside,"Equipped weapon ())","See what you have wielded, if anything.",")",false,"weapon",dialog);
            commandButton(inside,"Worn armor ([)","See armor currently worn.","[",false,"armor",dialog);
            commandButton(inside,"Worn rings (=)","Inspect worn rings.","=",false,"ring",dialog);
            commandButton(inside,"Worn amulet (\")","Inspect a currently worn amulet.","\"",false,"amulet",dialog);
            heading(inside,"ADVANCED (WHEN NEEDED)");
            commandButton(inside,"Extended commands (#)","Opens NetHack's extended-command prompt; useful for rare actions.","#",false,"commands",dialog);
            commandButton(inside,"Show original keyboard (...) ","For commands not yet supported by the tutorial, use NetHack's existing keyboard.","KEYBOARD",false,"commands",dialog);
            commandButton(inside,"Game options (O)","Configure NetHack gameplay options.","O",false,"commands",dialog);
        }
        ScrollView scroll=new ScrollView(activity);scroll.addView(inside);
        dialog[0]=new AlertDialog.Builder(activity).setTitle("Actions you can take")
            .setView(scroll).setNegativeButton("Return to game",null).create();
        dialog[0].show();
    }
    private void explainCurrent(){
        TutorialEngine.Advice a=currentAdvice;
        if(a==null){showCard(WikiLibrary.get("beginner"),null);return;}
        String situation=a.title+"\n\n"+a.explanation;
        WikiLibrary.Card card=WikiLibrary.get(a.wikiTopic);
        if(currentState!=null && !currentState.groundItems.isEmpty() &&
           (a.wikiTopic.equals("inventory") || a.title.toLowerCase(Locale.ROOT).contains("floor") ||
            a.title.toLowerCase(Locale.ROOT).contains("corpse") || a.title.toLowerCase(Locale.ROOT).contains("item"))) {
            for(TutorialEngine.GroundItem obj:currentState.groundItems)if(obj.underfoot){
                card=WikiLibrary.forObservedItem(obj.label(),obj.category);break;
            }
        }
        if(currentState!=null&&!currentState.recentMessage.trim().isEmpty()){
            situation+="\n\nLATEST GAME MESSAGE:\n"+currentState.recentMessage;
            WikiLibrary.Card message=WikiLibrary.forMessage(currentState.recentMessage);
            if(a.wikiTopic.equals("exploration")&&!message.id.equals("beginner"))card=message;
        }
        if(currentState!=null&&!currentState.groundItems.isEmpty()) {
            situation+="\n\nVISIBLE FLOOR OBJECTS:";
            for(TutorialEngine.GroundItem obj:currentState.groundItems)
                situation+="\n• "+obj.label()+" "+(obj.underfoot?"under your feet":"to the "+obj.direction());
            situation+="\nTap the ? beside a floor object for its specific help.";
        }
        showCard(card,situation);
    }
    private TextView paragraph(String heading,String body,int color){
        TextView text=text(heading+"\n"+body,14,color,false);
        text.setPadding(0,d(9),0,d(8));return text;
    }
    private void showCard(WikiLibrary.Card card,String situation){
        LinearLayout inside=vertical();inside.setPadding(d(19),d(18),d(19),d(18));
        inside.setBackgroundColor(0xff1c2d34);
        TextView eyebrow=text("OFFLINE NETHACK 5 REFERENCE",10,MINT,true);
        eyebrow.setLetterSpacing(.12f);inside.addView(eyebrow);
        TextView title=text("ⓘ  "+card.title,21,GOLD,true);
        title.setPadding(0,d(6),0,d(9));inside.addView(title);
        // Player-facing reference content: no implementation or identity-detection commentary.
        // Situation text is only shown for a contextual choice, never when inspecting an item.
        if(situation!=null && !situation.trim().isEmpty())
            inside.addView(paragraph("RIGHT NOW",situation,WHITE));
        inside.addView(paragraph("DESCRIPTION",card.what,WHITE));
        if(card.stats!=null && card.stats.length>0){
            TextView statsTitle=text("STATS",13,MINT,true);
            statsTitle.setPadding(0,d(12),0,d(6));inside.addView(statsTitle);
            TableLayout stats=new TableLayout(activity);
            stats.setStretchAllColumns(true);
            for(int i=0;i<card.stats.length;i++){
                String[] pair=card.stats[i];if(pair==null || pair.length<2)continue;
                TableRow row=new TableRow(activity);
                row.setPadding(d(9),d(6),d(9),d(6));
                row.setBackgroundColor(i%2==0?0xff253b43:0xff1d3038);
                TextView label=text(pair[0],12,SUB,false);
                TextView value=text(pair[1],12,WHITE,true);
                value.setGravity(Gravity.END);
                row.addView(label);row.addView(value);
                stats.addView(row,new TableLayout.LayoutParams(-1,-2));
            }
            inside.addView(stats,new LinearLayout.LayoutParams(-1,-2));
            inside.addView(text("Base values; enchantment, skill and other effects can modify combat.",10,SUB,false));
        }
        inside.addView(paragraph("STRATEGY",card.interactions,WHITE));
        if(card.cautions!=null&&!card.cautions.isEmpty())
            inside.addView(paragraph("WATCH OUT",card.cautions,WARNING));
        // Keep attribution short. The reference remains available offline.
        inside.addView(paragraph("SOURCE",card.sourceLabel+"\n"+card.wikiUrl,SUB));
        Button close=button("Return to game",0xff385960);
        final Dialog dialog=new Dialog(activity);
        close.setOnClickListener(v->dialog.dismiss());
        inside.addView(close,new LinearLayout.LayoutParams(-1,d(47)));
        ScrollView scroll=new ScrollView(activity);scroll.addView(inside);
        dialog.setContentView(scroll);
        Window window=dialog.getWindow();
        if(window!=null){
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams attr=window.getAttributes();
            attr.gravity=Gravity.BOTTOM;attr.width=WindowManager.LayoutParams.MATCH_PARENT;
            attr.height=WindowManager.LayoutParams.WRAP_CONTENT;
            attr.dimAmount=.7f;window.setAttributes(attr);
        }
        dialog.show();
        if(dialog.getWindow()!=null){
            dialog.getWindow().setLayout(-1,Math.min(d(650),activity.getResources().getDisplayMetrics().heightPixels*83/100));
            dialog.getWindow().setGravity(Gravity.BOTTOM);
        }
    }
    private void attachItemHelpButtons(){
        int id=StateProbe.id(activity,"menu_list");View v=id==0?null:activity.findViewById(id);
        if(!(v instanceof ListView))return;
        ListView list=(ListView)v;
        List<String> all=probe.currentMenuItemNames();if(all.isEmpty())return;
        for(int index=0;index<list.getChildCount();index++){
            int pos=list.getFirstVisiblePosition()+index;
            if(pos<0||pos>=all.size())continue;
            View row=list.getChildAt(index);
            int helpId=StateProbe.id(activity,"tutorial_item_help");
            Button help=helpId==0?null:row.findViewById(helpId);
            if(help==null)continue;
            String item=all.get(pos);
            help.setContentDescription("Explain "+item);
            help.setOnClickListener(clicked->showCard(WikiLibrary.forInventoryItem(item),
              null));
        }
    }
}
